#!/bin/bash
#SBATCH --job-name=MPKKSO
#SBATCH --partition=gpu
#SBATCH --nodes=1
#SBATCH --cpus-per-task=16
#SBATCH --ntasks-per-node=2
#SBATCH --gres=gpu:a100:2
#SBATCH --exclusive=user
#SBATCH --time=200:00:00
#SBATCH --output=out.txt  

# === SETUP TELEGRAM BOT VARIABLES ===
TELEGRAM_BOT_TOKEN="7871956984:AAHckNabtiNTFJxP14ORa9OFTPVe23cM_DQ"
TELEGRAM_CHAT_ID="7760968128"

send_telegram() {
    local msg="$1"
    curl -s -X POST "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
        -d chat_id="${TELEGRAM_CHAT_ID}" \
        -d text="${msg}" > /dev/null
}

# === SEND JOB START MESSAGE ===
send_telegram "<=== 🚀 SUKSHMA SLURM JOB STARTED 🚀 ===>
# Job Name: $SLURM_JOB_NAME
# Job ID: $SLURM_JOB_ID
# Node List: $SLURM_JOB_NODELIST
# Tasks: $SLURM_NTASKS
# CPUs per Task: ${SLURM_CPUS_PER_TASK:-1}
# GPUs per node: ${CUDA_VISIBLE_DEVICES:-0}
# Start Time: $(date)"

echo "SLURM_JOBID=$SLURM_JOBID"                                            
echo "SLURM_JOB_NODELIST=$SLURM_JOB_NODELIST"                               
echo "SLURM_NNODES=$SLURM_NNODES"                                           
echo "SLURMTMPDIR=$SLURMTMPDIR"                                             
echo "Date              = $(date)"                                          
echo "Hostname          = $(hostname -s)"                                   
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"                         
echo "Number of Nodes Allocated         = $SLURM_JOB_NUM_NODES"             
echo "Number of Tasks Allocated         = $SLURM_NTASKS"                    
echo "Number of Cores/Task Allocated = $SLURM_CPUS_PER_TASK"                
echo "Working Directory = $(pwd)"                                           
echo "working directory = $SLURM_SUBMIT_DIR"       

export NCCL_ALGO=Tree
export NCCL_P2P_LEVEL=NVL
export NVSHMEM_REMOTE_TRANSPORT=none
export NVSHMEM_DISABLE_P2P=0
export OMP_PROC_BIND=close
export OMP_PLACES=cores

module purge
module load hpc_sdk/nvhpc-24.3
module load libs/hdf5/1.14.6
#source ~/nvhpc.sh

set +e
make clean && make release
#make clear
compile_status=$?

if [ $compile_status -ne 0 ]; then
    send_telegram "===> ❌ COMPILATION FAILED ❌ <===
# Job Name: $SLURM_JOB_NAME
# Job ID: $SLURM_JOB_ID
# Node List: $SLURM_JOB_NODELIST
# End Time: $(date)

Compilation failed in make clean && make release."
    exit 1
fi
set -e


set +e
echo "START TIME: $(date)"
start_time=$(date +%s)

make run \
    nprocs=$SLURM_NTASKS \
    ppnode=$SLURM_NTASKS_PER_NODE \
    cpus_per_rank=$SLURM_CPUS_PER_TASK

run_status=$?

end_time=$(date +%s)
elapsed=$((end_time - start_time))
echo "Computation time: $elapsed seconds"
echo "END TIME: $(date)"

# Convert to HH:MM:SS
formatted_time=$(printf "%02d:%02d:%02d" $((elapsed/3600)) $(( (elapsed%3600)/60 )) $((elapsed%60)))

# === SEND END/ERROR MESSAGE ===
if [ $run_status -eq 0 ]; then
    send_telegram "===> ✅ SUKSHMA SLURM JOB COMPLETED ✅ <===
# Job Name: $SLURM_JOB_NAME
# Job ID: $SLURM_JOB_ID
# Node List: $SLURM_JOB_NODELIST
# Run Time: ${formatted_time}
# End Time: $(date)"

else
    # Read and truncate error log file 
    error_log_file="out.txt"
    if [ -f "$error_log_file" ]; then
        error_content=$(tail -c 500 "$error_log_file" | sed 's/`/"/g') 
    else
        error_content="(No slurm error log found)"
    fi

    send_telegram "===> ❌ SUKSHMA SLURM JOB FAILED ❌ <===
# Job Name: $SLURM_JOB_NAME
# Job ID: $SLURM_JOB_ID
# Node List: $SLURM_JOB_NODELIST
# End Time: $(date)
# Exit Code: $run_status

${error_content}"

fi

dir=$(awk '/^path[[:space:]]+/ {print $2}' bin/InputParams)

if [ -z "$dir" ]; then
    echo "No path found in InputParams"
    exit 1
fi

if [ "$dir" = "DATA" ]; then
    dir="bin/$dir"
fi

cp bin/InputParams "$dir/" || echo "Failed to copy InputParams"
cp out.txt "$dir/" || echo "Failed to copy out.txt"


module purge

###END OF FILE


