//#include "../include/binary.h"

__device__ void get_kx_ky_kz(double *kx, double *ky, double *kz, 
                             BoxIterator<cufftDoubleComplex> it) 

{
    long x = (long)it.x();
    long y = (long)it.y();
    long z = (long)it.z();

    const int nx = nx_d;
    const int ny = ny_d;
    const int nz = nz_d;

    const double dx = dx_d;
    const double dy = dy_d;
    const double dz = dz_d;

    if (x < nx / 2)
        *kx = (double)x * (double) (2.0 * M_PI /(dx * (double)nx));
    else
        *kx = (double)(x-nx) * (double) (2.0 * M_PI /(dx * (double)nx));
    
    if (y <ny / 2)
        *ky = (double)y * (double) (2.0 * M_PI /(dy * (double)ny));
    else
        *ky = (double)(y-ny) * (double) (2.0 * M_PI /(dy * (double)ny));
    
    if (z < nz / 2)
        *kz = (double)z * (double) (2.0 * M_PI /(dz * (double)nz));
    else
        *kz = (double)(z-nz) * (double) (2.0 * M_PI /(dz * (double)nz));

    return;
}
__global__ void Average(double *x, double sizescale)
{
    *x = *x*(sizescale);
}

__global__ void Copy_real_d(BoxIterator<cufftDoubleComplex> X_begin,
                            BoxIterator<cufftDoubleComplex> X_end,
                            BoxIterator<cufftDoubleComplex> Y_begin,
                            BoxIterator<cufftDoubleComplex> Z_begin,
                            double* __restrict__ tmpx,  
                            double* __restrict__ tmpy,  
                            double* __restrict__ tmpz)  
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    int nz = nz_d; int ny = ny_d;
    long idx = k + nz*(j + i*ny);

    X_begin += idx;
    Y_begin += idx;
    Z_begin += idx;

    if (X_begin < X_end)
    {
        tmpx[idx] = X_begin->x;
        tmpy[idx] = Y_begin->x;
        tmpz[idx] = Z_begin->x;
    }
    //__syncthreads();
}


__global__ void Copy_real(BoxIterator<cufftDoubleComplex> X_begin,
                            BoxIterator<cufftDoubleComplex> X_end,
                            double *Y, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    X_begin += idx;

    if (X_begin < X_end)
    {
        Y[idx] = X_begin->x;
    }
    //__syncthreads();
}

void Print_elas_MA(BoxIterator<cufftDoubleComplex>eigsts11_begin_r, 
                   BoxIterator<cufftDoubleComplex> eigsts11_end_r,
                   BoxIterator<cufftDoubleComplex>eigsts22_begin_r, 
                   BoxIterator<cufftDoubleComplex>eigsts33_begin_r, 
                   char* eigsts11, char* eigsts22, char* eigsts33)
{
        Copy_real_d<<<Gridsize,Blocksize>>>(eigsts11_begin_r, eigsts11_end_r, eigsts22_begin_r, eigsts33_begin_r,
                                            dummy, dummy2, dummy3);
        //Copy_real<<<Gridsize,Blocksize>>>(eigsts11_begin_r, eigsts11_end_r, dummy, nx,ny,nz);
        //Copy_real<<<Gridsize,Blocksize>>>(eigsts22_begin_r, eigsts22_end_r, dummy2, nx,ny,nz);
        //Copy_real<<<Gridsize,Blocksize>>>(eigsts33_begin_r, eigsts33_end_r, dummy3, nx,ny,nz);
        
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, ux_avg, num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy2, uy_avg, num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy3, uz_avg, num_items);
        
        //CUDA_CHECK(cudaDeviceSynchronize());
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, ux_avg2, num_items); 
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, uy_avg2, num_items);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy3, uz_avg2, num_items);
        
        CUDA_CHECK(cudaDeviceSynchronize());
        MPI_Allreduce(MPI_IN_PLACE, ux_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        MPI_Allreduce(MPI_IN_PLACE, uy_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        MPI_Allreduce(MPI_IN_PLACE, uz_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        
        if (rank == 0)
        { 
            printf("Max value in %s :%le\n", eigsts11, *ux_avg);
            printf("Max value in %s :%le\n", eigsts22, *uy_avg);
            printf("Max value in %s :%le\n", eigsts33, *uz_avg);
        }
        CUDA_CHECK(cudaMemset(ux_avg, 0.0, sizeof(*ux_avg)));
        CUDA_CHECK(cudaMemset(uy_avg, 0.0, sizeof(*uy_avg)));
        CUDA_CHECK(cudaMemset(uz_avg, 0.0, sizeof(*uz_avg)));
        
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy, ux_avg, num_items);
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy2, uy_avg, num_items);
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy3, uz_avg, num_items);
        
        CUDA_CHECK(cudaDeviceSynchronize());
        MPI_Allreduce(MPI_IN_PLACE, ux_avg, 1, MPI_DOUBLE, MPI_MIN, comm);
        MPI_Allreduce(MPI_IN_PLACE, uy_avg, 1, MPI_DOUBLE, MPI_MIN, comm);
        MPI_Allreduce(MPI_IN_PLACE, uz_avg, 1, MPI_DOUBLE, MPI_MIN, comm);
        
        if (rank == 0)
        { 
            printf("Min value in %s :%le\n", eigsts11, *ux_avg);
            printf("Min value in %s :%le\n", eigsts22, *uy_avg);
            printf("Min value in %s :%le\n", eigsts33, *uz_avg);
        }
                
        MPI_Allreduce(MPI_IN_PLACE, ux_avg2, 1, MPI_DOUBLE, MPI_SUM, comm);
        MPI_Allreduce(MPI_IN_PLACE, uy_avg2, 1, MPI_DOUBLE, MPI_SUM, comm);
        MPI_Allreduce(MPI_IN_PLACE, uz_avg2, 1, MPI_DOUBLE, MPI_SUM, comm);

        *ux_avg2 *= sizescale;
        *uy_avg2 *= sizescale;
        *uz_avg2 *= sizescale;

        if (rank == 0)
        { 
            printf("Avg value in %s :%le\n", eigsts11, *ux_avg2);
            printf("Avg value in %s :%le\n", eigsts22, *uy_avg2);
            printf("Avg value in %s :%le\n", eigsts33, *uz_avg2);
        }
        
        CUDA_CHECK(cudaMemset(ux_avg, 0.0, sizeof(*ux_avg)));
        CUDA_CHECK(cudaMemset(uy_avg, 0.0, sizeof(*uy_avg)));
        CUDA_CHECK(cudaMemset(uz_avg, 0.0, sizeof(*uz_avg)));
        
        CUDA_CHECK(cudaMemset(ux_avg2, 0.0, sizeof(*ux_avg2)));
        CUDA_CHECK(cudaMemset(uy_avg2, 0.0, sizeof(*uy_avg2)));
        CUDA_CHECK(cudaMemset(uz_avg2, 0.0, sizeof(*uz_avg2)));
}

void Print_elas_MA2(BoxIterator<cufftDoubleComplex>eigsts11_begin_r, 
                   BoxIterator<cufftDoubleComplex> eigsts11_end_r,
                   BoxIterator<cufftDoubleComplex> eigsts22_begin_r,
                   BoxIterator<cufftDoubleComplex>eigsts33_begin_r, 
                   char* eigsts11, char* eigsts22, char* eigsts33)
{
        
        Copy_real_d<<<Gridsize,Blocksize>>>(eigsts11_begin_r, eigsts11_end_r, eigsts22_begin_r, eigsts33_begin_r,
                                            dummy, dummy2, dummy3);
        
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, ux_avg, num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy2, uy_avg, num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy3, uz_avg, num_items);

        //cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, ux_avg2, num_items); 
        //cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, uy_avg2, num_items);
        //cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy3, uz_avg2, num_items);
        
        CUDA_CHECK(cudaDeviceSynchronize());
        //ncclAllReduce(ux_avg, ux_avg, 1, ncclDouble, ncclMax, nccl_comm, 0);
        //ncclAllReduce(uy_avg, uy_avg, 1, ncclDouble, ncclMax, nccl_comm, 0);
        //ncclAllReduce(uz_avg, uz_avg, 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        MPI_Allreduce(MPI_IN_PLACE, ux_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        MPI_Allreduce(MPI_IN_PLACE, uy_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        MPI_Allreduce(MPI_IN_PLACE, uz_avg, 1, MPI_DOUBLE, MPI_MAX, comm);
        
        //ncclAllReduce(ux_avg2, ux_avg2, 1, ncclDouble, ncclSum, nccl_comm, 0);
        //ncclAllReduce(uy_avg2, uy_avg2, 1, ncclDouble, ncclSum, nccl_comm, 0);
        //ncclAllReduce(uz_avg2, uz_avg2, 1, ncclDouble, ncclSum, nccl_comm, 0);
        
        CUDA_CHECK(cudaDeviceSynchronize());
        if (rank == 0)
        { 
            printf("Max value in %s :%le\n", eigsts11, *ux_avg);
            printf("Max value in %s :%le\n", eigsts22, *uy_avg);
            printf("Max value in %s :%le\n", eigsts33, *uz_avg);
            
            //printf("Avg value in %s :%le\n", eigsts11, *ux_avg2);
            //printf("Avg value in %s :%le\n", eigsts22, *uy_avg2);
            //printf("Avg value in %s :%le\n", eigsts33, *uz_avg2);
        }
        
        CUDA_CHECK(cudaMemset(ux_avg, 0.0, sizeof(*ux_avg)));
        CUDA_CHECK(cudaMemset(uy_avg, 0.0, sizeof(*uy_avg)));
        CUDA_CHECK(cudaMemset(uz_avg, 0.0, sizeof(*uz_avg)));
        
        //CUDA_CHECK(cudaMemset(ux_avg2, 0.0, sizeof(*ux_avg2)));
        //CUDA_CHECK(cudaMemset(uy_avg2, 0.0, sizeof(*uy_avg2)));
        //CUDA_CHECK(cudaMemset(uz_avg2, 0.0, sizeof(*uz_avg2)));
}

void SetColor(int colorCode) {
    printf("\033[%dm", colorCode);
}

// Function to reset color
void ResetColor() {
    printf("\033[0m");
}
__global__ void Summation(double *X, double *Y, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    if (idx < nx*ny*nz)
    {
        *Y += X[idx];
    }
}

__global__ void Copy_real2(BoxIterator<cufftDoubleComplex> X_begin,
                            BoxIterator<cufftDoubleComplex> X_end,
                            double *Y, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    X_begin += idx;

    if (X_begin < X_end)
    {
        //Y[idx] = 1.0;
        Y[idx] = X_begin->y;
    }
    //__syncthreads();
}

__global__ void Normalize_4d(BoxIterator<cufftDoubleComplex> iter1_begin,
                             BoxIterator<cufftDoubleComplex> iter1_end,
                             BoxIterator<cufftDoubleComplex> iter2_begin,
                             BoxIterator<cufftDoubleComplex> iter3_begin,
                             BoxIterator<cufftDoubleComplex> iter4_begin,
                             int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter1_begin += idx;
    iter2_begin += idx;
    iter3_begin += idx;
    iter4_begin += idx;
    
    const double sizescale = (1.0/(double)(nx*ny*nz));
    if (iter1_begin < iter1_end)
    {
        *iter1_begin = {((iter1_begin->x)*sizescale), 0.0}; 
        *iter2_begin = {((iter2_begin->x)*sizescale), 0.0}; 
        *iter3_begin = {((iter3_begin->x)*sizescale), 0.0}; 
        *iter4_begin = {((iter4_begin->x)*sizescale), 0.0}; 
    }

   // __syncthreads();
}

__global__ void Normalize_12d(BoxIterator<cufftDoubleComplex> iter1_begin,
                             BoxIterator<cufftDoubleComplex> iter1_end,
                             BoxIterator<cufftDoubleComplex> iter2_begin,
                             BoxIterator<cufftDoubleComplex> iter3_begin,
                             BoxIterator<cufftDoubleComplex> iter4_begin,
                             BoxIterator<cufftDoubleComplex> iter5_begin,
                             BoxIterator<cufftDoubleComplex> iter6_begin,
                             BoxIterator<cufftDoubleComplex> iter7_begin,
                             BoxIterator<cufftDoubleComplex> iter8_begin,
                             BoxIterator<cufftDoubleComplex> iter9_begin,
                             BoxIterator<cufftDoubleComplex> iter10_begin,
                             BoxIterator<cufftDoubleComplex> iter11_begin,
                             BoxIterator<cufftDoubleComplex> iter12_begin, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter1_begin += idx;
    iter2_begin += idx;
    iter3_begin += idx;
    iter4_begin += idx;
    iter5_begin += idx;
    iter6_begin += idx;
    
    iter7_begin += idx;
    iter8_begin += idx;
    iter9_begin += idx;
    iter10_begin += idx;
    iter11_begin += idx;
    iter12_begin += idx;
    
    const double sizescale = (1.0/(double)(nx*ny*nz));
    if (iter1_begin < iter1_end)
    {
        *iter1_begin = {((iter1_begin->x)*sizescale), 0.0}; 
        *iter2_begin = {((iter2_begin->x)*sizescale), 0.0}; 
        *iter3_begin = {((iter3_begin->x)*sizescale), 0.0}; 
        *iter4_begin = {((iter4_begin->x)*sizescale), 0.0}; 
        *iter5_begin = {((iter5_begin->x)*sizescale), 0.0}; 
        *iter6_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        
        *iter7_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        *iter8_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        *iter9_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        *iter10_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        *iter11_begin = {((iter6_begin->x)*sizescale), 0.0}; 
        *iter12_begin = {((iter6_begin->x)*sizescale), 0.0}; 
    }

   // __syncthreads();
}

__global__ void Normalize_6d(BoxIterator<cufftDoubleComplex> iter1_begin,
                             BoxIterator<cufftDoubleComplex> iter1_end,
                             BoxIterator<cufftDoubleComplex> iter2_begin,
                             BoxIterator<cufftDoubleComplex> iter3_begin,
                             BoxIterator<cufftDoubleComplex> iter4_begin,
                             BoxIterator<cufftDoubleComplex> iter5_begin,
                             BoxIterator<cufftDoubleComplex> iter6_begin)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz_d*(j + i*ny_d));

    iter1_begin += idx;
    iter2_begin += idx;
    iter3_begin += idx;
    iter4_begin += idx;
    iter5_begin += idx;
    iter6_begin += idx;
    
    const double sizescale = (1.0/(double)(nx_d*ny_d*nz_d));
    if (iter1_begin < iter1_end)
    {
        *iter1_begin = {((iter1_begin->x)*sizescale), 0.0}; 
        *iter2_begin = {((iter2_begin->x)*sizescale), 0.0}; 
        *iter3_begin = {((iter3_begin->x)*sizescale), 0.0}; 
        *iter4_begin = {((iter4_begin->x)*sizescale), 0.0}; 
        *iter5_begin = {((iter5_begin->x)*sizescale), 0.0}; 
        *iter6_begin = {((iter6_begin->x)*sizescale), 0.0}; 
    }

   // __syncthreads();
}

__global__ void Normalize_3d(BoxIterator<cufftDoubleComplex> iter1_begin,
                             BoxIterator<cufftDoubleComplex> iter1_end,
                             BoxIterator<cufftDoubleComplex> iter2_begin,
                             BoxIterator<cufftDoubleComplex> iter3_begin,
                             int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter1_begin += idx;
    iter2_begin += idx;
    iter3_begin += idx;
    
    const double sizescale = (1.0/(nx*ny*nz));
    if (iter1_begin < iter1_end)
    {
        *iter1_begin = {((iter1_begin->x)*sizescale), 0.0}; 
        *iter2_begin = {((iter2_begin->x)*sizescale), 0.0}; 
        *iter3_begin = {((iter3_begin->x)*sizescale), 0.0}; 
    }

   // __syncthreads();
}

__global__ void Normalize(BoxIterator<cufftDoubleComplex> iter_begin,
                          BoxIterator<cufftDoubleComplex> iter_end,
                          long nx, long ny, long nz, int Imag=0)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter_begin += idx;
    const double sizescale = (1.0/(nx*ny*nz));

    if (iter_begin < iter_end)
    {
        *iter_begin = {((iter_begin->x)*sizescale), 0.0}; 
    }

   // __syncthreads();
}
/*
__global__ void Normalize_noise(BoxIterator<cufftDoubleComplex> iter_begin,
                                BoxIterator<cufftDoubleComplex> iter_end,
                                double noise_per, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter_begin += idx;
    const double sizescale = (1.0/ (double) (nx*ny*nz));

    if (iter_begin >= iter_end)
        return;
    
    const double phi = sizescale * iter_begin->x; 
    const double noise = noise_per * (phi * (1.0 - phi));
    
    iter_begin->x = noise + phi; 
    iter_begin->y = 0.0; 
}
*/
__device__ void get_omega(double *omega, const double* __restrict__ n, 
                          const double* __restrict__ Chom) 
{
        
        const double n0n0 = n[0]*n[0], n1n1 = n[1]*n[1], n2n2 = n[2]*n[2]; 
        const double n0n1 = n[0]*n[1], n0n2 = n[0]*n[2], n1n2 = n[1]*n[2];
        const double Chom11_d = Chom[0];
        const double Chom12_d = Chom[1];
        const double Chom44_d = Chom[2];
        const double Chom12_44 = Chom12_d + Chom44_d;

        double invomega_v[6] = {fma(Chom11_d,n0n0,Chom44_d*(n1n1 + n2n2)),
                                fma(Chom11_d,n1n1,Chom44_d*(n0n0 + n2n2)),
                                fma(Chom11_d,n2n2,Chom44_d*(n0n0 + n1n1)),
                                (Chom12_44*n1n2),
                                (Chom12_44*n0n2),
                                (Chom12_44*n0n1)};

        const double det_omega = (invomega_v[0]*(invomega_v[1]*invomega_v[2] - invomega_v[3]*invomega_v[3])-
                                  invomega_v[5]*(invomega_v[5]*invomega_v[2] - invomega_v[4]*invomega_v[3])+
                                  invomega_v[4]*(invomega_v[5]*invomega_v[3] - invomega_v[4]*invomega_v[1]));
        
        const double inv_det = (fabs(det_omega) > 1.0e-06) ? (1.0 / det_omega) : 0.0;
        
         
        omega[0] = inv_det*(invomega_v[1]*invomega_v[2]- invomega_v[3]*invomega_v[3]);
        omega[1] = inv_det*(invomega_v[0]*invomega_v[2]- invomega_v[4]*invomega_v[4]);
        omega[2] = inv_det*(invomega_v[0]*invomega_v[1]- invomega_v[5]*invomega_v[5]);
        omega[3] =-inv_det*(invomega_v[0]*invomega_v[3]- invomega_v[4]*invomega_v[5]);
        omega[4] = inv_det*(invomega_v[5]*invomega_v[3]- invomega_v[4]*invomega_v[1]);
        omega[5] =-inv_det*(invomega_v[5]*invomega_v[2]- invomega_v[4]*invomega_v[3]);

}
__global__ void Compute_eigsts_hom(BoxIterator<cufftDoubleComplex> eigsts11_begin,
                                   BoxIterator<cufftDoubleComplex> eigsts11_end,
                                   BoxIterator<cufftDoubleComplex> eigsts22_begin,
                                   BoxIterator<cufftDoubleComplex> eigsts33_begin,
                                   const double* __restrict__ hphisum, 
                                   const double* __restrict__ Chom, 
                                   double epszero_d, double misfit_aniso)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    long idx = k + (nz_d*(j + i*ny_d));

    eigsts11_begin += idx; eigsts22_begin += idx; eigsts33_begin += idx;

    if (eigsts11_begin < eigsts11_end)
    {
        
        const double eig11 = epszero_d * hphisum[idx]; 
        const double eig22 = eig11 * misfit_aniso;
        ////const double eig33 = eig22; misfit aniso is same 
        
        const double Chom11_d = Chom[0]; 
        const double Chom12_d = Chom[1]; 
         
        *eigsts11_begin = {fma(Chom11_d, eig11,Chom12_d*(eig22 + eig22)), 0.0 };
        *eigsts22_begin = {fma(Chom11_d, eig22,Chom12_d*(eig11 + eig22)), 0.0 };
        *eigsts33_begin = {fma(Chom11_d, eig22,Chom12_d*(eig11 + eig22)), 0.0 };
       
        
    }
   // __syncthreads();

}

////Using ux,uy,uz pointers are reused here they've stored eigsts values and in this kernel we'll calc disps.
__global__ void Compute_uzero3(BoxIterator<cufftDoubleComplex> ux_begin,
                              BoxIterator<cufftDoubleComplex> ux_end,
                              BoxIterator<cufftDoubleComplex> uy_begin,
                              BoxIterator<cufftDoubleComplex> uz_begin,
                              const double* __restrict__ Chom)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz_d*(j + i*ny_d));

    ux_begin += idx; uy_begin += idx, uz_begin += idx;
    double n[3] = {0.0}; 
    double omega[6] = {0.0};

    if (ux_begin < ux_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], ux_begin);
        get_omega(omega, n, Chom);
      
        const cufftDoubleComplex fk11 = {(ux_begin->x * n[0]), (ux_begin->y * n[0])};
        const cufftDoubleComplex fk22 = {(uy_begin->x * n[1]), (uy_begin->y * n[1])};
        const cufftDoubleComplex fk33 = {(uz_begin->x * n[2]), (uz_begin->y * n[2])};

        *ux_begin = { (omega[0]*fk11.y + omega[5]*fk22.y + omega[4]*fk33.y), 
                      -1.0*(omega[0]*fk11.x + omega[5]*fk22.x + omega[4]*fk33.x) };
        
        *uy_begin = { (omega[5]*fk11.y + omega[1]*fk22.y + omega[3]*fk33.y), 
                      -1.0*(omega[5]*fk11.x + omega[1]*fk22.x + omega[3]*fk33.x) };

        *uz_begin = { (omega[4]*fk11.y + omega[3]*fk22.y + omega[2]*fk33.y), 
                      -1.0*(omega[4]*fk11.x + omega[3]*fk22.x + omega[2]*fk33.x) };

        
    }
    //__syncthreads();

}
/*
__global__ void Compute_uzero2(BoxIterator<cufftDoubleComplex> ux_begin,
                              BoxIterator<cufftDoubleComplex> ux_end,
                              BoxIterator<cufftDoubleComplex> uy_begin,
                              BoxIterator<cufftDoubleComplex> uy_end,
                              BoxIterator<cufftDoubleComplex> uz_begin,
                              BoxIterator<cufftDoubleComplex> uz_end,
                              BoxIterator<cufftDoubleComplex> eigsts11_begin,
                              BoxIterator<cufftDoubleComplex> eigsts11_end,
                              BoxIterator<cufftDoubleComplex> eigsts22_begin,
                              BoxIterator<cufftDoubleComplex> eigsts22_end,
                              BoxIterator<cufftDoubleComplex> eigsts33_begin,
                              BoxIterator<cufftDoubleComplex> eigsts33_end,
                              double Chom11_d, double Chom12_d, double Chom44_d,
                              long nx, long ny, long nz, double dx, double dy, double dz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    ux_begin += idx; uy_begin += idx, uz_begin += idx;
    eigsts11_begin += idx; eigsts22_begin += idx; eigsts33_begin += idx;

    double n[3] = {0.0}; 
    double omega[6] = {0.0};
    cufftDoubleComplex fk11, fk22, fk33;

    if (ux_begin < ux_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], eigsts11_begin, nx, ny, nz, dx, dy, dz);
        get_omega(omega, n, Chom11_d, Chom12_d, Chom44_d);
     
        fk11.x= eigsts11_begin->x*n[0];
        fk22.x= eigsts22_begin->x*n[1];
        fk33.x= eigsts33_begin->x*n[2];

        fk11.y= eigsts11_begin->y*n[0];
        fk22.y= eigsts22_begin->y*n[1];
        fk33.y= eigsts33_begin->y*n[2];

        *ux_begin = { (omega[0]*fk11.y + omega[5]*fk22.y + omega[4]*fk33.y), 
                      -1.0*(omega[0]*fk11.x + omega[5]*fk22.x + omega[4]*fk33.x) };
        
        *uy_begin = { (omega[5]*fk11.y + omega[1]*fk22.y + omega[3]*fk33.y), 
                      -1.0*(omega[5]*fk11.x + omega[1]*fk22.x + omega[3]*fk33.x) };

        *uz_begin = { (omega[4]*fk11.y + omega[3]*fk22.y + omega[2]*fk33.y), 
                      -1.0*(omega[4]*fk11.x + omega[3]*fk22.x + omega[2]*fk33.x) };

        
    }
    __syncthreads();

}

__global__ void Compute_uzero(BoxIterator<cufftDoubleComplex> ux_begin,
                              BoxIterator<cufftDoubleComplex> ux_end,
                              BoxIterator<cufftDoubleComplex> uy_begin,
                              BoxIterator<cufftDoubleComplex> uy_end,
                              BoxIterator<cufftDoubleComplex> uz_begin,
                              BoxIterator<cufftDoubleComplex> uz_end,
                              BoxIterator<cufftDoubleComplex> eigsts11_begin,
                              BoxIterator<cufftDoubleComplex> eigsts11_end,
                              BoxIterator<cufftDoubleComplex> eigsts22_begin,
                              BoxIterator<cufftDoubleComplex> eigsts22_end,
                              BoxIterator<cufftDoubleComplex> eigsts33_begin,
                              BoxIterator<cufftDoubleComplex> eigsts33_end,
                              double Chom11_d, double Chom12_d, double Chom44_d,
                              long nx, long ny, long nz, double dx, double dy, double dz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    ux_begin += idx; uy_begin += idx, uz_begin += idx;
    eigsts11_begin += idx; eigsts22_begin += idx; eigsts33_begin += idx;

    double n[3] = {0.0}; 

    cufftDoubleComplex fk11, fk22, fk33;
    double invomega_v[6] = {0.0}; double det_omega = 0.0;
    double omega[6] ={0.0}; 
    double adjomega[6] = {0.0};

    if (ux_begin < ux_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], eigsts11_begin, nx, ny, nz, dx, dy, dz);
         
        invomega_v[0] = (Chom11_d)*n[0]*n[0] + (Chom44_d)*n[1]*n[1] + Chom44_d*n[2]*n[2];
        invomega_v[1] = (Chom44_d)*n[0]*n[0] + (Chom11_d)*n[1]*n[1] + Chom44_d*n[2]*n[2];
        invomega_v[2] = (Chom44_d)*n[0]*n[0] + (Chom44_d)*n[1]*n[1] + Chom11_d*n[2]*n[2];
        invomega_v[3] = ((Chom12_d) + (Chom44_d))*n[1]*n[2];
        invomega_v[4] = ((Chom12_d) + (Chom44_d))*n[0]*n[2];
        invomega_v[5] = ((Chom12_d) + (Chom44_d))*n[0]*n[1];

        det_omega = (invomega_v[0]*(invomega_v[1]*invomega_v[2] - invomega_v[3]*invomega_v[3])-
                     invomega_v[5]*(invomega_v[5]*invomega_v[2] - invomega_v[4]*invomega_v[3])+
                     invomega_v[4]*(invomega_v[5]*invomega_v[3] - invomega_v[4]*invomega_v[1]));
       
        adjomega[0] = (invomega_v[1]*invomega_v[2]- invomega_v[3]*invomega_v[3]);
        adjomega[1] = (invomega_v[0]*invomega_v[2]- invomega_v[4]*invomega_v[4]);
        adjomega[2] = (invomega_v[0]*invomega_v[1]- invomega_v[5]*invomega_v[5]);
        adjomega[3] =-(invomega_v[0]*invomega_v[3]- invomega_v[4]*invomega_v[5]);
        adjomega[4] = (invomega_v[5]*invomega_v[3]- invomega_v[4]*invomega_v[1]);
        adjomega[5] =-(invomega_v[5]*invomega_v[2]- invomega_v[4]*invomega_v[3]);

        if (fabs(det_omega) > 1.0e-06)
        {
           omega[0] = (1.0/det_omega)*adjomega[0];
           omega[1] = (1.0/det_omega)*adjomega[1];
           omega[2] = (1.0/det_omega)*adjomega[2];
           omega[3] = (1.0/det_omega)*adjomega[3];
           omega[4] = (1.0/det_omega)*adjomega[4];
           omega[5] = (1.0/det_omega)*adjomega[5];
        }

        else
        {
           omega[0] = 0.0;
           omega[1] = 0.0;
           omega[2] = 0.0;
           omega[3] = 0.0;
           omega[4] = 0.0;
           omega[5] = 0.0;
        }
        
        fk11.x= eigsts11_begin->x*n[0];
        fk22.x= eigsts22_begin->x*n[1];
        fk33.x= eigsts33_begin->x*n[2];

        fk11.y= eigsts11_begin->y*n[0];
        fk22.y= eigsts22_begin->y*n[1];
        fk33.y= eigsts33_begin->y*n[2];
        
        *ux_begin = { (omega[0]*fk11.y + omega[5]*fk22.y + omega[4]*fk33.y), 
                      -1.0*(omega[0]*fk11.x + omega[5]*fk22.x + omega[4]*fk33.x) };
        
        *uy_begin = { (omega[5]*fk11.y + omega[1]*fk22.y + omega[3]*fk33.y), 
                      -1.0*(omega[5]*fk11.x + omega[1]*fk22.x + omega[3]*fk33.x) };

        *uz_begin = { (omega[4]*fk11.y + omega[3]*fk22.y + omega[2]*fk33.y), 
                      -1.0*(omega[4]*fk11.x + omega[3]*fk22.x + omega[2]*fk33.x) };
        
    }
    __syncthreads();

}*/

void Calc_uzero(cudaLibXtDesc *ux, cudaLibXtDesc *uy, cudaLibXtDesc *uz)

{
    auto [ux_begin_r, ux_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);

    auto [ux_begin_f, ux_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);
    
    auto [uy_begin_r, uy_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);

    auto [uy_begin_f, uy_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);
    
    auto [uz_begin_r, uz_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);

    auto [uz_begin_f, uz_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);
    
    Compute_eigsts_hom<<<Gridsize,Blocksize>>>(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, hphisum,
                                               Chom, epszero,misfit_aniso); 
    
    if (print_elas_vectors == 3 && OUTPUT == 1)
        Print_elas_MA2(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,(char*)"eigsts11", (char*)"eigsts22", (char*)"eigsts33");
    
    CUFFT_CHECK(cufftXtExecDescriptor(plan, ux, ux, CUFFT_FORWARD));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uy, uy, CUFFT_FORWARD));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uz, uz, CUFFT_FORWARD));
    
    
    Compute_uzero3<<<Gridsize,Blocksize>>>(ux_begin_f, ux_end_f, uy_begin_f, 
                                          uz_begin_f, Chom); 
    
       
    if ((print_elas_vectors == 3 || print_elas_vectors == 3) && OUTPUT == 1)
    {
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, ux, ux, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, uy, uy, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, uz, uz, CUFFT_INVERSE));

        Normalize_3d<<< Gridsize, Blocksize >>>(ux_begin_r, ux_end_r,uy_begin_r, uz_begin_r, nx,ny,nz);
        
        Print_elas_MA2(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,(char*)"ux", (char*)"uy", (char*)"uz");
                 
        CUFFT_CHECK(cufftXtExecDescriptor(plan, ux, ux, CUFFT_FORWARD));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uy, uy, CUFFT_FORWARD));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uz, uz, CUFFT_FORWARD));
            
    }

}
