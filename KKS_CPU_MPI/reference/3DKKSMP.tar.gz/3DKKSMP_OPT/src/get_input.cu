//#include "../include/binary.h"
void Get_Input_Parameters (char *fnin, char *fnout)
{
    FILE *fpin, *fpcout;

    if (!(fpin = fopen (fnin, "r"))) {
        printf ("File: %s could not be opened \n", fnin);
        exit (1);
    }

    if(fscanf (fpin, "%s%ld", param,&nx));
    if(fscanf (fpin, "%s%ld", param,&ny));
    if(fscanf (fpin, "%s%ld", param,&nz));
    if(fscanf (fpin, "%s%ld", param,&np));
    if(fscanf (fpin, "%s%le",param,&dx));
    if(fscanf (fpin, "%s%le",param,&dy));
    if(fscanf (fpin, "%s%le",param,&dz));
    if(fscanf (fpin, "%s%lf",param,&dt));
    if(fscanf (fpin, "%s%d", param,&NUM_THREADS_X));
    if(fscanf (fpin, "%s%d", param,&NUM_THREADS_Y));
    if(fscanf (fpin, "%s%d", param,&NUM_THREADS_Z));
    if(fscanf (fpin, "%s%le", param,&Lconv));
    if(fscanf (fpin, "%s%le", param,&Econv));
    if(fscanf (fpin, "%s%le", param,&Tconv));
    if(fscanf (fpin, "%s%le", param,&Na));
    if(fscanf (fpin, "%s%le", param,&Nv));
    if(fscanf (fpin, "%s%d", param,&Method));
    if(fscanf (fpin, "%s%d", param,&FE_form));
    if(fscanf (fpin, "%s%d", param,&Non_dim_calc));
    if(fscanf (fpin, "%s%d", param,&kappa_omega_calc));
    if(fscanf (fpin, "%s%lf",param,&Ln));
    if(fscanf (fpin, "%s%d", param,&Ln_dx));
    if(fscanf (fpin, "%s%lf",param,&gamma_intf));
    if(fscanf (fpin, "%s%lf%s%lf",param, &kpa, param, &omega));
    if(fscanf (fpin, "%s%le%s%le", param,&theta, param, &theta2));
    if(fscanf (fpin, "%s%lf",param,&diffusivity));
    if(fscanf (fpin, "%s%lf",param,&relax_coeff));
    if(fscanf (fpin, "%s%lf%s%lf%s%lf%s%lf", param, &f0A, param, &f0B, param,&Vm, param, &alpha));
    if(fscanf (fpin, "%s%le%s%le" , param , &c_alpha_eq , param , &c_beta_eq));
    if(fscanf (fpin, "%s%lf",param,&Supersaturation));
    if(fscanf (fpin, "%s%lf%s%lf%s%lf%s%d",param,&ppt_size_h, param, &width, param, &spacing, param, &NFP));
    if(fscanf (fpin, "%s%d", param,&Smoothening));
    if(fscanf (fpin, "%s%d", param,&Smoothening_steps));
    if(fscanf (fpin, "%s%d", param,&comp_evolution));
    if(fscanf (fpin, "%s%d", param,&nof_variants));
    if(fscanf (fpin, "%s%d", param,&initflag));
    if(fscanf (fpin, "%s%d", param,&create_nuclei));
    if(fscanf (fpin, "%s%d", param,&equal_nofps));
    if(fscanf (fpin, "%s%d", param,&seed));
    if(fscanf (fpin, "%s%d", param,&num_steps));
    if(fscanf (fpin, "%s%d", param,&initcount));
    if(fscanf (fpin, "%s%d", param,&t_prof1));
    if(fscanf (fpin, "%s%d", param,&t_prof2));
    if(fscanf (fpin, "%s%d", param,&t_prof3));
    if(fscanf (fpin, "%s%d", param,&numsteps_prof1));
    if(fscanf (fpin, "%s%d", param,&numsteps_prof2));
    if(fscanf (fpin, "%s%d", param,&noise_int));
    if(fscanf (fpin, "%s%d", param,&noise_steps));
    if(fscanf (fpin, "%s%le", param,&noise_per));
    if(fscanf (fpin, "%s%d", param,&elast_int));
    if(fscanf (fpin, "%s%d", param,&appl_stress));
    if(fscanf (fpin, "%s%d", param,&time_elast));
    if(fscanf (fpin, "%s%d", param,&time_sa));
    if(fscanf (fpin, "%s%d", param,&elast_eqm));
    if(fscanf (fpin, "%s%le", param,&Tol));
    if(fscanf (fpin, "%s%d", param,&nelast));
    if(fscanf (fpin, "%s%d", param,&norm_calc));
    if(fscanf (fpin, "%s%d", param,&newdfel));
    if(fscanf (fpin, "%s%d", param,&elast_consts));
    if(fscanf (fpin, "%s%d", param,&EC_calc));
    if(fscanf (fpin, "%s%le", param,&inhom));
    if(fscanf (fpin, "%s%le%s%le%s%le", param, &mu_m, param, &nu_m, param,
                &Az_m));
    if(fscanf (fpin, "%s%le%s%le%s%le", param, &mu_p, param, &nu_p, param,
                &Az_p));
    if(fscanf (fpin, "%s%le%s%le%s%le", param, &c11m, param, &c12m, param,
                &c44m));
    if(fscanf (fpin, "%s%le%s%le%s%le", param, &c11p, param, &c12p, param, &c44p));
    if(fscanf (fpin, "%s%le%s%le", param, &epszero, param, &misfit_aniso ));
    if(fscanf (fpin, "%s%le%le%le%le%le%le",param,&sigappl_v_h[0],&sigappl_v_h[1],
                &sigappl_v_h[2],&sigappl_v_h[3],&sigappl_v_h[4],&sigappl_v_h[5]));
    if(fscanf (fpin, "%s%d", param,&VTK_out));
    if(fscanf (fpin, "%s%d", param,&MPI_out));
    if(fscanf (fpin, "%s%d", param,&conf_out));
    if(fscanf (fpin, "%s%d", param,&drivforces_out));
    if(fscanf (fpin, "%s%d", param,&print_engs));
    if(fscanf (fpin, "%s%d", param,&engs_out));
    if(fscanf (fpin, "%s%d", param,&stress_strain_out));
    if(fscanf (fpin, "%s%d", param,&print_conv_iter));
    if(fscanf (fpin, "%s%d", param,&print_elas_vectors));
    if(fscanf (fpin, "%s%d", param,&felas2_out));
    if(fscanf (fpin, "%s%d", param,&Imag));
    if(fscanf (fpin, "%s%d", param,&nccl_int));
    if(fscanf (fpin, "%s%d", param,&testing));
    if(fscanf (fpin, "%s%s", param, path));
    if(fscanf (fpin, "%s%d", param,&TRACK_TIME));
    fclose (fpin);
    
    restart = initcount;
    if (rank == 0)
    {
        printf ("======PARAMETERS FROM INPUT FILE=======\n");
        printf ("nx=%ld\n",nx);
        printf ("ny=%ld\n",ny);
        printf ("nz=%ld\n",nz);
        printf ("np=%ld\n",np);
        printf ("dx=%le\n",dx);
        printf ("dy=%le\n",dy);
        printf ("dz=%le\n",dz);
        printf ("dt=%le\n",dt);
        printf ("Simulation steps = %d\n", num_steps);
        if (Method == 0)
            printf("Solving using Explicit and Constant Mobility Case\n");
        else if (Method == 1)
            printf("Solving usinf Explicit way and Variable Mobility Case\n");
        else if (Method == 3)
            printf("Solving usinf Explicit way and Weighted Avg  Mobility Case\n");
        printf ("theta = %lf\n", theta);
        printf ("Bulk free energy coefficients f0A=%le\t f0B=%le\nVm=%le\t dt=%le\n",
                f0A,f0B, Vm,dt);
        printf ("Interface_energy=%le\tInterface width=%le\n", gamma_intf, Ln);
        printf ("Supersaturation = %lf\n", Supersaturation);
        printf ("ppt_size = %lf\n", ppt_size_h);
        if (kappa_omega_calc == 1)
            printf("Calc Kappa and omega values from Ln,intf_energy & alpha\n");
        else
            printf("Using the kappa and omega values provided in the InputParams\n");
        
        printf ("=====MICROSTRUCTURE INFORMATION=====\n");
        printf ("Initflag = %d\n", initflag);
        printf("Number of Variants are: %d\n", nof_variants);

        if(initflag == 1) {

            initcount = 0;
            if (create_nuclei == 0)
                printf ("Single precipitate simulation\n");
            else if (create_nuclei == 1)
                printf ("Random nuclei generated based on CNT\n");
            else if (create_nuclei == 2 || create_nuclei == 3 || create_nuclei == 4)
            {
                if (nof_variants == 1)
                {
                    printf("Error: When simulating Multi-variants; No.of variants should be 4 in InputParams\n");
                    MPI_Abort(comm, EXIT_FAILURE);
                }
                printf ("Generating random MV nuclei with given volume fraction\n");
            }
            else if (create_nuclei == 3)
                printf ("Generating random nuclei of single variant with given vf\n");

        }
        else if (initflag == 2)
        {
            if (create_nuclei == 0)
                printf("creating quad nuclei of single variant\n");
            else if (create_nuclei == 1)
            {
                if (nof_variants == 1)
                {
                    printf("No.of variants should be 4\n");
                    MPI_Abort(comm, EXIT_FAILURE);
                }
                printf("creating quad nuclei of multi-variant\n");
            }
        }
        else if (initflag == 3)
        {
            printf("===> $$ Restarting simulation from step: $$ <===%d\n",restart);
            printf("==> $ If simulation is solving for multi variant, nof_variants should be 4 $ <==\n");
        }

        if(Smoothening == 0)
            printf("==> $$ NO SMOOTHENING is performed $$ <<== \n");
        if(Smoothening == 1)
            printf("==> $$ SMOOTHENING is performed for %d steps $$ <<== \n",Smoothening_steps);

        if(comp_evolution == 0)
            printf("running with NO COMPOSITION evolution \n");
        else
            printf("running with COMPOSITION evolution\n");

        if(elast_int == 0)
            printf("running WITHOUT ELASTICITY\n");
        else
        {
            printf("running WITH ELASTICITY from : %d\n",time_elast);
            if (elast_eqm == 1)
            {
                printf("Solving for elastic eqm\n");
                printf("Tolernece:%le\n", Tol);
            }
            else
                printf("Solving for given nelast steps\n");
            if (elast_consts == 1)
                printf("Solving using the given elastic constants\n");
            else
                printf("Solving using mu,nu,Az\n");
        }
        
        if(VTK_out == 4 && TRACK_TIME <= 0)
        {
            printf("When int16_t files are written, tracking is must to have double precision files for restarting\n");
            MPI_Abort(comm, EXIT_FAILURE);
        }
        
        if (elast_int == 1)
        {
            printf ("======ELASTICITY PARAMETERS=======\n");
            printf("Inhomogeneity is: %le\n", inhom);
            if (elast_consts == 0)
            {
                printf ("mu_m = %le, mu_m = %le, Az_m = %le\n", mu_m, nu_m, Az_m);
                printf ("mu_p = %le, nu_p = %le, az_p = %le\n", mu_p, nu_p, Az_p);
            }
            else
                printf ("c11m = %le, c12m = %le, c44m = %le\n",
                        c11m, c12m, c44m);
            printf ("epszero = %le misfit_aniso = %le\n", epszero, misfit_aniso);
            if (newdfel == 1)
                printf("Calc dfeldphi using newdfel\n");
            
            printf ("Applied stress \n");
            printf ("%.3le %.3le %.3le %.3le %.3le %.3le\n",
                    sigappl_v_h[0], sigappl_v_h[1], sigappl_v_h[2],
                    sigappl_v_h[3], sigappl_v_h[4], sigappl_v_h[5]);
            if (appl_stress == 1)
            {
                if (initflag == 3)
                {
                    if (time_sa < restart)
                    {
                        printf ("Error: time_sa (%d) should be greater than restart(%d) to apply stress\n", time_sa, restart);
                        exit(1);
                    }
                }

                printf ("Stress will be applied after iteration no = %d\n",time_sa);
            }
            else if (appl_stress == 0)
                printf("No stress is applied\n");
            printf("print_elas_vectors value is: %d\n", print_elas_vectors);
        }


        //else
        //{

        //    //sprintf (fn,"conf.%06d", initcount);
        //    //sprintf (fn,"prof_gp.%07d", initcount);
        //    sprintf (fn,"prof_gp.%d", initcount);
        //    printf ("Configuration read from file %s\n",fn);

        //}
        
        if (!(fpcout = fopen (fnout, "w"))) {
            printf ("File:%s could not be opened \n", fnout);
            exit (1);
        }
        //fprintf (fpcout, "The name of this file is : %s \n", fnout);
        //fprintf (fpcout, "Input is from            : %s \n", fnin);


        fprintf (fpcout, "nx %ld\n", nx);
        fprintf (fpcout, "ny %ld\n", ny);
        fprintf (fpcout, "nz %ld\n", nz);
        fprintf (fpcout, "np %ld\n", np);
        fprintf (fpcout, "dx %le\n",dx);
        fprintf (fpcout, "dy %le\n",dy);
        fprintf (fpcout, "dz %le\n",dz);
        fprintf (fpcout, "dt %lf\n",dt);
        fprintf (fpcout, "NUM_THREADS_X %d\n", NUM_THREADS_X);
        fprintf (fpcout, "NUM_THREADS_Y %d\n", NUM_THREADS_Y);
        fprintf (fpcout, "NUM_THREADS_Z %d\n", NUM_THREADS_Z);
        fprintf (fpcout, "Lconv %le\n", Lconv);
        fprintf (fpcout, "Econv %le\n", Econv);
        fprintf (fpcout, "Tconv %le\n", Tconv);
        fprintf (fpcout, "Na %le\n", Na);
        fprintf (fpcout, "Nv %le\n", Nv);
        fprintf (fpcout, "Method %d\n", Method);
        fprintf (fpcout, "FE_form %d\n", FE_form);
        fprintf (fpcout, "Non_dim_calc %d\n", Non_dim_calc);
        fprintf (fpcout, "kappa_omega_calc %d\n", kappa_omega_calc);
        fprintf (fpcout, "Ln %lf\n",Ln);
        fprintf (fpcout, "Ln_dx %d\n", Ln_dx);
        fprintf (fpcout, "gamma_intf %lf\n",gamma_intf);
        fprintf (fpcout, "kpa , omega %lf\t%lf\n",kpa, omega);
        fprintf (fpcout, "theta %le\n",theta);
        fprintf (fpcout, "diffusivity %lf\n",diffusivity);
        fprintf (fpcout, "realx_coeff %lf\n",relax_coeff);
        fprintf (fpcout, "f0A, f0B, Vm, alpha %lf\t%lf\t%lf\t%lf\n", f0A, f0B, Vm,alpha);
        fprintf (fpcout, "c_alpha_eq, c_beta_eq %le\t%le\n" ,c_alpha_eq ,c_beta_eq);
        fprintf (fpcout, "Supersaturation %lf\n",Supersaturation);
        fprintf (fpcout, "ppt_size_h, width, vf %lf\t%lf\t%lf\n",ppt_size_h, width,vf);
        fprintf (fpcout, "comp_evolution %d\n", comp_evolution);
        fprintf (fpcout, "Smoothening %d\n", Smoothening);
        fprintf (fpcout, "nof_variants %d\n", nof_variants);
        fprintf (fpcout, "initflag %d\n", initflag);
        fprintf (fpcout, "create_nuclei %d\n", create_nuclei);
        fprintf (fpcout, "equal_nofps %d\n", equal_nofps);
        fprintf (fpcout, "seed %d\n", seed);
        fprintf (fpcout, "numsteps %d\n", num_steps);
        fprintf (fpcout, "restart %d\n", restart);
        fprintf (fpcout, "initcount %d\n", initcount);
        fprintf (fpcout, "t_prof1 %d\n", t_prof1);
        fprintf (fpcout, "t_prof2 %d\n", t_prof2);
        fprintf (fpcout, "t_prof3 %d\n", t_prof3);
        fprintf (fpcout, "numsteps_prof1 %d\n", numsteps_prof1);
        fprintf (fpcout, "numsteps_prof2 %d\n", numsteps_prof2);
        fprintf (fpcout, "elast_int %d\n", elast_int);
        fprintf (fpcout, "appl_stress %d\n", appl_stress);
        fprintf (fpcout, "time_elast %d\n", time_elast);
        fprintf (fpcout, "time_sa %d\n", time_sa);
        fprintf (fpcout, "elast_eqm %d\n", elast_eqm);
        fprintf (fpcout, "Tol %le\n",Tol);
        fprintf (fpcout, "nelast %d\n", nelast);
        fprintf (fpcout, "norm_calc %d\n", norm_calc);
        fprintf (fpcout, "newdfel %d\n", newdfel);
        fprintf (fpcout, "elast_consts %d\n", elast_consts);
        fprintf (fpcout, "EC_calc %d\n", EC_calc);
        fprintf (fpcout, "inhom %le\n", inhom);
        fprintf (fpcout, "mu_m, nu_m, Az_m %le\t%le\t%le\n", mu_m, nu_m, Az_m);
        fprintf (fpcout, "mu_p, nu_p, Az_p %le\t%le\t%le\n", mu_p, nu_p, Az_p);
        fprintf (fpcout, "c11m, c12m, c44m %le\t%le\t%le\n", c11m, c12m, c44m);
        fprintf (fpcout, "c11p, c12p, c44p %le\t%le\t%le\n", c11p, c12p, c44p);
        fprintf (fpcout, "epszero, misfit_aniso %le\t%le\n", epszero,misfit_aniso );
        fprintf (fpcout, "appl_sigma  %le\t%le\t%le\t%le\t%le\t%le\n",sigappl_v_h[0], sigappl_v_h[1],
                            sigappl_v_h[2], sigappl_v_h[3], sigappl_v_h[4], sigappl_v_h[5]);
        fprintf (fpcout, "VTK_out %d\n", VTK_out);
        fprintf (fpcout, "MPI_out %d\n", MPI_out);
        fprintf (fpcout, "conf_out %d\n", conf_out);
        fprintf (fpcout, "driv_forces %d\n", drivforces_out);
        fprintf (fpcout, "print_engs %d\n", print_engs);
        fprintf (fpcout, "engs_out %d\n", engs_out);
        fprintf (fpcout, "stress_strain_out %d\n", stress_strain_out);
        fprintf (fpcout, "print_conv_iter %d\n", print_conv_iter);
        fprintf (fpcout, "print_elas_vectors %d\n", print_elas_vectors);
        fprintf (fpcout, "felas2_out %d\n", felas2_out);
        fprintf (fpcout, "Imag %d\n", Imag);
        fprintf (fpcout, "nccl_int %d\n", nccl_int);
        fprintf (fpcout, "testing %d\n", testing);
        /*
        fprintf (fpcout, "nx %ld\n", nx);
        fprintf (fpcout, "ny %ld\n", ny);
        fprintf (fpcout, "nz %ld\n", nz);
        fprintf (fpcout, "np %ld\n", np);
        fprintf (fpcout, "dx %lf\n",dx);
        fprintf (fpcout, "dy %lf\n",dy);
        fprintf (fpcout, "dz %lf\n",dz);
        fprintf (fpcout, "dt %lf\n",dt);
        fprintf (fpcout, "num_steps %d\n", num_steps);
        fprintf (fpcout, "f0A   %3.2f\t  f0B %3.2f\t Vm   %3.2f\t   alpha   %3.2f\n",
                f0A , f0B, Vm , alpha);
        fprintf (fpcout, "Supersaturation %lf\n", Supersaturation);
        fprintf (fpcout, "Ppt_size %lf\t vf %lf\n", ppt_size_h, vf);
        fprintf (fpcout, "diffusivity %le\t relax_coeff %lf\t \n", diffusivity, relax_coeff );
        if (Method == 0)
            fprintf(fpcout,"Solving using Explicit and Weighted Mobility Case\n");
        else if (Method == 1)
            fprintf(fpcout,"Solving usinf Explicit way and Variable Mobility Case\n");
        fprintf (fpcout,"theta = %lf\n", theta);
        fprintf(fpcout,"Bulk free energy coefficients f0A=%le\t f0B=%le\nVm=%le\t dt=%le\n",
                f0A,f0B, Vm,dt);
        fprintf(fpcout,"Interface_energy=%le\tInterface width=%le\n", gamma_intf, Ln);
        if (kappa_omega_calc == 1)
            fprintf(fpcout,"Calc Kappa and omega values from Ln,intf_energy & alpha\n");
        else
            fprintf(fpcout,"Using the kappa and omega values provided in the InputParams\n");
        
        fprintf(fpcout,"=====MICROSTRUCTURE INFORMATION=====\n");
        fprintf(fpcout,"Initflag = %d\n", initflag);

        if(initflag == 1) {

            initcount = 0;
            if (create_nuclei == 0)
                fprintf(fpcout,"Single precipitate simulation\n");
            else if (create_nuclei == 1)
                fprintf(fpcout,"Random nuclei generated based on CNT\n");
            else if (create_nuclei == 2)
            {
                if (nof_variants == 1)
                {
                    fprintf(fpcout,"Error: When simulating Multi-variants; No.of variants should be 4 in InputParams\n");
                    exit(1);
                }
                fprintf(fpcout,"Generating random MV nuclei with given volume fraction\n");
            }
            else if (create_nuclei == 3)
                fprintf(fpcout,"Generating random nuclei of single variant with given vf\n");

        }
        else if (initflag == 2)
        {
            if (create_nuclei == 0)
                fprintf(fpcout,"creating quad nuclei of single variant\n");
            else if (create_nuclei == 1)
            {
                if (nof_variants == 1)
                {
                    fprintf(fpcout,"No.of variants should be 4\n");
                    exit(1);
                }
                fprintf(fpcout,"creating quad nuclei of multi-variant\n");
            }
        }
        else
        {
            fprintf(fpcout,"reading input from conf.%d\n",restart);
        }

        if(comp_evolution == 0)
            fprintf(fpcout,"running without comp evolution\n");
        else
            fprintf(fpcout,"running with comp evolution\n");

        if(elast_int == 0)
            fprintf(fpcout,"running without elasticity\n");
        else
        {
            fprintf(fpcout,"running with elasticity\n");
            if (elast_eqm == 1)
            {
                fprintf(fpcout,"Solving for elastic eqm\n");
                fprintf(fpcout, "Tolerence:%le\n",Tol);
            }
            else
                fprintf(fpcout,"Solving for given nelast steps\n");
            if (elast_consts == 1)
                fprintf(fpcout,"Solving using the given elastic constants\n");
            else
                fprintf(fpcout,"Solving using mu,nu,Az\n");
        }
        
        if (elast_int == 1)
        {
            fprintf(fpcout,"======ELASTICITY PARAMETERS=======\n");
            if (elast_consts == 0)
            {
                fprintf(fpcout,"inhomogeneity = %le\n", inhom);
                fprintf(fpcout,"mu_m = %le, mu_m = %le, Az_m = %le\n", mu_m, nu_m, Az_m);
                fprintf(fpcout,"mu_p = %le, nu_p = %le, az_p = %le\n", mu_p, nu_p, Az_p);
            }
            else
                fprintf(fpcout,"c11m = %le, c12m = %le, c44m = %le\n",
                        c11m, c12m, c44m);
            fprintf(fpcout,"epszero = %le misfit_aniso = %le\n", epszero, misfit_aniso);
            if (newdfel == 1)
                fprintf(fpcout,"Calc dfeldphi using newdfel\n");
            
            fprintf(fpcout,"Applied stress \n");
            fprintf(fpcout,"%.3le %.3le %.3le %.3le %.3le %.3le\n",
                    sigappl_v_h[0], sigappl_v_h[1], sigappl_v_h[2],
                    sigappl_v_h[3], sigappl_v_h[4], sigappl_v_h[5]);
            if (appl_stress == 1)
            {
                if (initflag == 3)
                {
                    if (time_sa < restart)
                    {
                        fprintf(fpcout,"Error: time_sa (%d) should be greater than restart(%d) to apply stress\n", time_sa, restart);
                        exit(1);
                    }
                }

                fprintf(fpcout,"Stress will be applied after iteration no = %d\n",time_sa);
            }
            else if (appl_stress == 0)
                fprintf(fpcout,"No stress is applied\n");
        }
        */
        fclose  (fpcout);
    }
}

