//#include "../include/binary.h"
#include "out_conf.cu"
#include "calc_uzero.cu"
#include "inhomelast.cu"
#include "homelast.cu"
//#include "inhomelast.cu"

__global__ void Celas(double *Chom, double *Chet, double Chom11, double Chom12, double Chom44,
                     double Chet11, double Chet12, double Chet44)
{
    Chom[0] = Chom11;
    Chom[1] = Chom12;
    Chom[2] = Chom44;

    Chet[0] = Chet11;
    Chet[1] = Chet12;
    Chet[2] = Chet44;
}
__global__ void Average_d2(double *x, double *y, double sizescale)
{
    *x = *x*(sizescale);
    *y = *y*(sizescale);
}

__global__ void Calc_Gradphi_sv(BoxIterator<cufftDoubleComplex> gradphi0x_begin,
                                BoxIterator<cufftDoubleComplex> gradphi0y_begin,
                                BoxIterator<cufftDoubleComplex> gradphi0z_begin,
                                BoxIterator<cufftDoubleComplex> phi0_begin,
                                int nx_local, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    if (i >= nx_local || j >= ny || k >= nz) 
        return;

    long idx = k + (nz*(j + i*ny));

    gradphi0x_begin += idx;
    gradphi0y_begin += idx;
    gradphi0z_begin += idx; 
    phi0_begin += idx;
 
    double n[3] = {0.0};
    get_kx_ky_kz(&n[0], &n[1], &n[2], gradphi0x_begin);
    
    gradphi0x_begin->x = -1.0*n[0]*phi0_begin->y;
    gradphi0x_begin->y =      n[0]*phi0_begin->x;
    gradphi0y_begin->x = -1.0*n[1]*phi0_begin->y;
    gradphi0y_begin->y =      n[1]*phi0_begin->x;
    gradphi0z_begin->x = -1.0*n[2]*phi0_begin->y;
    gradphi0z_begin->y =      n[2]*phi0_begin->x;
}

__global__ void Calc_Gradphi_MV(BoxIterator<cufftDoubleComplex> gradphi0x_begin,
                                BoxIterator<cufftDoubleComplex> gradphi0y_begin,
                                BoxIterator<cufftDoubleComplex> gradphi0z_begin,
                                BoxIterator<cufftDoubleComplex> gradphi1x_begin,
                                BoxIterator<cufftDoubleComplex> gradphi1y_begin,
                                BoxIterator<cufftDoubleComplex> gradphi1z_begin,
                                BoxIterator<cufftDoubleComplex> gradphi2x_begin,
                                BoxIterator<cufftDoubleComplex> gradphi2y_begin,
                                BoxIterator<cufftDoubleComplex> gradphi2z_begin,
                                BoxIterator<cufftDoubleComplex> gradphi3x_begin,
                                BoxIterator<cufftDoubleComplex> gradphi3y_begin,
                                BoxIterator<cufftDoubleComplex> gradphi3z_begin,
                                BoxIterator<cufftDoubleComplex> phi0_begin,
                                BoxIterator<cufftDoubleComplex> phi1_begin,
                                BoxIterator<cufftDoubleComplex> phi2_begin,
                                BoxIterator<cufftDoubleComplex> phi3_begin,
                                int nx_local, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    if (i >= nx_local || j >= ny || k >= nz) 
        return;

    long idx = k + (nz*(j + i*ny));

    gradphi0x_begin += idx; 
    gradphi0y_begin += idx;
    gradphi0z_begin += idx;
    
    gradphi1x_begin += idx;
    gradphi1y_begin += idx;
    gradphi1z_begin += idx; 
    
    gradphi2x_begin += idx;
    gradphi2y_begin += idx;
    gradphi2z_begin += idx; 
    
    gradphi3x_begin += idx;
    gradphi3y_begin += idx;
    gradphi3z_begin += idx;     

    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;
 
    double n[3] = {0.0};
    get_kx_ky_kz(&n[0], &n[1], &n[2], gradphi0x_begin);
    
    gradphi0x_begin->x = -1.0*n[0]*phi0_begin->y;
    gradphi0x_begin->y =      n[0]*phi0_begin->x;
    gradphi0y_begin->x = -1.0*n[1]*phi0_begin->y;
    gradphi0y_begin->y =      n[1]*phi0_begin->x;
    gradphi0z_begin->x = -1.0*n[2]*phi0_begin->y;
    gradphi0z_begin->y =      n[2]*phi0_begin->x;
    
    gradphi1x_begin->x = -1.0*n[0]*phi1_begin->y;
    gradphi1x_begin->y =      n[0]*phi1_begin->x;
    gradphi1y_begin->x = -1.0*n[1]*phi1_begin->y;
    gradphi1y_begin->y =      n[1]*phi1_begin->x;
    gradphi1z_begin->x = -1.0*n[2]*phi1_begin->y;
    gradphi1z_begin->y =      n[2]*phi1_begin->x;
    
    gradphi2x_begin->x = -1.0*n[0]*phi2_begin->y;
    gradphi2x_begin->y =      n[0]*phi2_begin->x;
    gradphi2y_begin->x = -1.0*n[1]*phi2_begin->y;
    gradphi2y_begin->y =      n[1]*phi2_begin->x;
    gradphi2z_begin->x = -1.0*n[2]*phi2_begin->y;
    gradphi2z_begin->y =      n[2]*phi2_begin->x;
    
    gradphi3x_begin->x = -1.0*n[0]*phi3_begin->y;
    gradphi3x_begin->y =      n[0]*phi3_begin->x;
    gradphi3y_begin->x = -1.0*n[1]*phi3_begin->y;
    gradphi3y_begin->y =      n[1]*phi3_begin->x;
    gradphi3z_begin->x = -1.0*n[2]*phi3_begin->y;
    gradphi3z_begin->y =      n[2]*phi3_begin->x;
}

__global__ void Calc_fgrad_addfelas_sv(double *ftotal, double *felas, 
                                        BoxIterator<cufftDoubleComplex> gradphi0x_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi0y_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi0z_begin,
                                        double *kappa, int nx_local, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    if (i >= nx_local || j >= ny || k >= nz) 
        return;

    long idx = k + (nz*(j + i*ny));

    gradphi0x_begin += idx;
    gradphi0y_begin += idx;
    gradphi0z_begin += idx; 

    ftotal[idx] += (felas[idx] + (kappa[0] * (gradphi0x_begin->x * gradphi0x_begin->x
                                            + gradphi0y_begin->x * gradphi0y_begin->x
                                            + gradphi0z_begin->x * gradphi0z_begin->x)));
}

__global__ void Calc_fgrad_addfelas_MV(double *ftotal, double *felas, 
                                        BoxIterator<cufftDoubleComplex> gradphi0x_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi0y_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi0z_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi1x_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi1y_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi1z_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi2x_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi2y_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi2z_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi3x_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi3y_begin,
                                        BoxIterator<cufftDoubleComplex> gradphi3z_begin,
                                        double *kappa, int nx_local, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    if (i >= nx_local || j >= ny || k >= nz) 
        return;

    long idx = k + (nz*(j + i*ny));

    gradphi0x_begin += idx;
    gradphi0y_begin += idx;
    gradphi0z_begin += idx; 

    gradphi1x_begin += idx;
    gradphi1y_begin += idx;
    gradphi1z_begin += idx; 

    gradphi2x_begin += idx;
    gradphi2y_begin += idx;
    gradphi2z_begin += idx; 

    gradphi3x_begin += idx;
    gradphi3y_begin += idx;
    gradphi3z_begin += idx; 
    
    const double grad = (gradphi0x_begin->x * gradphi0x_begin->x + 
                         gradphi0y_begin->x * gradphi0y_begin->x +
                         gradphi0z_begin->x * gradphi0z_begin->x +
                         gradphi1x_begin->x * gradphi1x_begin->x + 
                         gradphi1y_begin->x * gradphi1y_begin->x +
                         gradphi1z_begin->x * gradphi1z_begin->x + 
                         gradphi2x_begin->x * gradphi2x_begin->x + 
                         gradphi2y_begin->x * gradphi2y_begin->x +
                         gradphi2z_begin->x * gradphi2z_begin->x + 
                         gradphi3x_begin->x * gradphi3x_begin->x + 
                         gradphi3y_begin->x * gradphi3y_begin->x +
                         gradphi3z_begin->x * gradphi3z_begin->x); 
    
    ftotal[idx] += (felas[idx] + (kappa[0] * grad));

}


//// Only normalize phi and initalize noise in noise_array.
__global__ void Normalize_phi_Init_noise(BoxIterator<cufftDoubleComplex> iter_begin,
                                         BoxIterator<cufftDoubleComplex> iter_end,
                                         curandStatePhilox4_32_10_t *d_states, double* noise_array,
                                         double noise_per, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    curandStatePhilox4_32_10_t local_state = d_states[idx];
    double randn = curand_normal_double(&local_state);

    iter_begin += idx;
    if (iter_begin >= iter_end)
        return;
    
    const double sizescale = (1.0/ (double) (nx*ny*nz));
    const double phi = sizescale * iter_begin->x; 
    
    double noise = noise_per * randn * (phi * (1.0-phi));
    
    iter_begin->x = phi;  
    iter_begin->y = 0.0;  
    
    d_states[idx] = local_state;
    noise_array[idx] = noise;

}
__global__ void Normalize_noise_phi(BoxIterator<cufftDoubleComplex> iter_begin,
                                BoxIterator<cufftDoubleComplex> iter_end,
                                curandStatePhilox4_32_10_t *d_states, double* noise_array,
                                double noise_per, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    curandStatePhilox4_32_10_t local_state = d_states[idx];
    double randn = curand_normal_double(&local_state);

    iter_begin += idx;
    if (iter_begin >= iter_end)
        return;
    
    const double sizescale = (1.0/ (double) (nx*ny*nz));
    const double phi = sizescale * iter_begin->x; 
    
    double noise = noise_per * randn * (phi * (1.0-phi));
    
    iter_begin->x = noise + phi;  
    iter_begin->y = 0.0;
    d_states[idx] = local_state;
    noise_array[idx] = noise;

}

__global__ void Normalize_noise_comp(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     double* noise_array,
                                     double* noise_mean, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));
    comp_begin += idx;
    
    if (comp_begin >= comp_end)
        return;
    
    const double sizescale = (1.0/ (double) (nx*ny*nz));
    const double cmp = comp_begin->x * sizescale;
    
    comp_begin->x = (noise_array[idx] - noise_mean[0]) + cmp;
    comp_begin->y = 0.0; 

}

__global__ void Add_noise(BoxIterator<cufftDoubleComplex> comp_begin,
                          BoxIterator<cufftDoubleComplex> comp_end,
                          BoxIterator<cufftDoubleComplex> phi_begin,
                          double* noise_array, double* noise_mean, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));
    comp_begin += idx;
    phi_begin += idx;
    
    if (comp_begin >= comp_end)
        return;
    
    const double cmp = comp_begin->x;
    const double phi = phi_begin->x;
    
    comp_begin->x = (noise_array[idx] - noise_mean[0]) + cmp;
    phi_begin->x = (noise_array[idx] - noise_mean[0]) + phi;

}

//// No scaling in comp is needed here since it's Method=2
__global__ void Add_noise_comp(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                      double* noise_array,
                                     double* noise_mean, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));
    comp_begin += idx;
    
    if (comp_begin >= comp_end)
        return;
    
    const double cmp = comp_begin->x;
    
    comp_begin->x = (noise_array[idx] - noise_mean[0]) + cmp;

}

__global__ void Normalize_noise(BoxIterator<cufftDoubleComplex> iter_begin,
                                BoxIterator<cufftDoubleComplex> iter_end,
                                curandStatePhilox4_32_10_t *d_states,
                                double noise_per, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));
    if (iter_begin >= iter_end)
        return;

    curandStatePhilox4_32_10_t local_state = d_states[idx];
    double randn = curand_normal_double(&local_state);

    iter_begin += idx;
    const double sizescale = (1.0/ (double) (nx*ny*nz));

    
    const double phi = sizescale * iter_begin->x; 
    double noise = noise_per * randn * (phi * (1.0-phi));
    
    iter_begin->x = noise + phi;  
    iter_begin->y = 0.0;
    d_states[idx] = local_state;

}

__global__ void Normalize_noise2(BoxIterator<cufftDoubleComplex> iter_begin,
                                BoxIterator<cufftDoubleComplex> iter_end,
                                curandStatePhilox4_32_10_t *d_states,
                                double noise_per, int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));
    if (iter_begin >= iter_end)
        return;

    curandStatePhilox4_32_10_t local_state = d_states[idx];
    double randn = curand_normal_double(&local_state);

    iter_begin += idx;
    const double sizescale = (1.0/ (double) (nx*ny*nz));

    
    const double phi = sizescale * iter_begin->x;
    double mask = phi*(1.0-phi);
    double noise = noise_per * randn * mask; 
    
    const double new_phi = noise + phi; 
    
    iter_begin->x = noise + new_phi; 
    iter_begin->y = 0.0;
    d_states[idx] = local_state;

    if (mask > 0.0 || mask < 0.0) 
    {
        printf("idx=%ld randn=%le phi_before=%le phi_after=%le\n",
               idx, randn, phi, new_phi);
    }
}

__global__ void init_rng(curandStatePhilox4_32_10_t *states,
                         unsigned long seed,
                         int nx, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;
    long idx = k + nz * (j + i * ny);
    if (idx >= nx * ny * nz) return;

    // Each thread gets a unique RNG state
    curand_init(seed, idx, 0, &states[idx]);
}
__global__ void Normalize_comp(BoxIterator<cufftDoubleComplex> iter_begin,
                               BoxIterator<cufftDoubleComplex> iter_end,
                               double CALPHA_chk, double CBETA_chk, double* abort_flag)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nz=nz_d; const int ny=ny_d;const int nx=nx_d;
    long idx = k + (nz*(j + i*ny));

    iter_begin += idx;
    const double sizescale = (1.0/ (double)(nx*ny*nz));
    const double Calpha_chk = CALPHA_chk;
    const double Cbeta_chk = CBETA_chk;

    if (iter_begin < iter_end)
    {
        *iter_begin = {((iter_begin->x)*sizescale), 0.0};
        
        if (iter_begin->x > Calpha_chk || iter_begin->x > Cbeta_chk)
        {
            *abort_flag = 1.0;
            return;
        }
    }
}

void Print_max_avg(size_t t_storage_bytes, void *t_storage, double *hphi0, double *Vf, long num_items,
                   double sizescale, char* hphi)
{
    cub::DeviceReduce::Max(t_storage, t_storage_bytes, hphi0, Vf, num_items);
    CUDA_CHECK(cudaDeviceSynchronize());
    MPI_Allreduce(MPI_IN_PLACE, Vf, 1, MPI_DOUBLE, MPI_MAX, comm); 
    if (rank == 0)
        printf("Max value in %s: %le\n",hphi, *Vf);
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
    
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, hphi0, Vf, num_items);
    CUDA_CHECK(cudaDeviceSynchronize()); 
    MPI_Allreduce(MPI_IN_PLACE, Vf, 1, MPI_DOUBLE, MPI_SUM, comm); 
    *Vf *= sizescale;
    if (rank == 0)
        printf("Avg value in %s: %le\n",hphi , *Vf);
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
}

/*
void Print_max_avg(size_t t_storage_bytes, void *t_storage, double *hphi0, double *Vf1, double *Vf2, long num_items,
                   double sizescale, char* hphi)
{
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, hphi0, Vf1, num_items);
    cub::DeviceReduce::Max(t_storage, t_storage_bytes, hphi0, Vf2, num_items);
    CUDA_CHECK(cudaDeviceSynchronize());
    MPI_Allreduce(MPI_IN_PLACE, Vf1, 1, MPI_DOUBLE, MPI_SUM, comm); 
    MPI_Allreduce(MPI_IN_PLACE, Vf2, 1, MPI_DOUBLE, MPI_MAX, comm); 
    *Vf1 *= sizescale;
    if (rank == 0)
    {
        printf("Max value in %s: %le\n",hphi, *Vf2);
        printf("Avg value in %s: %le\n",hphi , *Vf1);
    }
    
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));

}*/

__global__ void Update_PhaseComp(BoxIterator<cufftDoubleComplex> Calpha_begin, 
                                 BoxIterator<cufftDoubleComplex> Calpha_end, 
                                 BoxIterator<cufftDoubleComplex> Cbeta_begin, 
                                 const double diffusivity, const double dt)

{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const long ny = ny_d; const long nz = nz_d;
    const long idx = k + (nz * (j + (i*ny)));
    Calpha_begin += idx; Cbeta_begin += idx;
    if (Calpha_begin >= Calpha_end)
        return;
    
    double n[3] = {0.0};
    get_kx_ky_kz(&n[0], &n[1], &n[2], Calpha_begin);

    const double kpow2 = (n[0]*n[0]) + (n[1]*n[1]) + (n[2]*n[2]);
    const double Ddt = diffusivity*dt;
    const double denom = 1.0 + (Ddt*kpow2);

    Calpha_begin->x /= denom;
    Calpha_begin->y /= denom;
    
    Cbeta_begin->x /= denom;
    Cbeta_begin->y /= denom;
}

__global__ void Calc_dfdcxyz(BoxIterator<cufftDoubleComplex> gradmux_begin, 
                                 BoxIterator<cufftDoubleComplex> gradmux_end, 
                                 BoxIterator<cufftDoubleComplex> gradmuy_begin, 
                                 BoxIterator<cufftDoubleComplex> gradmuz_begin, 
                                 const double* __restrict__ hphisum, double Am, double Ap, 
                                 double D) 
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz_d * (j + (i*ny_d)));
    gradmux_begin += idx; gradmuy_begin += idx; gradmuz_begin += idx;
    if (gradmux_begin < gradmux_end)
    {
        const double hsum = hphisum[idx];
        const double temp = D*((0.5/Am)*(1.0-hsum) + (0.5/Ap)*hsum); 
        const double mux = gradmux_begin->x; 
        const double muy = gradmuy_begin->x; 
        const double muz = gradmuz_begin->x;

        *gradmux_begin = {(temp * mux), 0.0};
        *gradmuy_begin = {(temp * muy), 0.0};
        *gradmuz_begin = {(temp * muz), 0.0};


    }
   // __syncthreads();

}

__global__ void Calc_dfdc(BoxIterator<cufftDoubleComplex> dfdc_begin, 
                                 BoxIterator<cufftDoubleComplex> dfdc_end, 
                                 BoxIterator<cufftDoubleComplex> dfdcx_begin, 
                                 BoxIterator<cufftDoubleComplex> dfdcy_begin, 
                                 BoxIterator<cufftDoubleComplex> dfdcz_begin, 
                                 double dx, double dy, double dz)

{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz_d * (j + (i*ny_d)));
    
    dfdc_begin += idx; 
    dfdcx_begin += idx; 
    dfdcy_begin += idx; 
    dfdcz_begin += idx; 

    double n[3] = {0.0};

    if (dfdc_begin < dfdc_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], dfdc_begin);
        
        const cufftDoubleComplex dfdcx = *dfdcx_begin;
        const cufftDoubleComplex dfdcy = *dfdcy_begin;
        const cufftDoubleComplex dfdcz = *dfdcz_begin;

        *dfdc_begin = {(-1.0*(n[0]*dfdcx.y + n[1]*dfdcy.y + n[2]*dfdcz.y)),
                             (n[0]*dfdcx.x + n[1]*dfdcy.x + n[2]*dfdcz.x)};

    }
    //__syncthreads();

}
__global__ void Kernel_test(cufftDoubleComplex *test1, cufftDoubleComplex *test2, cufftDoubleComplex * test3, 
                            BoxIterator <cufftDoubleComplex> X_begin, BoxIterator <cufftDoubleComplex> X_end, 
                            BoxIterator <cufftDoubleComplex> Y_begin, BoxIterator <cufftDoubleComplex> Y_end, 
                            BoxIterator <cufftDoubleComplex> Z_begin, BoxIterator <cufftDoubleComplex> Z_end, 
                            long nx, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    X_begin += idx; 
    Y_begin += idx; 
    Z_begin += idx; 
    if (X_begin < X_end)
    {
        test1[idx].x = X_begin->x;
        test2[idx].x = Y_begin->x;
        test3[idx].x = Z_begin->x;
        
        test1[idx].y = 0.0; 
        test2[idx].y = 0.0; 
        test3[idx].y = 0.0; 
        
        //printf("x_begin->x value from kernel: %le\n", X_begin->x);
        //printf("test1 value from kernel: %le\n", test1[idx].x);
    }
    //__syncthreads();

}
/*
__global__ void KernelR2C(double *Y, 
                          BoxIterator <cufftDoubleComplex> X_begin,
                          BoxIterator <cufftDoubleComplex> X_end, 
                          long nx, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    X_begin += idx; 
    if (X_begin < X_end)
    {
        X_begin->x = Y[idx];
        X_begin->y = 0.0;
    }
    //__syncthreads();

}*/
__global__ void KernelC2R(double *Y, 
                          BoxIterator <cufftDoubleComplex> X_begin,
                          BoxIterator <cufftDoubleComplex> X_end, 
                          long nx, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    X_begin += idx; 
    if (X_begin < X_end)
    {
        Y[idx] = X_begin->x;
    }
    //__syncthreads();

}

__global__ void Calc_hsum_dhdphi_sv(double* __restrict__ hphisum, double* __restrict__ dhdphi0, 
                                    double*  __restrict__ ftotal, double* __restrict__ volfrac,
                                    BoxIterator<cufftDoubleComplex> phi0_begin,
                                    BoxIterator<cufftDoubleComplex> phi0_end,
                                    BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                                    double omega, int engs_out, int output, int TRACK_OBS, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;

    long idx = k + nz*(j + i*ny);
    
    phi0_begin += idx; 
    dfdphi0_begin += idx; 

    if (phi0_begin >= phi0_end)
        return;
    double p0 = phi0_begin->x;
    double p0p0 = p0*p0;

    hphisum[idx] = (p0*p0p0 * (6.0*p0p0 - 15.0*p0 + 10.0));
    
    dhdphi0[idx] = (30.0*p0p0 * (p0p0 - 2.0*p0 + 1.0));
    
    *dfdphi0_begin = {(omega*(2.0*p0 * (1.0-p0)*(1.0-2.0*p0))), 0.0};
    
    if ((engs_out != 0 && output == 1) || TRACK_OBS == 1)
        ftotal[idx] = omega*(p0p0 * (1.0-p0)*(1.0-p0));
    
    if(TRACK_OBS == 1)
    {
        volfrac[idx] = (p0 > 0.5) ? 1.0 : 0.0;
    }
}
/*
__global__ void Calc_hsum_dhdphi_sv(double *hphisum, double *dhdphi0, 
                                    BoxIterator<cufftDoubleComplex> phi0_begin,
                                    BoxIterator<cufftDoubleComplex> phi0_end)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;

    long idx = k + nz_d*(j + i*ny_d);
    
    phi0_begin += idx; 

    if (phi0_begin < phi0_end)
    {
        double p0 = phi0_begin->x;
        double p0p0 = p0*p0;

        hphisum[idx] = (p0*p0p0 * (6.0*p0p0 - 15.0*p0 + 10.0));
        
        dhdphi0[idx] = (30.0*p0p0 * (p0p0 - 2.0*p0 + 1.0));
        
    }
    //__syncthreads();

}*/

__global__ void Calc_hphisum_dhdphi(double *hphisum, double *dhdphi0, double *dhdphi1,
                                   double *dhdphi2, double *dhdphi3, double *vol_frac, 
                                  BoxIterator<cufftDoubleComplex> phi0_begin,
                                  BoxIterator<cufftDoubleComplex> phi0_end,
                                  BoxIterator<cufftDoubleComplex> phi1_begin,
                                  BoxIterator<cufftDoubleComplex> phi2_begin,
                                  BoxIterator<cufftDoubleComplex> phi3_begin,
                                  int TRACK_OBS, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;

    long idx = k + (nz * (j + (i*ny))); 
    phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;
    
    if (phi0_begin < phi0_end)
    {
        double p0 = phi0_begin->x;
        double p1 = phi1_begin->x;
        double p2 = phi2_begin->x;
        double p3 = phi3_begin->x;
        
        double p0p0 = p0*p0;
        double p1p1 = p1*p1;
        double p2p2 = p2*p2;
        double p3p3 = p3*p3;
        
        hphisum[idx] = (p0*p0p0 * (6.0*p0p0 - 15.0*p0 + 10.0) + 
                        p1*p1p1 * (6.0*p1p1 - 15.0*p1 + 10.0) + 
                        p2*p2p2 * (6.0*p2p2 - 15.0*p2 + 10.0) + 
                        p3*p3p3 * (6.0*p3p3 - 15.0*p3 + 10.0));
         
        dhdphi0[idx] = (30.0*p0p0 * (p0p0 - 2.0*p0 + 1.0));
        dhdphi1[idx] = (30.0*p1p1 * (p1p1 - 2.0*p1 + 1.0));
        dhdphi2[idx] = (30.0*p2p2 * (p2p2 - 2.0*p2 + 1.0));
        dhdphi3[idx] = (30.0*p3p3 * (p3p3 - 2.0*p3 + 1.0));
        
        if(TRACK_OBS == 1)
            vol_frac[idx] = (p0 > 0.5 || p1 > 0.5 || p2 > 0.5 || p3 > 0.5) ? 1.0 : 0.0;
    }
    //__syncthreads();

}

__global__ void Calc_Grad(BoxIterator<cufftDoubleComplex> gradx_begin,
                          BoxIterator<cufftDoubleComplex> gradx_end,
                          BoxIterator<cufftDoubleComplex> grady_begin,
                          BoxIterator<cufftDoubleComplex> grady_end,
                          BoxIterator<cufftDoubleComplex> gradz_begin,
                          BoxIterator<cufftDoubleComplex> gradz_end,
                          BoxIterator<cufftDoubleComplex> X_begin,
                          BoxIterator<cufftDoubleComplex> X_end,
                          double dx, double dy, double dz,
                          long nx_start, long nx, long ny, long nz) 
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    double n[3] = {0.0};
    
    X_begin += idx; gradx_begin += idx; grady_begin += idx; gradz_begin += idx;

    if (gradx_begin < gradx_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], gradx_begin);
        
        cufftDoubleComplex temp = *X_begin;

        *gradx_begin = {(-1.0*n[0] * temp.y), (n[0] * temp.x)};
        *grady_begin = {(-1.0*n[1] * temp.y), (n[1] * temp.x)};
        *gradz_begin = {(-1.0*n[2] * temp.y), (n[2] * temp.x)};
        
    }
    //__syncthreads();

}

__global__ void Calc_dgdphi_sv(BoxIterator<cufftDoubleComplex> dgdphi0_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi0_end, 
                            BoxIterator<cufftDoubleComplex> phi0_begin, 
                            double omega,
                            long nx, long ny, long nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    dgdphi0_begin += idx;
    phi0_begin += idx; 
    if (dgdphi0_begin < dgdphi0_end)
    {
        double p0 = phi0_begin->x;
        
        *dgdphi0_begin = {(omega*(2.0*p0 * (1.0-p0)*(1.0-2.0*p0))), 0.0};

    }
    //__syncthreads();
}

__global__ void Calc_dgdphi_sphi(BoxIterator<cufftDoubleComplex> dgdphi0_begin, 
                                 BoxIterator<cufftDoubleComplex> dgdphi0_end, 
                                 BoxIterator<cufftDoubleComplex> phi0_begin, 
                                 BoxIterator<cufftDoubleComplex> phi1_begin, 
                                 BoxIterator<cufftDoubleComplex> phi2_begin, 
                                 BoxIterator<cufftDoubleComplex> phi3_begin, 
                                 double omega, double theta)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nz = nz_d; const int ny = ny_d;
    long idx = k + (nz * (j + (i*ny))); 
    
    dgdphi0_begin += idx;
    phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;
    
    if (dgdphi0_begin < dgdphi0_end)
    { 
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double omg = omega;
        const double tmp = 2.0*theta;

        const double fterm = (2.0*p0 * (1.0-p0)*(1.0-2.0*p0));
        const double sterm = fma(p1, p1, fma(p2, p2, p3*p3));
 
        dgdphi0_begin->x = (omg*(fterm + tmp*p0*sterm));
        dgdphi0_begin->y = 0.0; 
        
    }
    //__syncthreads();
}

__global__ void Calc_dgdphi(BoxIterator<cufftDoubleComplex> dgdphi0_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi0_end, 
                            BoxIterator<cufftDoubleComplex> dgdphi1_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi2_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi3_begin, 
                            BoxIterator<cufftDoubleComplex> phi0_begin, 
                            BoxIterator<cufftDoubleComplex> phi1_begin, 
                            BoxIterator<cufftDoubleComplex> phi2_begin, 
                            BoxIterator<cufftDoubleComplex> phi3_begin, 
                            double omega, double theta, double* __restrict__ ftotal,
                            int engs_out, int TRACK_OBS, int output, int ny, int nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    
    dgdphi0_begin += idx; dgdphi1_begin += idx; dgdphi2_begin += idx; dgdphi3_begin += idx;
    phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;
    
    if (dgdphi0_begin < dgdphi0_end)
    {
        /* 
        ////Type-1 :
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double p0p0 = p0*p0;
        const double p1p1 = p1*p1;
        const double p2p2 = p2*p2;
        const double p3p3 = p3*p3;

        const double omg = omega;
        const double tmp = 2.0*theta;

        *dgdphi0_begin = {(omg*((2.0*p0 * (1.0-p0)*(1.0-2.0*p0)) + tmp*p0 * (p1p1 + p2p2 + p3p3))), 0.0};
        *dgdphi1_begin = {(omg*((2.0*p1 * (1.0-p1)*(1.0-2.0*p1)) + tmp*p1 * (p0p0 + p2p2 + p3p3))), 0.0};
        *dgdphi2_begin = {(omg*((2.0*p2 * (1.0-p2)*(1.0-2.0*p2)) + tmp*p2 * (p0p0 + p1p1 + p3p3))), 0.0};
        *dgdphi3_begin = {(omg*((2.0*p3 * (1.0-p3)*(1.0-2.0*p3)) + tmp*p3 * (p0p0 + p1p1 + p2p2))), 0.0};*/
         
        ////Type-2 : Fastest
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double p0p0 = p0*p0;
        const double p1p1 = p1*p1;
        const double p2p2 = p2*p2;
        const double p3p3 = p3*p3;
        const double psum = p0p0 + p1p1 + p2p2 + p3p3;

        const double omg = omega;
        const double tmp = 2.0*theta;

        *dgdphi0_begin = {(omg*((2.0*p0 * (1.0-p0)*(1.0-2.0*p0)) + tmp*p0 * (psum - p0p0))), 0.0};
        *dgdphi1_begin = {(omg*((2.0*p1 * (1.0-p1)*(1.0-2.0*p1)) + tmp*p1 * (psum - p1p1))), 0.0};
        *dgdphi2_begin = {(omg*((2.0*p2 * (1.0-p2)*(1.0-2.0*p2)) + tmp*p2 * (psum - p2p2))), 0.0};
        *dgdphi3_begin = {(omg*((2.0*p3 * (1.0-p3)*(1.0-2.0*p3)) + tmp*p3 * (psum - p3p3))), 0.0};
        
        const double fterm = (p0p0*(1.0-p0)*(1.0-p0) + p1p1*(1.0-p1)*(1.0-p1) + 
                 p2p2*(1.0-p2)*(1.0-p2) + p3p3*(1.0-p3)*(1.0-p3));
        
        const double sterm = (p0p0*(p1p1 +p2p2 + p3p3) + p1p1*(p2p2 + p3p3) + p2p2*p3p3);

        if ((engs_out != 0 && output == 1) || TRACK_OBS == 1)
            ftotal[idx] += omg * (fterm + theta*sterm); 
        
        /*
        ////Type-3 :
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double omg = omega;
        const double tmp = 2.0*theta;

        const double fterm0 = (2.0*p0 * (1.0-p0)*(1.0-2.0*p0));
        const double fterm1 = (2.0*p1 * (1.0-p1)*(1.0-2.0*p1));
        const double fterm2 = (2.0*p2 * (1.0-p2)*(1.0-2.0*p2));
        const double fterm3 = (2.0*p3 * (1.0-p3)*(1.0-2.0*p3));
        
        const double sterm0 = fma(p1, p1, fma(p2, p2, p3*p3));
        const double sterm1 = fma(p0, p0, fma(p2, p2, p3*p3));
        const double sterm2 = fma(p1, p1, fma(p0, p0, p3*p3));
        const double sterm3 = fma(p1, p1, fma(p2, p2, p0*p0));
 
        dgdphi0_begin->x = (omg*(fterm0 + tmp*p0*sterm0));
        dgdphi1_begin->x = (omg*(fterm1 + tmp*p1*sterm1));
        dgdphi2_begin->x = (omg*(fterm2 + tmp*p2*sterm2));
        dgdphi3_begin->x = (omg*(fterm3 + tmp*p3*sterm3));
        
        dgdphi0_begin->y = 0.0; 
        dgdphi1_begin->y = 0.0; 
        dgdphi2_begin->y = 0.0; 
        dgdphi3_begin->y = 0.0; */
    }
}

__global__ void Calc_dgdphi2(BoxIterator<cufftDoubleComplex> dgdphi0_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi0_end, 
                            BoxIterator<cufftDoubleComplex> dgdphi1_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi2_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi3_begin, 
                            BoxIterator<cufftDoubleComplex> phi0_begin, 
                            BoxIterator<cufftDoubleComplex> phi1_begin, 
                            BoxIterator<cufftDoubleComplex> phi2_begin, 
                            BoxIterator<cufftDoubleComplex> phi3_begin, 
                            double omega, double theta, double theta2, 
                            int ny, int nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    
    dgdphi0_begin += idx; dgdphi1_begin += idx; dgdphi2_begin += idx; dgdphi3_begin += idx;
    phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;
    
    if (dgdphi0_begin < dgdphi0_end)
    { 
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double p0p0 = p0*p0;
        const double p1p1 = p1*p1;
        const double p2p2 = p2*p2;
        const double p3p3 = p3*p3;
        const double psum = p0p0 + p1p1 + p2p2 + p3p3;

        const double omg = omega;
        const double tmp = 2.0*theta;
        const double tmp2 = 2.0*theta2;

        *dgdphi0_begin = {(omg*((2.0*p0 * (1.0-p0)*(1.0-2.0*p0)) + tmp*p0 * (psum - p0p0) + tmp2*p0*(p1p1*p2p2 + p1p1*p3p3 + p2p2*p3p3))), 0.0};
        *dgdphi1_begin = {(omg*((2.0*p1 * (1.0-p1)*(1.0-2.0*p1)) + tmp*p1 * (psum - p1p1) + tmp2*p1*(p0p0*p2p2 + p0p0*p3p3 + p2p2*p3p3))), 0.0};
        *dgdphi2_begin = {(omg*((2.0*p2 * (1.0-p2)*(1.0-2.0*p2)) + tmp*p2 * (psum - p2p2) + tmp2*p2*(p0p0*p1p1 + p0p0*p3p3 + p1p1*p3p3))), 0.0};
        *dgdphi3_begin = {(omg*((2.0*p3 * (1.0-p3)*(1.0-2.0*p3)) + tmp*p3 * (psum - p3p3) + tmp2*p3*(p0p0*p1p1 + p0p0*p2p2 + p1p1*p2p2))), 0.0};
        
    }
}

__global__ void Calc_dgdphi1(BoxIterator<cufftDoubleComplex> dgdphi0_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi0_end, 
                            BoxIterator<cufftDoubleComplex> dgdphi1_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi2_begin, 
                            BoxIterator<cufftDoubleComplex> dgdphi3_begin, 
                            BoxIterator<cufftDoubleComplex> phi0_begin, 
                            BoxIterator<cufftDoubleComplex> phi1_begin, 
                            BoxIterator<cufftDoubleComplex> phi2_begin, 
                            BoxIterator<cufftDoubleComplex> phi3_begin, 
                            double omega)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nz=nz_d; const int ny=ny_d;
    long idx = k + (nz * (j + (i*ny))); 
    
    dgdphi0_begin += idx; dgdphi1_begin += idx; dgdphi2_begin += idx; dgdphi3_begin += idx;
    phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;
    
    if (dgdphi0_begin < dgdphi0_end)
    {
        const double p0 = phi0_begin->x;
        const double p1 = phi1_begin->x;
        const double p2 = phi2_begin->x;
        const double p3 = phi3_begin->x;
        
        const double omg = omega;

        *dgdphi0_begin = {(omg*((2.0*p0 * (1.0-p0)*(1.0-2.0*p0)))), 0.0};
        *dgdphi1_begin = {(omg*((2.0*p1 * (1.0-p1)*(1.0-2.0*p1)))), 0.0};
        *dgdphi2_begin = {(omg*((2.0*p2 * (1.0-p2)*(1.0-2.0*p2)))), 0.0};
        *dgdphi3_begin = {(omg*((2.0*p3 * (1.0-p3)*(1.0-2.0*p3)))), 0.0};
        
    }
}
__global__ void Calc_dfchdphi_mu(BoxIterator<cufftDoubleComplex> dfdc_begin, BoxIterator<cufftDoubleComplex> dfdc_end,
                                 BoxIterator<cufftDoubleComplex> dfdphi0_begin,BoxIterator<cufftDoubleComplex> comp_begin,
                                 const double* __restrict__ hphisum, const double* __restrict__ dhdphi0, 
                                 const double* __restrict__ c_eq, const double Nv, const double AM, const double AP)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int ny=ny_d; int nz=nz_d;
    long idx = k + (nz * (j + (i*ny))); 
    dfdc_begin += idx; comp_begin += idx; dfdphi0_begin += idx; 
    
    if (dfdc_begin < dfdc_end)
    {
        const double temp = dfdphi0_begin->x;
        const double hsum = hphisum[idx];
        const double Am = AM;
        const double Ap = AP;
        const double frac = Am/Ap;
        const double calpha_eq = c_eq[0];
        const double cbeta_eq = c_eq[1];
        
        ////Matrix phase comp.
        double Calpha  = (comp_begin->x - (hsum*(cbeta_eq - (frac*calpha_eq))));
        Calpha /= ((hsum*frac) + (1.0 - hsum));

        /////Precipitate phase comp.
        const double delta_Calpha = Calpha - calpha_eq;
        const double Cbeta  = cbeta_eq + frac*delta_Calpha;
        const double delta_Cbeta = Cbeta - cbeta_eq;

        const double falpha = Am*delta_Calpha*delta_Calpha;
        const double fbeta = Ap*delta_Cbeta*delta_Cbeta;

        const double mu = 2.0*Am*delta_Calpha;
        const double dfchem = ((fbeta-falpha) + (Calpha-Cbeta)*mu);

        *comp_begin = {((hsum*Cbeta) + ((1.0 - hsum)*Calpha)), 0.0};
        *dfdc_begin = {mu, 0.0};
        *dfdphi0_begin = {(temp + Nv*dhdphi0[idx]*dfchem), 0.0};

    }
    //__syncthreads();
}

__global__ void Calc_phase_comp(BoxIterator<cufftDoubleComplex> Calpha,
                                BoxIterator<cufftDoubleComplex> Cbeta,
                                BoxIterator<cufftDoubleComplex> comp_begin,
                                BoxIterator<cufftDoubleComplex> comp_end, double *hphisum,
                                double *c_eq, double *f0, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx;
    Calpha += idx;
    Cbeta += idx;
    
    if (comp_begin < comp_end)
    {
        double hsum = hphisum[idx];
        double frac = f0[0]/f0[1];
        double calpha_eq = c_eq[0];
        double cbeta_eq = c_eq[1];
         
        ////Matrix phase comp.
        double C1  = (comp_begin->x - (hsum*(cbeta_eq - (frac*calpha_eq))));
        C1 /= ((hsum*frac) + (1.0 - hsum));

        /////Precipitate phase comp.
        double C2  = cbeta_eq + frac*(C1 - calpha_eq);

        //*comp_begin = {((hsum*C2) + ((1.0 - hsum)*C1)), 0.0};
        
        Calpha->x = C1;
        Calpha->y = 0.0;
        
        Cbeta->x = C2;
        Cbeta->y = 0.0;
        
    }
    //__syncthreads();
}

__global__ void Calc_phase_engs(BoxIterator<cufftDoubleComplex> phase_engy_begin,
                                 BoxIterator<cufftDoubleComplex> phase_engy_end,
                                 BoxIterator<cufftDoubleComplex> Calpha,
                                 BoxIterator<cufftDoubleComplex> Cbeta,
                                double *hphisum, double *ftotal, double *c_eq,
                                double *f0, double Am, double Ap, double NV,
                                int FE_form, int engs_out, int output,
                                int TRACK_OBS, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    phase_engy_begin += idx;
    Calpha += idx;
    Cbeta += idx;

    if (phase_engy_begin < phase_engy_end)
    {
        if (FE_form == 0)
        {   
            double c1 = Calpha->x - c_eq[0];
            double c2 = Cbeta->x - c_eq[1];
            
            ////Using a fft pointer at the moment real part to store matrix and imag for precipitate.
            phase_engy_begin->x = Am * c1*c1; 
            phase_engy_begin->y = Ap * c2*c2; 
            
        }
        else if (FE_form == 1)
        {
            double calpha_eq = c_eq[0];
            double cbeta_eq = c_eq[1];
            
            double c1 = Calpha->x; 
            double c2 = Cbeta->x; 
 
            phase_engy_begin->x = (Am * c1*c1); 

            phase_engy_begin->y = ((Ap*c2*c2) + (2.0*(Am*calpha_eq - Ap*cbeta_eq)*c2) +
                                    (Ap*cbeta_eq*cbeta_eq - Am*calpha_eq*calpha_eq));

        }
        
        if (TRACK_OBS == 1 || (engs_out != 0 && output == 1))
            ftotal[idx] += NV*(phase_engy_begin->x * (1.0-hphisum[idx]) + (phase_engy_begin->y * hphisum[idx]));
    }
    //__syncthreads();
}

__global__ void Calc_mu(BoxIterator<cufftDoubleComplex> mu_begin,
                        BoxIterator<cufftDoubleComplex> mu_end, 
                        BoxIterator<cufftDoubleComplex> Calpha, 
                        double *c_eq, double Am, double Ap, int FE_form,
                        long nx, long ny, long nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    mu_begin += idx;
    Calpha += idx;

    if (mu_begin < mu_end)
    {
        if (FE_form == 0)
            *mu_begin = {(2.0*Am*(Calpha->x - c_eq[0])), 0.0}; 
        
        else if (FE_form == 1)
            *mu_begin = {(2.0*Am*Calpha->x), 0.0};

    }
    //__syncthreads();
}

__global__ void Calc_dfchdphi_sv(BoxIterator<cufftDoubleComplex> dfdphi_begin,
                               BoxIterator<cufftDoubleComplex> dfdphi_end,
                               BoxIterator<cufftDoubleComplex> dfdc_begin,
                               BoxIterator<cufftDoubleComplex> Calpha,
                               BoxIterator<cufftDoubleComplex> Cbeta,
                               BoxIterator<cufftDoubleComplex> phase_eng,
                               double *dhdphi, 
                               double Nv, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    
    dfdphi_begin += idx;
    dfdc_begin += idx;
    Calpha += idx;
    Cbeta += idx;
    phase_eng += idx;

    if (dfdphi_begin < dfdphi_end)
    {
        const double tmp = dfdphi_begin->x;
        const double C1 = Calpha->x;
        const double C2 = Cbeta->x;
        const cufftDoubleComplex tmp2 = *phase_eng;
        
        ////imag part has precip value and real has matrix value.
        dfdphi_begin->x = tmp + Nv*(dhdphi[idx] * ((tmp2.y - tmp2.x) + (C1 - C2)*dfdc_begin->x));
        dfdphi_begin->y = 0.0;

    }
    //__syncthreads();
}

__global__ void Calc_dfchdphi(BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                               BoxIterator<cufftDoubleComplex> dfdphi0_end,
                               BoxIterator<cufftDoubleComplex> dfdphi1_begin,
                               BoxIterator<cufftDoubleComplex> dfdphi2_begin,
                               BoxIterator<cufftDoubleComplex> dfdphi3_begin,
                               BoxIterator<cufftDoubleComplex> dfdc_begin,
                               BoxIterator<cufftDoubleComplex> Calpha, 
                               BoxIterator<cufftDoubleComplex> Cbeta, 
                               BoxIterator<cufftDoubleComplex> phase_eng,
                               double *dhdphi0, double *dhdphi1,
                               double *dhdphi2, double *dhdphi3, 
                               double Nv, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    
    dfdphi0_begin += idx;
    dfdphi1_begin += idx;
    dfdphi2_begin += idx;
    dfdphi3_begin += idx;
    dfdc_begin += idx;
    Calpha += idx;
    Cbeta += idx;
    phase_eng += idx;

    if (dfdphi0_begin < dfdphi0_end)
    {
        const double tmp0 = dfdphi0_begin->x;
        const double tmp1 = dfdphi1_begin->x;
        const double tmp2 = dfdphi2_begin->x;
        const double tmp3 = dfdphi3_begin->x;

        const cufftDoubleComplex ph_eng = *phase_eng;
        const double c_alpha = Calpha->x;
        const double c_beta = Cbeta->x;    

        double fcd = Nv*((ph_eng.y - ph_eng.x) + (c_alpha - c_beta)*dfdc_begin->x);

        *dfdphi0_begin = {(tmp0 + dhdphi0[idx]*fcd), 0.0};
        *dfdphi1_begin = {(tmp1 + dhdphi1[idx]*fcd), 0.0};
        *dfdphi2_begin = {(tmp2 + dhdphi2[idx]*fcd), 0.0};
        *dfdphi3_begin = {(tmp3 + dhdphi3[idx]*fcd), 0.0};

    }
    //__syncthreads();
}

__global__ void Calc_fchem(double *fchem, double *hphisum, double *fbeta, double *falpha, 
                           long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    if (idx < nx*ny*nz)
    {
        fchem[idx] = hphisum[idx]*fbeta[idx] + (1.0 - hphisum[idx])*falpha[idx];

    }
    //__syncthreads();
}

__global__ void Update_phi(BoxIterator<cufftDoubleComplex> phi0_begin, 
                           BoxIterator<cufftDoubleComplex> phi0_end,
                           BoxIterator<cufftDoubleComplex> phi1_begin,
                           BoxIterator<cufftDoubleComplex> phi2_begin,
                           BoxIterator<cufftDoubleComplex> phi3_begin,
                           BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                           BoxIterator<cufftDoubleComplex> dfdphi1_begin,
                           BoxIterator<cufftDoubleComplex> dfdphi2_begin,
                           BoxIterator<cufftDoubleComplex> dfdphi3_begin,
                           double *kappa, double L, double dt,
                           double dx, double dy, double dz,
                           long nx, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    double n[3] = {0.0};
    double kpow2 = 0.0;

    phi0_begin += idx; 
    phi1_begin += idx; 
    phi2_begin += idx; 
    phi3_begin += idx; 
    dfdphi0_begin += idx;
    dfdphi1_begin += idx;
    dfdphi2_begin += idx;
    dfdphi3_begin += idx;

    if (phi0_begin < phi0_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], phi0_begin); 
        kpow2 = (n[0]*n[0] + n[1]*n[1] + n[2]*n[2]);
        
        double tmp = L*dt;
        //double denom = (1.0+(L*2.0*kappa[0]*kpow2*dt));
        double denom = (1.0+(L*kappa[0]*kpow2*dt));
        cufftDoubleComplex df0 = *dfdphi0_begin;
        cufftDoubleComplex df1 = *dfdphi1_begin;
        cufftDoubleComplex df2 = *dfdphi2_begin;
        cufftDoubleComplex df3 = *dfdphi3_begin;
        cufftDoubleComplex phi0 = *phi0_begin;
        cufftDoubleComplex phi1 = *phi1_begin;
        cufftDoubleComplex phi2 = *phi2_begin;
        cufftDoubleComplex phi3 = *phi3_begin;
    
        phi0.x -= tmp*df0.x;
        phi1.x -= tmp*df1.x;
        phi2.x -= tmp*df2.x;
        phi3.x -= tmp*df3.x;
        
        phi0.y -= tmp*df0.y; 
        phi1.y -= tmp*df1.y; 
        phi2.y -= tmp*df2.y; 
        phi3.y -= tmp*df3.y; 
        
        phi0.x /= denom; 
        phi1.x /= denom; 
        phi2.x /= denom; 
        phi3.x /= denom; 

        phi0.y /= denom;
        phi1.y /= denom;
        phi2.y /= denom;
        phi3.y /= denom;

        *phi0_begin = phi0;
        *phi1_begin = phi1;
        *phi2_begin = phi2;
        *phi3_begin = phi3;
         
    }
    //__syncthreads();
}

__global__ void Update_phi_sv(BoxIterator<cufftDoubleComplex> phi0_begin, 
                           BoxIterator<cufftDoubleComplex> phi0_end,
                           BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                           double *kappa, double L, double dt,
                           double dx, double dy, double dz,
                           long nx, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    double n[3] = {0.0};
    double kpow2 = 0.0;

    phi0_begin += idx; 
    dfdphi0_begin += idx;

    if (phi0_begin < phi0_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], phi0_begin);
        kpow2 = (n[0]*n[0] + n[1]*n[1] + n[2]*n[2]);
        
        double tmp = L*dt;
        //double denom = (1.0+(L*2.0*kappa[0]*kpow2*dt));
        double denom = (1.0+(L*kappa[0]*kpow2*dt));
        cufftDoubleComplex df = *dfdphi0_begin;
        cufftDoubleComplex phi = *phi0_begin;
    
        phi.x -= tmp*df.x;
        
        phi.y -= tmp*df.y; 
        
        phi.x /= denom; 

        phi.y /= denom;

        *phi0_begin = phi;
         
    }
    //__syncthreads();
}

__global__ void Update_comp0(BoxIterator<cufftDoubleComplex> comp_begin, 
                            BoxIterator<cufftDoubleComplex> comp_end,
                            BoxIterator<cufftDoubleComplex> dfdc_begin,
                            BoxIterator<cufftDoubleComplex> dfdc_end,
                            double Mob, double dt, double dx, double dy, double dz,
                            long nx, long ny, long nz)
{
 
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    double n[3] = {0.0};
    double kpow2 = 0.0;
    
    comp_begin += idx; dfdc_begin += idx;
    if (comp_begin < comp_end)
    {  
        get_kx_ky_kz(&n[0], &n[1], &n[2], comp_begin);
        kpow2 = (n[0]*n[0] + n[1]*n[1] + n[2]*n[2]);
        
        double tmp = Mob*dt*kpow2;
        cufftDoubleComplex dfc = *dfdc_begin;

        comp_begin->x -= tmp*dfc.x;
        comp_begin->y -= tmp*dfc.y;
            
    }
    //__syncthreads();
}

__global__ void Update_comp1(BoxIterator<cufftDoubleComplex> comp_begin, 
                            BoxIterator<cufftDoubleComplex> comp_end,
                            BoxIterator<cufftDoubleComplex> dfdc_begin,
                            BoxIterator<cufftDoubleComplex> dfdc_end,
                            double dt, long nx, long ny, long nz)
{
 
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    
    comp_begin += idx; dfdc_begin += idx;
    if (comp_begin < comp_end)
    {  
        cufftDoubleComplex dfc = *dfdc_begin;

        comp_begin->x +=  (dt * dfc.x);
        comp_begin->y +=  (dt * dfc.y);
            
    }
    //__syncthreads();
}
__global__ void Update_comp2(BoxIterator<cufftDoubleComplex> comp_begin, 
                            BoxIterator<cufftDoubleComplex> comp_end,
                            BoxIterator<cufftDoubleComplex> Calpha_begin,
                            BoxIterator<cufftDoubleComplex> Cbeta_begin,
                            const double* __restrict__ hphisum)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nz = nz_d; const int ny = ny_d;
    long idx = k + (nz * (j + (i*ny))); 
    comp_begin += idx; Calpha_begin += idx;
    Cbeta_begin += idx;
    if (comp_begin >= comp_end)
        return;
    
    const double hsum = hphisum[idx];
    *comp_begin = {((hsum*Cbeta_begin->x) + ((1.0-hsum)*Calpha_begin->x)), 0.0};

}

__global__ void Normalize_strd(cufftDoubleComplex *x, long nx, long ny, int flag=0)
{
    long int gid = (long)threadIdx.x + (long)blockDim.x * (long)blockIdx.x;
    long int stride = (long)blockDim.x * (long)gridDim.x;
    long int idx;

    long len;
    len = nx*ny;
    for (idx=gid; idx<len; idx+=stride)
    {
        x[idx].x /= (double)(len);
        x[idx].y /= (double)(len);
        if (flag ==1 && x[idx].x > (double)(len))
            printf("after:%ld\t%lf\t%lf\n",idx,x[idx].x,x[idx].y);
    }
    //__syncthreads();
}

//__global__ void SaveReal(double *temp, cufftDoubleComplex *x, int ny_d)
//{
//
//    int i = threadIdx.x + blockIdx.x*blockDim.x;
//    int j = threadIdx.y + blockIdx.y*blockDim.y;
//
//    int idx = (j + i*ny_d);
//
//    temp[idx] = x[idx].x;
//    //__syncthreads();
//}

__global__ void Find_err_matrix(double *temp,cufftDoubleComplex *comp, long ny, long nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 

    temp[idx] = fabs(comp[idx].x - temp[idx]);
    //__syncthreads();

}

void Evolve(cudaLibXtDesc *comp, cudaLibXtDesc *phi0, cudaLibXtDesc *phi1,
            cudaLibXtDesc *phi2, cudaLibXtDesc *phi3, cudaLibXtDesc *dfdc)
{
    
    auto [comp_begin_r, comp_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)comp->descriptor->data[0]);

    auto [comp_begin_f, comp_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)comp->descriptor->data[0]);
    
    auto [phi0_begin_r, phi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi0->descriptor->data[0]);

    auto [phi0_begin_f, phi0_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi0->descriptor->data[0]);
    
    auto [phi1_begin_r, phi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi1->descriptor->data[0]);

    auto [phi1_begin_f, phi1_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi1->descriptor->data[0]);
    
    auto [phi2_begin_r, phi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi2->descriptor->data[0]);

    auto [phi2_begin_f, phi2_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi2->descriptor->data[0]);

    auto [phi3_begin_r, phi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi3->descriptor->data[0]);

    auto [phi3_begin_f, phi3_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi3->descriptor->data[0]);
 
    auto [dfdc_begin_r, dfdc_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)dfdc->descriptor->data[0]);

    auto [dfdc_begin_f, dfdc_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)dfdc->descriptor->data[0]);
    

    int loop_condition;
    
    CUFFT_CHECK(cufftXtMalloc(plan, &gradmux, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    CUFFT_CHECK(cufftXtMalloc(plan, &gradmuy, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    CUFFT_CHECK(cufftXtMalloc(plan, &gradmuz, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
     
    CUFFT_CHECK(cufftXtMalloc(plan, &dfdphi0, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    
    if (nof_variants == 1)
    {
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &dfdphi1, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &dfdphi2, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &dfdphi3, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    }
    else if (nof_variants == 4)
    {
        CUFFT_CHECK(cufftXtMalloc(plan, &dfdphi1, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
        CUFFT_CHECK(cufftXtMalloc(plan, &dfdphi2, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
        CUFFT_CHECK(cufftXtMalloc(plan, &dfdphi3, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    }
    if (engs_out == 1 || TRACK_TIME > 0)
    {
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi0x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi0y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi0z, CUFFT_XT_FORMAT_INPLACE));
        
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi1x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi1y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi1z, CUFFT_XT_FORMAT_INPLACE));
        
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi2x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi2y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi2z, CUFFT_XT_FORMAT_INPLACE));
        
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi3x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi3y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &gradphi3z, CUFFT_XT_FORMAT_INPLACE));
    }
    else
    {
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi0x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi0y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi0z, CUFFT_XT_FORMAT_INPLACE));
        
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi1x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi1y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi1z, CUFFT_XT_FORMAT_INPLACE));
 
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi2x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi2y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi2z, CUFFT_XT_FORMAT_INPLACE));
        
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi3x, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi3y, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &gradphi3z, CUFFT_XT_FORMAT_INPLACE));
    }
    
    auto [gradphi0x_begin_r, gradphi0x_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi0x->descriptor->data[0]);
     
    auto [gradphi0y_begin_r, gradphi0y_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi0y->descriptor->data[0]);
    
    auto [gradphi0z_begin_r, gradphi0z_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi0z->descriptor->data[0]);
    
    auto [gradphi0x_begin_f, gradphi0x_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi0x->descriptor->data[0]);

    auto [gradphi0y_begin_f, gradphi0y_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi0y->descriptor->data[0]); 
    
    auto [gradphi0z_begin_f, gradphi0z_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi0z->descriptor->data[0]); 
    
    auto [gradphi1x_begin_r, gradphi1x_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi1x->descriptor->data[0]);
     
    auto [gradphi1y_begin_r, gradphi1y_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi1y->descriptor->data[0]);
    
    auto [gradphi1z_begin_r, gradphi1z_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi1z->descriptor->data[0]);
    
    auto [gradphi1x_begin_f, gradphi1x_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi1x->descriptor->data[0]);

    auto [gradphi1y_begin_f, gradphi1y_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi1y->descriptor->data[0]); 
    
    auto [gradphi1z_begin_f, gradphi1z_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi1z->descriptor->data[0]); 
    
    auto [gradphi2x_begin_r, gradphi2x_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi2x->descriptor->data[0]);
     
    auto [gradphi2y_begin_r, gradphi2y_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi2y->descriptor->data[0]);
    
    auto [gradphi2z_begin_r, gradphi2z_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi2z->descriptor->data[0]);
    
    auto [gradphi2x_begin_f, gradphi2x_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi2x->descriptor->data[0]);

    auto [gradphi2y_begin_f, gradphi2y_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi2y->descriptor->data[0]); 
    
    auto [gradphi2z_begin_f, gradphi2z_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi2z->descriptor->data[0]); 
    
    auto [gradphi3x_begin_r, gradphi3x_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi3x->descriptor->data[0]);
     
    auto [gradphi3y_begin_r, gradphi3y_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi3y->descriptor->data[0]);
    
    auto [gradphi3z_begin_r, gradphi3z_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                             rank, size, nx, ny, nz, 
                                                              (cufftDoubleComplex*)gradphi3z->descriptor->data[0]);
    
    auto [gradphi3x_begin_f, gradphi3x_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi3x->descriptor->data[0]);

    auto [gradphi3y_begin_f, gradphi3y_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi3y->descriptor->data[0]); 
    
    auto [gradphi3z_begin_f, gradphi3z_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                                            (cufftDoubleComplex*)gradphi3z->descriptor->data[0]); 

    auto [gradmux_begin_r, gradmux_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmux->descriptor->data[0]);

    auto [gradmux_begin_f, gradmux_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmux->descriptor->data[0]);
    
    auto [gradmuy_begin_r, gradmuy_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmuy->descriptor->data[0]);

    auto [gradmuy_begin_f, gradmuy_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmuy->descriptor->data[0]);
    
    auto [gradmuz_begin_r, gradmuz_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmuz->descriptor->data[0]);

    auto [gradmuz_begin_f, gradmuz_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)gradmuz->descriptor->data[0]);
     
    auto [dfdphi0_begin_r, dfdphi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi0->descriptor->data[0]);

    auto [dfdphi0_begin_f, dfdphi0_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi0->descriptor->data[0]);

    auto [dfdphi1_begin_r, dfdphi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi1->descriptor->data[0]);

    auto [dfdphi1_begin_f, dfdphi1_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi1->descriptor->data[0]);

    auto [dfdphi2_begin_r, dfdphi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi2->descriptor->data[0]);

    auto [dfdphi2_begin_f, dfdphi2_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi2->descriptor->data[0]);

    auto [dfdphi3_begin_r, dfdphi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi3->descriptor->data[0]);

    auto [dfdphi3_begin_f, dfdphi3_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi3->descriptor->data[0]);
     
    CUDA_CHECK(cudaMalloc((void**)&comp_avg, 2*sizeof(*comp_avg)));
    CUDA_CHECK(cudaMemset(comp_avg, 0.0, 2*sizeof(*min_comp)));
    comp_avg_h = (double*) calloc (2, sizeof(double));
    persts_h = (double*) calloc (6, sizeof(double));

    if (elast_int == 1)
    {
        CUDA_CHECK(cudaMalloc((void**)&Chom, 3*sizeof(double)));
        CUDA_CHECK(cudaMalloc((void**)&Chet, 3*sizeof(double)));
        
        Celas<<<1,1>>>(Chom, Chet, Chom11, Chom12, Chom44, Chet11, Chet12, Chet44);
        
        eigsts_h = (double*) calloc (3, sizeof(double));
        
        CUDA_CHECK(cudaMalloc((void**)&avgeigsts, 3*sizeof(double)));
        CUDA_CHECK(cudaMalloc((void**)&avgpersts, 6*sizeof(double)));
        
        CUDA_CHECK(cudaMemset(avgeigsts, 0.0, 3*sizeof(*avgpersts)));
        CUDA_CHECK(cudaMemset(avgpersts, 0.0, 6*sizeof(*avgpersts)));
         
        CUDA_CHECK(cudaMalloc((void**)&hom_strain_v, 6*sizeof(double)));
        CUDA_CHECK(cudaMemset(hom_strain_v, 0.0, 6*sizeof(double)));

        hom_strain_h = (double*) calloc(6, sizeof(double));
        
        if (inhom != 1.0)
        {
            if (norm_calc == 1)
            {
                CUDA_CHECK(cudaMalloc((void**)&disperr, 3*sizeof(double)));
                CUDA_CHECK(cudaMemset(disperr, 0.0, 3*sizeof(*disperr)));

                disperr_h = (double*) calloc (3, sizeof(double));
            }

            CUFFT_CHECK(cufftXtMalloc(plan, &str_v0_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            CUFFT_CHECK(cufftXtMalloc(plan, &str_v1_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            CUFFT_CHECK(cufftXtMalloc(plan, &str_v2_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            CUFFT_CHECK(cufftXtMalloc(plan, &str_v3_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            CUFFT_CHECK(cufftXtMalloc(plan, &str_v4_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            CUFFT_CHECK(cufftXtMalloc(plan, &str_v5_d, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
            
            CUFFT_CHECK(cufftXtMalloc(plan, &unewx, CUFFT_XT_FORMAT_INPLACE));
            CUFFT_CHECK(cufftXtMalloc(plan, &unewy, CUFFT_XT_FORMAT_INPLACE));
            CUFFT_CHECK(cufftXtMalloc(plan, &unewz, CUFFT_XT_FORMAT_INPLACE));
         
            CUDA_CHECK(cudaMalloc((void**)&Cavg, 3*sizeof(double)));
            CUDA_CHECK(cudaMalloc((void**)&S_d, 3*sizeof(double)));

            CUDA_CHECK(cudaMemset(Cavg, 0.0, 3*sizeof(*Cavg)));
            CUDA_CHECK(cudaMemset(S_d, 0.0, 3*sizeof(*S_d))); 
        }
        
        if (noise_int != 0)
        {
            CUDA_CHECK(cudaMalloc((void**)&noise_array, double_size));
            CUDA_CHECK(cudaMallocManaged((void**)&noise_mean, sizeof(double)));
            CUDA_CHECK(cudaMemset(noise_mean, 0.0, sizeof(*noise_mean)));
            CUDA_CHECK(cudaMemset(noise_array, 0.0, double_size)); 
        }

    }

    //cudaGetLastError();
    //if (rank == 0)
    //    printf("CUDA error status before starting the time loop in evolve : %s\n",
    //                cudaGetErrorString(Err));

    iteration = 1;
    loop_condition = 1;
    
    if (testing == 1 && nof_variants == 4) 
    {
        KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
        Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dfdphi0");  
        
        KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi1_begin_r, dfdphi1_end_r, nx,ny,nz);
        Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dfdphi1");  
        
        KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi2_begin_r, dfdphi2_end_r, nx,ny,nz);
        Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dfdphi2");  
        
        KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi3_begin_r, dfdphi3_end_r, nx,ny,nz);
        Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dfdphi3");  

    }
    else
    {
        KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
        Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dfdphi0");
    }


    //Time loop
    if (noise_int != 0)
        init_rng<<<Gridsize, Blocksize>>>(d_states, seed, nx, ny, nz);
    clock_t start_time, end_time;
    cudaEvent_t start, stop;
    double cpu_time;
    float local_ms = 0.0;

    CUDA_CHECK(cudaEventCreate(&start));
    CUDA_CHECK(cudaEventCreate(&stop));
    start_time = MPI_Wtime();
    CUDA_CHECK(cudaEventRecord(start, 0));

    for (count = initcount; count <= num_steps; count++)
    {
        ////Smoothening 
        if (Smoothening == 1)
        {
            if (comp_evolution == 1);
                temp1= 1;
            if (elast_int == 1)
            {
                temp2= 1;
                time_elast += Smoothening_steps;
            }

            if (count < Smoothening_steps)
            {
                comp_evolution = 0;
                elast_int = 0;
            }

            else
            {
                if (temp1== 1)
                    comp_evolution = 1;
                if (temp2== 1)
                    elast_int = 1;
                Smoothening = 0;
            }
        }
        
        TRACK_OBS = 0;
        if (TRACK_TIME > 0)
        {
            if (count % TRACK_TIME == 0)
            {
                TRACK_OBS =1;
                CUDA_CHECK(cudaMemset(Avg_ptr, 0.0, 4*sizeof(double))); 
            }
        }
        
        OUTPUT = 0;
        if (((count % t_prof1)==0 && count <= numsteps_prof1) ||
            ((count % t_prof2)==0 && count <= numsteps_prof2) ||
            ((count % t_prof3)==0 && count > numsteps_prof2) ||
            (count == num_steps) || (loop_condition == 0))
        {
            OUTPUT = 1;
            if (rank == 0)
                printf("\nIteration No: %d\n",count);
            MPI_Barrier(comm);
            
            /*
            ////Writing output
            Output_Conf(comp, phi0, phi1, phi2, phi3, count);
            if (VTK_out == 1)
            {
                if (rank == 0)
                    printf ("Output is written to file \n");
            }
            */

        }

        if (count > num_steps || loop_condition == 0)
            break;
        ////Calc hphisum and dhdphi.
        if (nof_variants == 1)
        {
            dfdphi0->subFormat = CUFFT_XT_FORMAT_INPLACE;
             
            if (TRACK_OBS == 1)
            {
                CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
                CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
                Calc_hsum_dhdphi_sv<<<Gridsize,Blocksize>>>(hphisum, dhdphi0, dummy, dummy2, phi0_begin_r, phi0_end_r,
                                                        dfdphi0_begin_r, omega, engs_out, OUTPUT, TRACK_OBS, ny,nz);
                
                ///NOTE:Avg_ptr[0] is volume fraction.
                cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &Avg_ptr[0], nx_local*ny*nz);
                //cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &ftotavg[0], nx_local*ny*nz);
                //ncclAllReduce(vol_frac, vol_frac, 1, ncclDouble, ncclSum, nccl_comm, 0);
                
                //CUDA_CHECK(cudaMemcpy(&vf_h, vol_frac, sizeof(double), cudaMemcpyDeviceToHost));
            }
            else 
                Calc_hsum_dhdphi_sv<<<Gridsize,Blocksize>>>(hphisum, dhdphi0, ftotal, dummy2, phi0_begin_r, phi0_end_r,
                                                            dfdphi0_begin_r, omega, engs_out, OUTPUT, TRACK_OBS, ny,nz);


        }
        else if (nof_variants == 4)
        {
            
            Calc_hphisum_dhdphi<<<Gridsize, Blocksize>>>(hphisum,dhdphi0, dhdphi1,
                                                         dhdphi2, dhdphi3, dummy2, phi0_begin_r, phi0_end_r,
                                                         phi1_begin_r, phi2_begin_r, phi3_begin_r,
                                                         TRACK_OBS, ny, nz); 
            if (TRACK_OBS == 1)
                cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &Avg_ptr[0], nx_local*ny*nz);
        }
     
        if (OUTPUT == 1 && testing == 1 && nof_variants == 4)
        {
            KernelC2R<<<Gridsize, Blocksize>>> (dummy, phi0_begin_r, phi0_end_r, nx,ny,nz);
            Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"phi0");  
            
            KernelC2R<<<Gridsize, Blocksize>>> (dummy, phi1_begin_r, phi1_end_r, nx,ny,nz);
            Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"phi1");  
            
            KernelC2R<<<Gridsize, Blocksize>>> (dummy, phi2_begin_r, phi2_end_r, nx,ny,nz);
            Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"phi2");  
            
            KernelC2R<<<Gridsize, Blocksize>>> (dummy, phi3_begin_r, phi3_end_r, nx,ny,nz);
            Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"phi3");  
            
            Print_max_avg(t_storage_bytes, t_storage, hphisum, Vf, num_items, sizescale, (char*)"hphisum");  
        }
        else if (OUTPUT == 1 && testing == 1 && nof_variants == 1)
        {
            KernelC2R<<<Gridsize, Blocksize>>> (dummy, phi0_begin_r, phi0_end_r, nx,ny,nz);
            Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"phi0");  
            
            Print_max_avg(t_storage_bytes, t_storage, hphisum, Vf, num_items, sizescale, (char*)"hphisum");  

        }

        ////Calc Phase comp, Phase energies & mu_bar.
        if (comp_evolution == 1)
        {
            dfdc->subFormat = CUFFT_XT_FORMAT_INPLACE; 
            gradmux->subFormat = CUFFT_XT_FORMAT_INPLACE;
            gradmuy->subFormat = CUFFT_XT_FORMAT_INPLACE;
            gradmuz->subFormat = CUFFT_XT_FORMAT_INPLACE;
            
            ////Phase comp is stored in grad vars.
            Calc_phase_comp<<<Gridsize, Blocksize>>>(gradmux_begin_r,  gradmuy_begin_r, comp_begin_r, comp_end_r, hphisum,
                                                     c_eq, f0, nx,ny,nz);
            
            if (TRACK_OBS == 1)
            {
                if (nof_variants == 4)
                    CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));

                Calc_phase_engs<<<Gridsize, Blocksize>>>(gradmuz_begin_r, gradmuz_end_r,gradmux_begin_r, gradmuy_begin_r, 
                                                            hphisum, dummy, c_eq, f0, Am, Ap, Nv, FE_form, engs_out, 
                                                            OUTPUT, TRACK_OBS, nx_local,ny,nz);
                
                ////NOTE:Avg_ptr[1] is fbulk.
                if (nof_variants == 1)
                    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &Avg_ptr[1], nx_local*ny*nz);
            }

            else
                ////Phase energy is stored in gradmuz.
                Calc_phase_engs<<<Gridsize, Blocksize>>>(gradmuz_begin_r, gradmuz_end_r,gradmux_begin_r, gradmuy_begin_r, 
                                                            hphisum, ftotal, c_eq, f0, Am, Ap, Nv, FE_form, engs_out, 
                                                            OUTPUT, TRACK_OBS, nx_local,ny,nz);
            
            
            ////Using dfdc as mu_bar and then later actual dfdc. 
            ////Phase comp is stored in gradmux&y.
            Calc_mu<<<Gridsize,Blocksize>>>(dfdc_begin_r, dfdc_end_r, gradmux_begin_r, c_eq, Am, Ap, 
                                            FE_form, nx,ny,nz);
             
        }
        ////Instead of having dgdphi & dfdchdphi pointers using dfdphi. 
        if (nof_variants == 1)
        { 
            //dfdphi0->subFormat = CUFFT_XT_FORMAT_INPLACE;
            //
            //Calc_dgdphi_sv<<<Gridsize,Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r, phi0_begin_r,
            //                                       omega, nx,ny,nz);
            
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dgdphi");  

            }
            
            if(comp_evolution == 1)
            {
                Calc_dfchdphi_sv<<<Gridsize, Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r, dfdc_begin_r,
                                                            gradmux_begin_r, gradmuy_begin_r, gradmuz_begin_r, dhdphi0,
                                                            Nv, nx,ny,nz);
            }
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dg_dfchdphi");  

            }
        }
        else if (nof_variants == 4)
        {
            
            dfdphi0->subFormat = CUFFT_XT_FORMAT_INPLACE;
            dfdphi1->subFormat = CUFFT_XT_FORMAT_INPLACE;
            dfdphi2->subFormat = CUFFT_XT_FORMAT_INPLACE;
            dfdphi3->subFormat = CUFFT_XT_FORMAT_INPLACE;
            
            //// Only 4th order with cross penality 
            if (theta2 < 0.0)
            {
                if (TRACK_OBS == 1)
                {
                    Calc_dgdphi<<<Gridsize,Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r, dfdphi1_begin_r, dfdphi2_begin_r, 
                                                        dfdphi3_begin_r, phi0_begin_r, phi1_begin_r, phi2_begin_r, phi3_begin_r, 
                                                        omega,theta, dummy, engs_out, TRACK_OBS, OUTPUT, ny,nz);
                    
                    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &Avg_ptr[1], nx_local*ny*nz);
                }
                else
                    Calc_dgdphi<<<Gridsize,Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r, dfdphi1_begin_r, dfdphi2_begin_r, 
                                                        dfdphi3_begin_r, phi0_begin_r, phi1_begin_r, phi2_begin_r, phi3_begin_r, 
                                                        omega,theta, ftotal, engs_out, TRACK_OBS, OUTPUT, ny,nz);
            }
            
            //// With 6th order to avoid seggregation. if don't need 6th order make theta2 to be negative.
            else
            {
                Calc_dgdphi2<<<Gridsize,Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r, dfdphi1_begin_r, dfdphi2_begin_r, 
                                                    dfdphi3_begin_r, phi0_begin_r, phi1_begin_r, phi2_begin_r, phi3_begin_r, 
                                                    omega,theta,theta2, ny,nz);
            }
             
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dgdphi0");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi1_begin_r, dfdphi1_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dgdphi1");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi2_begin_r, dfdphi2_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dgdphi2");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi3_begin_r, dfdphi3_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dgdphi3");  

            }
            
            
            if(comp_evolution == 1) 
                Calc_dfchdphi<<<Gridsize, Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r,
                                                        dfdphi1_begin_r, dfdphi2_begin_r, dfdphi3_begin_r,
                                                        dfdc_begin_r, gradmux_begin_r, gradmuy_begin_r,
                                                        gradmuz_begin_r, dhdphi0, dhdphi1, dhdphi2, dhdphi3,
                                                        Nv, nx,ny,nz);
            
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi0_begin_r, dfdphi0_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dg_dfchdphi0");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi1_begin_r, dfdphi1_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dg_dfdphi1");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi2_begin_r, dfdphi2_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dg_dfdphi2");  
                
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdphi3_begin_r, dfdphi3_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"dg_dfdphi3");  

            }
        }
        
        ////Calc gradmu.
        if (comp_evolution == 1)
        {
            ////TODO:testing.
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdc_begin_r, dfdc_end_r, nx,ny,nz);
                Print_max_avg(t_storage_bytes, t_storage, dummy, Vf, num_items, sizescale, (char*)"mu");  

            }
            //// TODO:Testing ends.
            if (Method == 0 || Method == 1) 
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, dfdc, dfdc, CUFFT_FORWARD));
                cufftXtExecDescriptor(plan, dfdc, dfdc, CUFFT_FORWARD);
            
            if (Method == 1)
            { 
                gradmux->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradmuy->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradmuz->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                
                Calc_Grad<<<Gridsize,Blocksize>>>(gradmux_begin_f, gradmux_end_f,
                                                  gradmuy_begin_f, gradmuy_end_f,
                                                  gradmuz_begin_f, gradmuz_end_f,
                                                  dfdc_begin_f, dfdc_end_f,
                                                  dx,dy,dz, 
                                                  nx_start,nx,ny,nz);
                
                
                cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_INVERSE);
                cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_INVERSE);
                cufftXtExecDescriptor(plan, gradmuz, gradmuz, CUFFT_INVERSE);
                
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_INVERSE));
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_INVERSE));
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmuz, gradmuz, CUFFT_INVERSE));
                 
                Normalize<<< Gridsize, Blocksize >>>(gradmux_begin_r, gradmux_end_r,nx,ny,nz, Imag);
                Normalize<<< Gridsize, Blocksize >>>(gradmuy_begin_r, gradmuy_end_r,nx,ny,nz, Imag);
                Normalize<<< Gridsize, Blocksize >>>(gradmuz_begin_r, gradmuz_end_r,nx,ny,nz, Imag);
                 
                ////TODO:testing.
                if (testing == 1 && OUTPUT == 1)
                {
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmux_begin_r, gradmux_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"gradmux");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuy_begin_r, gradmuy_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"gradmuy");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuz_begin_r, gradmuz_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"gradmuz");  
                    
                }
                //// TODO:Testing ends.
                
                ////Reusing the grad pointers as dfdcxyz.  
                Calc_dfdcxyz<<<Gridsize, Blocksize>>>(gradmux_begin_r, gradmux_end_r, 
                                                      gradmuy_begin_r, 
                                                      gradmuz_begin_r,  hphisum,
                                                      Am, Ap, diffusivity); 
                
                if (testing == 1 && OUTPUT == 1)
                {
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmux_begin_r, gradmux_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"dfdcx");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuy_begin_r, gradmuy_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"dfdcy");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuz_begin_r, gradmuz_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"dfdcz");  
                    
                }
                //// TODO:Testing ends.
                
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_FORWARD));
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_FORWARD));
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, gradmuz, gradmuz, CUFFT_FORWARD));
                
                cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_FORWARD);
                cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_FORWARD);
                cufftXtExecDescriptor(plan, gradmuz, gradmuz, CUFFT_FORWARD);
                
                ////Calc actual dfdc for the comp evolution.
                Calc_dfdc<<<Gridsize,Blocksize>>>(dfdc_begin_f, dfdc_end_f, gradmux_begin_f, gradmuy_begin_f,
                                                   gradmuz_begin_f, dx,dy,dz);
                if (testing == 1 && OUTPUT == 1)
                {
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, dfdc_begin_f, dfdc_end_f, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"dfdc_f");
                }
            }
            
            if (Method == 0 || Method == 1) 
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, comp, comp, CUFFT_FORWARD));
                cufftXtExecDescriptor(plan, comp, comp, CUFFT_FORWARD);

            // The diffusivity in the Input params is the mobility in case of M1.
            if (Method == 0)
                Update_comp0<<<Gridsize,Blocksize>>>(comp_begin_f, comp_end_f, dfdc_begin_f, dfdc_end_f,
                                                     Mobility,dt, dx,dy,dz, nx,ny,nz);
            
            else if ( Method == 1)
                Update_comp1<<<Gridsize,Blocksize>>>(comp_begin_f, comp_end_f, dfdc_begin_f, dfdc_end_f,
                                                     dt, nx,ny,nz);
            else if (Method == 2)
            { 
                //// Using grad vars as phase specific comp
                cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_FORWARD);
                cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_FORWARD);
                
                if (testing == 1 && OUTPUT == 1)
                { 
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmux_begin_f, gradmux_end_f, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"Calpha_f");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuy_begin_f, gradmuy_end_f, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"Cbeta_f");  
                }
                //// Using grad vars as phase specific comp
                Update_PhaseComp<<<Gridsize,Blocksize>>>(gradmux_begin_f, gradmux_end_f, gradmuy_begin_f,diffusivity, dt);
                
                cufftXtExecDescriptor(plan, gradmux, gradmux, CUFFT_INVERSE);
                cufftXtExecDescriptor(plan, gradmuy, gradmuy, CUFFT_INVERSE);
            
                Normalize<<< Gridsize, Blocksize >>>(gradmux_begin_r, gradmux_end_r,nx,ny,nz,Imag);
                Normalize<<< Gridsize, Blocksize >>>(gradmuy_begin_r, gradmuy_end_r,nx,ny,nz,Imag);
                
                if (testing == 1 && OUTPUT == 1)
                { 
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmux_begin_r, gradmux_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"Calpha");  
                    
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, gradmuy_begin_r, gradmuy_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"Cbeta");  
                }

                Update_comp2<<<Gridsize,Blocksize>>>(comp_begin_r, comp_end_r, gradmux_begin_r, gradmuy_begin_r,hphisum);
                
                if (testing == 1 && OUTPUT == 1)
                { 
                    KernelC2R<<<Gridsize, Blocksize>>> (dummy, comp_begin_r, comp_end_r, nx,ny,nz);
                    CUDA_CHECK(cudaDeviceSynchronize()); 
                    Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"Comp");
                }

            }
            
            /*
            if (testing == 1 && OUTPUT == 1)
            {
                KernelC2R<<<Gridsize, Blocksize>>> (dummy, comp_begin_f, comp_end_f, nx,ny,nz);
                CUDA_CHECK(cudaDeviceSynchronize()); 
                Print_max_avg(t_storage_bytes,t_storage,dummy,Vf,num_items, sizescale,(char*)"comp_f");  
            }*/
            
            
        }
        
        ////Finding elastic driving force in real space
        if (elast_int == 1 && count >= time_elast )
        {
            if (Method != 2)
            {
                gradmux->subFormat = CUFFT_XT_FORMAT_INPLACE;
                gradmuy->subFormat = CUFFT_XT_FORMAT_INPLACE;
                gradmuz->subFormat = CUFFT_XT_FORMAT_INPLACE;
            }
            
            if (appl_stress == 1 && count == time_sa)
                CUDA_CHECK(cudaMemcpy(sigappl_v, sigappl_v_h, 6*sizeof(double), cudaMemcpyHostToDevice));

            if (inhom == 1.0)
            {
                //if (rank == 0) printf("Solving using Hom Elas\n");
                HomElast(gradmux, gradmuy, gradmuz, dfdphi0, dfdphi1, dfdphi2, dfdphi3);
            }
            else
            {

                if (count == time_elast)
                    Calc_uzero(gradmux, gradmuy, gradmuz);
                
                InhomElast(dfdphi0, dfdphi1, dfdphi2, dfdphi3, gradmux,gradmuy,gradmuz, unewx,unewy,unewz,
                           str_v0_d,str_v1_d, str_v2_d, str_v3_d, str_v4_d, str_v5_d);
            }

        }
                   
        //CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_FORWARD));
        //CUFFT_CHECK(cufftXtExecDescriptor(plan, dfdphi0, dfdphi0, CUFFT_FORWARD));
        cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_FORWARD);
        cufftXtExecDescriptor(plan, dfdphi0, dfdphi0, CUFFT_FORWARD);

        if (nof_variants == 4)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi1, phi1, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi2, phi2, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi3, phi3, CUFFT_FORWARD));
            
            CUFFT_CHECK(cufftXtExecDescriptor(plan, dfdphi1, dfdphi1, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, dfdphi2, dfdphi2, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, dfdphi3, dfdphi3, CUFFT_FORWARD));
        }
        
        if ((engs_out == 1 && OUTPUT == 1) || TRACK_OBS == 1)
        {
            if (nof_variants == 1)
            {
                gradphi0x->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi0y->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi0z->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                 
                Calc_Gradphi_sv<<<Gridsize,Blocksize>>>(gradphi0x_begin_f, gradphi0y_begin_f, gradphi0z_begin_f,
                                                        phi0_begin_f, nx_local, ny,nz);

                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0x, gradphi0x, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0y, gradphi0y, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0z, gradphi0z, CUFFT_INVERSE));

                Normalize_3d<<<Gridsize, Blocksize>>>(gradphi0x_begin_r, gradphi0x_end_r, gradphi0y_begin_r, gradphi0z_begin_r, 
                                                      nx,ny,nz);
                
                if (engs_out == 1)
                {
                    ////NOTE:dummy2 is reused here for felas engs_out.
                    Calc_fgrad_addfelas_sv<<<Gridsize,Blocksize>>>(ftotal, dummy2, gradphi0x_begin_r, gradphi0y_begin_r, 
                                                                   gradphi0z_begin_r, kappa, nx_local, ny, nz);
                }
                if (TRACK_OBS == 1)
                {
                    CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
                    Calc_fgrad_addfelas_sv<<<Gridsize,Blocksize>>>(dummy, dummy2, gradphi0x_begin_r, gradphi0y_begin_r, 
                                                                   gradphi0z_begin_r, kappa, nx_local, ny, nz);
                    
                    ////NOTE:Avg_ptr[2] is fgrad & Avg_ptr[3] is felas.
                    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &Avg_ptr[2], nx_local*ny*nz);
                    if (count >= time_elast)
                        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &Avg_ptr[3], nx_local*ny*nz);
                }
            }
            else if (nof_variants == 4)
            {
                gradphi0x->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi0y->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi0z->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                
                gradphi1x->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi1y->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi1z->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                
                gradphi2x->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi2y->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi2z->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                
                gradphi3x->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi3y->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                gradphi3z->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
                 
                Calc_Gradphi_MV<<<Gridsize,Blocksize>>>(gradphi0x_begin_f, gradphi0y_begin_f, gradphi0z_begin_f,
                                                        gradphi1x_begin_f, gradphi1y_begin_f, gradphi1z_begin_f,
                                                        gradphi2x_begin_f, gradphi2y_begin_f, gradphi2z_begin_f,
                                                        gradphi3x_begin_f, gradphi3y_begin_f, gradphi3z_begin_f,
                                                        phi0_begin_f, phi1_begin_f, phi2_begin_f, phi3_begin_f, 
                                                        nx_local, ny,nz);

                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0x, gradphi0x, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0y, gradphi0y, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi0z, gradphi0z, CUFFT_INVERSE));
                
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi1x, gradphi1x, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi1y, gradphi1y, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi1z, gradphi1z, CUFFT_INVERSE));
                
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi2x, gradphi2x, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi2y, gradphi2y, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi2z, gradphi2z, CUFFT_INVERSE));
                
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi3x, gradphi3x, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi3y, gradphi3y, CUFFT_INVERSE));
                CUFFT_CHECK(cufftXtExecDescriptor(plan, gradphi3z, gradphi3z, CUFFT_INVERSE));
                
                Normalize_12d<<<Gridsize, Blocksize>>>(gradphi0x_begin_r, gradphi0x_end_r, gradphi0y_begin_r, gradphi0z_begin_r, 
                                                       gradphi1x_begin_r, gradphi1y_begin_r, gradphi1z_begin_r, 
                                                       gradphi2x_begin_r, gradphi2y_begin_r, gradphi2z_begin_r, 
                                                       gradphi3x_begin_r, gradphi3y_begin_r, gradphi3z_begin_r, nx, ny,nz);
                if (engs_out == 1)
                {
                    ////NOTE:dummy2 is reused here for felas engs_out.
                    Calc_fgrad_addfelas_MV<<<Gridsize,Blocksize>>>(ftotal, dummy2, 
                                                                   gradphi0x_begin_r, gradphi0y_begin_r, gradphi0z_begin_r, 
                                                                   gradphi1x_begin_r, gradphi1y_begin_r, gradphi1z_begin_r, 
                                                                   gradphi2x_begin_r, gradphi2y_begin_r, gradphi2z_begin_r, 
                                                                   gradphi3x_begin_r, gradphi3y_begin_r, gradphi3z_begin_r, 
                                                                   kappa, nx_local, ny, nz);
                }
                if (TRACK_OBS == 1)
                {
                    CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
                    ////NOTE:dummy2 is reused here for felas engs_out.
                    Calc_fgrad_addfelas_MV<<<Gridsize,Blocksize>>>(dummy, dummy2, 
                                                                   gradphi0x_begin_r, gradphi0y_begin_r, gradphi0z_begin_r, 
                                                                   gradphi1x_begin_r, gradphi1y_begin_r, gradphi1z_begin_r, 
                                                                   gradphi2x_begin_r, gradphi2y_begin_r, gradphi2z_begin_r, 
                                                                   gradphi3x_begin_r, gradphi3y_begin_r, gradphi3z_begin_r, 
                                                                   kappa, nx_local, ny, nz);
                    
                    ////NOTE:Avg_ptr[2] is fgrad & Avg_ptr[3] is felas.
                    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &Avg_ptr[2], nx_local*ny*nz);
                    if (count >= time_elast)
                        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &Avg_ptr[3], nx_local*ny*nz);
                }

            }

        }
         
        if (nof_variants == 1) 
            Update_phi_sv<<<Gridsize,Blocksize>>>(phi0_begin_f, phi0_end_f, dfdphi0_begin_f, 
                                                  kappa, relax_coeff, dt, dx,dy,dz, nx,ny,nz);
        
        else if (nof_variants == 4)
        {
            Update_phi<<<Gridsize,Blocksize>>>(phi0_begin_f, phi0_end_f, phi1_begin_f, phi2_begin_f,
                                               phi3_begin_f, dfdphi0_begin_f, dfdphi1_begin_f, dfdphi2_begin_f,
                                               dfdphi3_begin_f, kappa, relax_coeff, dt, dx,dy,dz, nx,ny,nz);
            
        }
        
        //// NOISE addition at defined steps witout mean subtraction no noise in comp.
        if (nof_variants == 1 && noise_int == 1)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_INVERSE));
            
            if (num_steps % noise_steps == 0)
                Normalize_noise<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r, d_states, noise_per, nx,ny,nz);
                //Normalize_noise2<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r, d_states, noise_per, nx,ny,nz);
            
            else
                Normalize<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r,nx,ny,nz,Imag);

        }
        
        //// NOISE addition at defined steps witout mean subtraction & storing random noise in noise_array for noise add to comp .
        else if (nof_variants == 1 && noise_int == 2)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_INVERSE));
            
            if (num_steps % noise_steps == 0)
            {
                Normalize_noise_phi<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r, d_states, noise_array, noise_per, nx,ny,nz);
                
                cub::DeviceReduce::Sum(t_storage, t_storage_bytes, noise_array, noise_mean, num_items);
            }
            
            else
                Normalize<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r,nx,ny,nz,Imag);

        }
        
        //// NOISE addition at defined steps with mean subtraction in both phi and comp
        else if (nof_variants == 1 && noise_int == 3)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_INVERSE));
            
            if (num_steps % noise_steps == 0)
            {
                Normalize_phi_Init_noise<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r, d_states, noise_array, noise_per, 
                                                                    nx,ny,nz);
                
                cub::DeviceReduce::Sum(t_storage, t_storage_bytes, noise_array, noise_mean, num_items);
            }
            
            else
                Normalize<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r,nx,ny,nz,Imag);

        }
        else if (nof_variants == 1 && noise_int == 0)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_INVERSE));
            Normalize<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r,nx,ny,nz,Imag);
        }

        if (nof_variants == 4)
        {
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi0, phi0, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi1, phi1, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi2, phi2, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptor(plan, phi3, phi3, CUFFT_INVERSE));
 
            Normalize_4d<<< Gridsize, Blocksize >>>(phi0_begin_r, phi0_end_r, phi1_begin_r, phi2_begin_r, 
                                                    phi3_begin_r, nx,ny,nz);
        }
        if (comp_evolution == 1)
        {
            if (Method == 0 || Method == 1)
            {
                //CUFFT_CHECK(cufftXtExecDescriptor(plan, comp, comp, CUFFT_INVERSE));
                cufftXtExecDescriptor(plan, comp, comp, CUFFT_INVERSE);
            
                //Normalize_comp<<< Gridsize, Blocksize >>>(comp_begin_r, comp_end_r,CALPHA_chk, CBETA_chk,
                //                                          abort_flag);
                
                if (noise_int == 0 || noise_int == 1)
                    Normalize<<< Gridsize, Blocksize >>>(comp_begin_r, comp_end_r,nx,ny,nz,Imag);
                
                else if (noise_int == 2)
                {
                    if (num_steps % noise_steps == 0)
                    {
                        MPI_Allreduce(MPI_IN_PLACE, noise_mean, 1, MPI_DOUBLE, MPI_SUM, comm); 
                        //ncclAllReduce(noise_mean, noise_mean, 1, ncclDouble, ncclSum, nccl_comm, 0);
                        CUDA_CHECK(cudaStreamSynchronize(0));
                        Average<<<1,1>>>(noise_mean, sizescale);
                        Normalize_noise_comp<<<Gridsize,Blocksize>>>(comp_begin_r, comp_end_r, noise_array, 
                                                                     noise_mean, nx,ny,nz);
                    }
                    else
                        Normalize<<< Gridsize, Blocksize >>>(comp_begin_r, comp_end_r,nx,ny,nz,Imag);

                }
                
                if (*abort_flag == 1.0)
                {
                    printf("====> $$ ABORTING the job, composition is blowing up $$ <==== \n");
                    MPI_Abort(comm, EXIT_FAILURE);

                }

            }

            if (Method == 2 && noise_int == 2 && (num_steps % noise_steps == 0))
            {
                //// No scaling in comp is needed here since it's Method=2
                MPI_Allreduce(MPI_IN_PLACE, noise_mean, 1, MPI_DOUBLE, MPI_SUM, comm); 
                //ncclAllReduce(noise_mean, noise_mean, 1, ncclDouble, ncclSum, nccl_comm, 0);
                CUDA_CHECK(cudaStreamSynchronize(0));
                Average<<<1,1>>>(noise_mean, sizescale);
                Add_noise_comp<<<Gridsize,Blocksize>>>(comp_begin_r, comp_end_r, noise_array, noise_mean, nx,ny,nz);

            }
            
            if (noise_int == 3 && (num_steps % noise_steps == 0))
            {
                MPI_Allreduce(MPI_IN_PLACE, noise_mean, 1, MPI_DOUBLE, MPI_SUM, comm); 
                //ncclAllReduce(noise_mean, noise_mean, 1, ncclDouble, ncclSum, nccl_comm, 0);
                CUDA_CHECK(cudaStreamSynchronize(0)); 
                Average<<<1,1>>>(noise_mean, sizescale);
                Add_noise<<<Gridsize,Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, noise_array, noise_mean, nx,ny,nz);

            }
        }
        
        if (OUTPUT == 1)
        {
            ////Writing output
            Output_Conf(comp, phi0, phi1, phi2, phi3, count);
            if (VTK_out == 1)
            {
                if (rank == 0)
                    printf ("Output is written to file \n");
            }
        
        }
        
        if (TRACK_OBS == 1) 
        { 
            ncclAllReduce(Avg_ptr, Avg_ptr, 4, ncclDouble, ncclSum, nccl_comm, 0);
            CUDA_CHECK(cudaMemcpy(Avg_ptr_h, Avg_ptr, 4*sizeof(double), cudaMemcpyDeviceToHost));
           
            if(rank == 0)
            {
                Avg_ptr_h[0] *= sizescale;
                Avg_ptr_h[1] *= sizescale;
                Avg_ptr_h[2] *= sizescale;
                Avg_ptr_h[3] *= sizescale;
                
                double h_ftotal = Avg_ptr_h[1] + Avg_ptr_h[2];
                
                char full_path[1024]; 
                snprintf(full_path, sizeof(full_path), "%s/Sim_Obs.csv", path);

                FILE *f_eng = fopen(full_path, "a");
                if (f_eng != NULL)
                {
                    if (count == initcount)
                    {
                        if(inhom != 1.0)
                            fprintf(f_eng, "Step, Vol_Frac, Total_Energy, Elastic_Energy, S11, S22, S33, S23, S13, S12\n");
                    
                        else 
                            fprintf(f_eng, "Step, Vol_Frac, Total_Energy, Elastic_Energy, S11, S22, S33\n"); 
                    }
                    
                    if (inhom != 1.0)
                        fprintf(f_eng, "%d, %.12le, %.12le, %.12le,%.12le,%.12le,%.12le,%.12le,%.12le,%.12le\n", 
                                        count, Avg_ptr_h[0], h_ftotal, Avg_ptr_h[3], persts_h[0], persts_h[1], persts_h[2], 
                                        persts_h[3], persts_h[4], persts_h[5]);
                    else
                        fprintf(f_eng, "%d, %.12le, %.12le, %.12le,%.12le,%.12le,%.12le\n",
                                        count, Avg_ptr_h[0], h_ftotal, Avg_ptr_h[3], persts_h[0], persts_h[1], persts_h[2]);

                    fclose(f_eng);
                }                    
                if (print_engs == 1)
                {
                    printf("Volume fraction is:%le\n", Avg_ptr_h[0]);
                    printf("ftotal:%E\n", h_ftotal);
                    ////NOTE: if count < time_elast it will be zero.
                    printf("felas:%E\n", Avg_ptr_h[3]); 
                }
            }    
        }
        MPI_Barrier(comm);
        
        sim_time = sim_time + dt;
        iteration = iteration + 1;
    }//time loop ends
    CUDA_CHECK(cudaDeviceSynchronize());
    end_time = MPI_Wtime();
    CUDA_CHECK(cudaEventRecord(stop, 0));
    CUDA_CHECK(cudaEventSynchronize(stop));
    cudaEventElapsedTime(&local_ms, start, stop);
    MPI_Allreduce(MPI_IN_PLACE, &local_ms, 1, MPI_FLOAT, MPI_MAX, comm); 

    cpu_time = (double)(end_time - start_time);
    MPI_Allreduce(MPI_IN_PLACE, &cpu_time, 1, MPI_DOUBLE, MPI_MAX, comm); 
    if (rank == 0)
    {
        printf("Solver time from CUDA: %f seconds\n", (local_ms/1000.0));
        printf("Solver time: %f seconds\n", cpu_time);
    }
    
    CUFFT_CHECK(cufftXtFree(dfdphi0));
    CUFFT_CHECK(cufftXtFree(dfdphi1));
    CUFFT_CHECK(cufftXtFree(dfdphi2));
    CUFFT_CHECK(cufftXtFree(dfdphi3));
    CUFFT_CHECK(cufftXtFree(gradmux));
    CUFFT_CHECK(cufftXtFree(gradmuy));
    CUFFT_CHECK(cufftXtFree(gradmuz));
    CUDA_CHECK(cudaFree(comp_avg));
    free(comp_avg_h);
    
    if (noise_int != 0) 
    {
        CUDA_CHECK(cudaFree(noise_array));
        CUDA_CHECK(cudaFree(noise_mean));
    }

    if (elast_int == 1)
    {
        free(eigsts_h);
        free(persts_h);
        free(hom_strain_h);
        CUFFT_CHECK(cufftXtFree(str_v0_d));
        CUFFT_CHECK(cufftXtFree(str_v1_d));
        CUFFT_CHECK(cufftXtFree(str_v2_d));
        CUFFT_CHECK(cufftXtFree(str_v3_d));
        CUFFT_CHECK(cufftXtFree(str_v4_d));
        CUFFT_CHECK(cufftXtFree(str_v5_d));
        CUFFT_CHECK(cufftXtFree(unewx));
        CUFFT_CHECK(cufftXtFree(unewy));
        CUFFT_CHECK(cufftXtFree(unewz));
        CUDA_CHECK(cudaFree(avgeigsts));
        CUDA_CHECK(cudaFree(avgpersts));
        if (norm_calc == 1)
        {
            CUDA_CHECK(cudaFree(disperr));
            free(disperr_h);
        }
        CUDA_CHECK(cudaFree(hom_strain_v));
        CUDA_CHECK(cudaFree(Chom));
        CUDA_CHECK(cudaFree(Chet));
        CUDA_CHECK(cudaFree(Cavg));
        CUDA_CHECK(cudaFree(S_d));
    }
    if(engs_out == 1 || TRACK_TIME > 0)
    {
        CUFFT_CHECK(cufftXtFree(gradphi0x));
        CUFFT_CHECK(cufftXtFree(gradphi0y));
        CUFFT_CHECK(cufftXtFree(gradphi0z));

    }
}
