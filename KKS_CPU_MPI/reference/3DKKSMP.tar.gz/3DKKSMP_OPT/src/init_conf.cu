//#include "../include/binary.h"

#define IA 16807
#define IM 2147483647
#define AM (1.0/IM)
#define IQ 127773
#define IR 2836
#define NTAB 32
#define NDIV (1+(IM-1)/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

__global__ void GetNearbyVariants_MGPU(
    const double centx, const double centy, const double centz,
    const double exclusion_rad,           
    int* __restrict__ occupancy,
    BoxIterator<cufftDoubleComplex> phi0_begin,
    BoxIterator<cufftDoubleComplex> phi1_begin,
    BoxIterator<cufftDoubleComplex> phi2_begin,
    BoxIterator<cufftDoubleComplex> phi3_begin,
    int* nearby_variant_flags, int nx_local, int nx_start, int ny, int nz)
{
    const long i = threadIdx.x + blockIdx.x * blockDim.x;
    const long j = threadIdx.y + blockIdx.y * blockDim.y;
    const long k = threadIdx.z + blockIdx.z * blockDim.z;

    const int glob_i    = i + nx_start;
    const long idx      = k + (nz * (j + (i * ny)));
    
    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;

    if (idx >= nx_local * ny * nz) return;
    if (occupancy[idx] == 0) return;       // skip empty cells fast

    double dist2 = ((double)glob_i - centx) * ((double)glob_i - centx)
                 + ((double)j      - centy) * ((double)j      - centy)
                 + ((double)k      - centz) * ((double)k      - centz);

    if (dist2 > exclusion_rad * exclusion_rad) return;  // outside sensing zone

    // This cell is occupied and within exclusion zone — flag its variant
    double p0 = phi0_begin->x;
    double p1 = phi1_begin->x;
    double p2 = phi2_begin->x;
    double p3 = phi3_begin->x;

    if (p0 > 0.5) atomicMax(&nearby_variant_flags[0], 1);
    if (p1 > 0.5) atomicMax(&nearby_variant_flags[1], 1);
    if (p2 > 0.5) atomicMax(&nearby_variant_flags[2], 1);
    if (p3 > 0.5) atomicMax(&nearby_variant_flags[3], 1);
}


__device__ __forceinline__
double superEllipsoidPhi(double x, double y, double z,
                         double cx, double cy, double cz,
                         double ax, double ay, double az,
                         double n, double eps)
{
    double dx = fabs(x - cx) / ax;
    double dy = fabs(y - cy) / ay;
    double dz = fabs(z - cz) / az;

    // Super-ellipsoid norm
    double px = pow(dx, n);
    double py = pow(dy, n);
    double pz = pow(dz, n);

    double val = pow(px + py + pz, 1.0 / n);

    // Proper scaling → IMPORTANT for cuboidal shape
    double scale = fmin(fmin(ax, ay), az);
    double dist  = (val - 1.0) * scale;

    double invW = 1.0 / (sqrt(2.0) * eps);

    return 0.5 * (1.0 - tanh(dist * invW));
}

__global__ void Create_SELP_SV(BoxIterator<cufftDoubleComplex> comp_begin,
                           BoxIterator<cufftDoubleComplex> comp_end,
                           BoxIterator<cufftDoubleComplex> phi0_begin,
                           const double rad,
                           const double c_beta_eq,
                           const double c_alpha_eq,
                           double c0, double spacing,
                           int nx, int ny, int nz)
{
    const long i = threadIdx.x + blockIdx.x * blockDim.x;
    const long j = threadIdx.y + blockIdx.y * blockDim.y;
    const long k = threadIdx.z + blockIdx.z * blockDim.z;

    const long idx = k + (nz * (j + (i * ny)));

    comp_begin += idx;
    phi0_begin += idx;

    if (comp_begin < comp_end)
    {
        double cx[3], cy[3], cz[3];
        double ax[3], ay[3], az[3];

        double s   = spacing; 
        double eps = 1.0;   // ⚠️ more stable than 0.1

        // Positions
        //cx[0] = nx * 0.5;        cy[0] = ny * (0.5 - s); cz[0] = nz * 0.5;
        //cx[1] = nx * (0.5 - s);  cy[1] = ny * (0.5 + s); cz[1] = nz * 0.5;
        //cx[2] = nx * (0.5 + s);  cy[2] = ny * (0.5 + s); cz[2] = nz * 0.5;
        
        cx[0] = nx * 0.5;  cy[0] = ny * (0.5 - s);  cz[0] = nz * 0.5;
        cx[1] = nx * 0.5;  cy[1] = ny * (0.5 + s);  cz[1] = nz * 0.5;

        // Sizes
        //for (int p = 0; p < 2; p++)
        //{
        //    ax[p] = 2.0 * rad;
        //    ay[p] = 2.0 * rad;
        //    az[p] = 2.0 * rad;
        //}
        
        ax[0] = 2.0 * rad;
        ay[0] = 2.0 * rad;
        az[0] = 2.0 * rad;
        
        ax[1] = 1.99* rad;
        ay[1] = 1.99* rad;
        az[1] = 1.99* rad;

        double x = (double)j;
        double y = (double)k;
        double z = (double)i;

        double phi0_val = 0.0;
        double phi1_val = 0.0;
        //double phi2_val = 0.0;

        for (int p = 0; p < 2; p++)
        {
            double pi = superEllipsoidPhi(x, y, z,
                                          cx[p], cy[p], cz[p],
                                          ax[p], ay[p], az[p],
                                          8.0,   // cuboidal
                                          eps);

            phi0_val = fmax(phi0_val, pi);
            
            //if (p == 0)
            //    phi0_val = fmax(phi0_val, pi);
            //else if (p == 1)
            //    phi1_val = fmax(phi1_val, pi);
            //else
            //    phi0_val = fmax(phi0_val, pi);
        }

        //double phi = fmax(fmax(phi0_val, phi1_val), phi2_val);
        double phi = fmax(phi0_val, phi1_val);

        comp_begin->x = ((c_beta_eq * phi) + c0 * (1.0 - phi));

        phi0_begin->x = phi0_val;
        //phi1_begin->x = phi1_val;
        //phi2_begin->x = phi2_val;
    }
}


__global__ void Create_SELP(BoxIterator<cufftDoubleComplex> comp_begin,
                           BoxIterator<cufftDoubleComplex> comp_end,
                           BoxIterator<cufftDoubleComplex> phi0_begin,
                           BoxIterator<cufftDoubleComplex> phi1_begin,
                           BoxIterator<cufftDoubleComplex> phi2_begin,
                           BoxIterator<cufftDoubleComplex> phi3_begin,
                           const double rad,
                           const double c_beta_eq,
                           const double c_alpha_eq,
                           double c0, double spacing,
                           int nx, int ny, int nz)
{
    const long i = threadIdx.x + blockIdx.x * blockDim.x;
    const long j = threadIdx.y + blockIdx.y * blockDim.y;
    const long k = threadIdx.z + blockIdx.z * blockDim.z;

    const long idx = k + (nz * (j + (i * ny)));

    comp_begin += idx;
    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        double cx[3], cy[3], cz[3];
        double ax[3], ay[3], az[3];

        double s   = spacing; 
        double eps = 1.0;   // ⚠️ more stable than 0.1

        // Positions
        //cx[0] = nx * 0.5;        cy[0] = ny * (0.5 - s); cz[0] = nz * 0.5;
        //cx[1] = nx * (0.5 - s);  cy[1] = ny * (0.5 + s); cz[1] = nz * 0.5;
        //cx[2] = nx * (0.5 + s);  cy[2] = ny * (0.5 + s); cz[2] = nz * 0.5;
        
        cx[0] = nx * 0.5;  cy[0] = ny * (0.5 - s);  cz[0] = nz * 0.5;
        cx[1] = nx * 0.5;  cy[1] = ny * (0.5 + s);  cz[1] = nz * 0.5;

        // Sizes
        //for (int p = 0; p < 2; p++)
        //{
        //    ax[p] = 2.0 * rad;
        //    ay[p] = 2.0 * rad;
        //    az[p] = 2.0 * rad;
        //}
        
        ax[0] = 2.0 * rad;
        ay[0] = 2.0 * rad;
        az[0] = 2.0 * rad;
        
        ax[1] = 0.99* rad;
        ay[1] = 0.99* rad;
        az[1] = 0.99* rad;

        double x = (double)j;
        double y = (double)k;
        double z = (double)i;

        double phi0_val = 0.0;
        double phi1_val = 0.0;
        double phi2_val = 0.0;

        for (int p = 0; p < 2; p++)
        {
            double pi = superEllipsoidPhi(x, y, z,
                                          cx[p], cy[p], cz[p],
                                          ax[p], ay[p], az[p],
                                          8.0,   // cuboidal
                                          eps);

            //phi0_val = fmax(phi0_val, pi);
            
            if (p == 0)
                phi0_val = fmax(phi0_val, pi);
            else if (p == 1)
                phi1_val = fmax(phi1_val, pi);
            else
                phi2_val = fmax(phi2_val, pi);
        }

        double phi = fmax(fmax(phi0_val, phi1_val), phi2_val);

        comp_begin->x = ((c_beta_eq * phi) + c0 * (1.0 - phi));

        phi0_begin->x = phi0_val;
        phi1_begin->x = phi1_val;
        phi2_begin->x = phi2_val;
    }
}

__global__ void Initialize_comp(cufftDoubleComplex *comp, double c0)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int nx = nz_d; int ny = ny_d; int nz = nz_d;
    long idx = k + (nz * (j + (i*ny))); 
    if (idx >= nx*ny*nz)
        return;
    
    comp[idx].x = c0;
    comp[idx].y = 0.0;
}
__global__ void Initialize_MGPU_SV(BoxIterator<cufftDoubleComplex> comp_begin,
                                BoxIterator<cufftDoubleComplex> comp_end, 
                                BoxIterator<cufftDoubleComplex> phi0_begin, 
                                double c0, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx;
    phi0_begin += idx;
    
    if (comp_begin < comp_end)
    {
        *comp_begin = {c0, 0.0};
        *phi0_begin = {0.0, 0.0};
    }
}

__global__ void Initialize_MGPU(BoxIterator<cufftDoubleComplex> comp_begin,
                                BoxIterator<cufftDoubleComplex> comp_end, 
                                BoxIterator<cufftDoubleComplex> phi0_begin, 
                                BoxIterator<cufftDoubleComplex> phi1_begin, 
                                BoxIterator<cufftDoubleComplex> phi2_begin, 
                                BoxIterator<cufftDoubleComplex> phi3_begin, 
                                double c0)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    
    const int ny = ny_d; const int nz = nz_d; 

    long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx;
    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;
    
    if (comp_begin < comp_end)
    {
        *comp_begin = {c0, 0.0};
        *phi0_begin = {0.0, 0.0};
        *phi1_begin = {0.0, 0.0};
        *phi2_begin = {0.0, 0.0};
        *phi3_begin = {0.0, 0.0};

    }
    
}

void FindCrit_Ncl_size (double *ppt_size, double f0A, double Vm, double c0, 
                          double c_alpha_eq, double c_beta_eq, 
                          double mu_m, double mu_p, double nu_m, double nu_p, 
                          double epszero, double interface_energy, int elast_int)
{

    double  chem_driving_force, elast_driving_force, crit_nucleus;

    chem_driving_force  = -1.0*((f0A/Vm)*(c0-c_alpha_eq)*(c0-c_alpha_eq)
                          +2.0*(c_beta_eq-c0)*(f0A/Vm)*(c0-c_alpha_eq));
    elast_driving_force = (2.0*(0.5*(mu_p+mu_m))*(1.0 + 0.5*(nu_m + nu_p))*
                          epszero*epszero)/(1.0-0.5*(nu_p+nu_m));

    if (elast_int == 1)
      crit_nucleus = -2.0*interface_energy/
                    (chem_driving_force + elast_driving_force);
    else
      crit_nucleus = -2.0*interface_energy/chem_driving_force;

    *ppt_size = 1.1*crit_nucleus;

}

void FindCrit_Ncl_size2 (double *ppt_size, double f0A, double f0B,
                         double Vm, double c0, 
                          double c_alpha_eq, double c_beta_eq, 
                          double mu_m, double mu_p, double nu_m, double nu_p, 
                          double epszero, double interface_energy, int elast_int)
{

    double  chem_driving_force, elast_driving_force, crit_nucleus;

    chem_driving_force  = -1.0*((f0A/Vm)*(c0-c_alpha_eq)*(c0-c_alpha_eq)
                          +2.0*(c_beta_eq-c0)*(f0A/Vm)*(c0-c_alpha_eq) + 
                          ((f0B/Vm)*(c0-c_beta_eq)*(c0-c_beta_eq)));
    elast_driving_force = (2.0*(0.5*(mu_p+mu_m))*(1.0 + 0.5*(nu_m + nu_p))*
                          epszero*epszero)/(1.0-0.5*(nu_p+nu_m));

    if (elast_int == 1)
      crit_nucleus = -2.0*interface_energy/
                    (chem_driving_force + elast_driving_force);
    else
      crit_nucleus = -2.0*interface_energy/chem_driving_force;

    *ppt_size = 1.1*crit_nucleus;

}

void Move_R2D(cufftDoubleComplex *Y, double *X, long nx_local, long ny, long nz)
{
    for (int i=0; i<nx_local*ny*nz; i++)
    {
        Y[i].x = X[i];
    }

}

void read_field(double *data, int nx_local, int ny, int nz,
                int nx_offset, int nx_global, char *path,
                const char *field_name, const char *basename, int step, MPI_Comm comm) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);

    hid_t file_id, dset_id, filespace, memspace, plist_id;
    
    hsize_t local_dims[3]  = {(hsize_t) nx_local, (hsize_t) ny, (hsize_t) nz};
    hsize_t start[3]       = {(hsize_t) nx_offset, 0, 0};

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fopen(filename, H5F_ACC_RDONLY, plist_id);
    H5Pclose(plist_id);

    dset_id = H5Dopen(file_id, field_name, H5P_DEFAULT);
    filespace = H5Dget_space(dset_id);
    H5Sselect_hyperslab(filespace, H5S_SELECT_SET, start, NULL, local_dims, NULL);
    memspace = H5Screate_simple(3, local_dims, NULL);

    plist_id = H5Pcreate(H5P_DATASET_XFER);
    H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_COLLECTIVE);
    H5Dread(dset_id, H5T_NATIVE_DOUBLE, memspace, filespace, plist_id, data);

    H5Pclose(plist_id);
    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
    H5Fclose(file_id);
}

__global__ void KernelRealToComplex(BoxIterator<cufftDoubleComplex> comp_begin,
                                    BoxIterator<cufftDoubleComplex> comp_end,
                                    BoxIterator<cufftDoubleComplex> phi0_begin,
                                    BoxIterator<cufftDoubleComplex> phi0_end,
                                    BoxIterator<cufftDoubleComplex> phi1_begin,
                                    BoxIterator<cufftDoubleComplex> phi1_end,
                                    BoxIterator<cufftDoubleComplex> phi2_begin,
                                    BoxIterator<cufftDoubleComplex> phi2_end,
                                    BoxIterator<cufftDoubleComplex> phi3_begin,
                                    BoxIterator<cufftDoubleComplex> phi3_end,
                                    double *real_comp,
                                    double *real_phi0, double *real_phi1,
                                    double *real_phi2, double *real_phi3,
                                    long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    
    comp_begin += idx ; phi0_begin += idx; phi1_begin += idx;
    phi2_begin += idx; phi3_begin += idx;
    
    if (comp_begin < comp_end)
    {
        *comp_begin = {real_comp[idx], 0.0};
        *phi0_begin = {real_phi0[idx], 0.0};
        *phi1_begin = {real_phi1[idx], 0.0};
        *phi2_begin = {real_phi2[idx], 0.0};
        *phi3_begin = {real_phi3[idx], 0.0};

    }
    __syncthreads();
}

double ran(long *idum)
{
	int j;
	long k;
	static long iy = 0;
	static long iv[NTAB];
	double temp;
	double dummy = RNMX;

	if (*idum <= 0 || !iy) {
		if (-(*idum) < 1)
			*idum = 1;
		else
			*idum = -(*idum);
		for (j = NTAB + 7; j >= 0; j--) {
			k = (*idum) / IQ;
			*idum = IA * (*idum - k * IQ) - IR * k;
			if (*idum < 0)
				*idum += IM;
			if (j < NTAB)
				iv[j] = *idum;
		}
		iy = iv[0];
	}
	k = (*idum) / IQ;
	*idum = IA * (*idum - k * IQ) - IR * k;
	if (*idum < 0)
		*idum += IM;
	j = iy / NDIV;
	iy = iv[j];
	iv[j] = *idum;
	if ((temp = AM * iy) > RNMX)
		return dummy;
	else
		return temp;
}
__global__ void Compute_f0_c_eq(double *f0, double *c_eq, double f0A, double f0B,
                                double Vm, double c_alpha_eq, double c_beta_eq)
{
    // 0 -> alpha; 1 -> beta.
    f0[0] = (f0A);
    f0[1] = (f0B);
    c_eq[0] = c_alpha_eq;
    c_eq[1] = c_beta_eq;
    //printf("f0_beta & cbeta_eq:\t%lf\t%lf\n",f0[1], c_eq[1]);
    //printf("f0_alpha & calpha_eq:\t%lf\t%lf\n",f0[0], c_eq[0]);

}

__global__ void Create1DNuclei(int nx, int ny, double centx, double centy,
		double *ppt_size, cufftDoubleComplex *comp,
		cufftDoubleComplex *phi0,
		double *c_eq, double c0 )
{

	int i = threadIdx.x + blockIdx.x * blockDim.x;
	int j = threadIdx.y + blockIdx.y * blockDim.y;

	int idx = (j + i *ny);
    if (idx < nx*ny)
    {
        if ((((double) i - centx) * ((double) i - centx)
                + ((double) j - centy) * ((double) j - centy))
                < ((*ppt_size) * (*ppt_size)))
        {
            comp[idx].x = c_eq[1];
            comp[idx].y = 0.0;
            phi0[idx].x = 1.0;
            phi0[idx].y = 0.0;
        }
        else
        {
            // Fill matrix.
            comp[idx].x = c0;
            comp[idx].y = 0.0;
        }
    }
	__syncthreads();
}


void CreateNuclei_h(cufftDoubleComplex *comp, cufftDoubleComplex *phi0, 
                     double c_beta_eq, double c0, double ppt_size,
                     double centx, double centy, double centz,
                     long nx, long ny, long nz)

{
    for (long i=0; i<nx; i++)
    {
        for (long j=0; j<ny; j++)
        {
            for (long k=0; k<nz; k++)
            {
                long l = (k + nz*(j + (i*ny)));
                
                if ((((double) i - centx) * ((double) i - centx)
                    + ((double) j - centy) * ((double) j - centy) 
                    + ((double) k - centz) * ((double) k - centz)) 
                        < ((ppt_size) * (ppt_size)))
                {
                    comp[l].x = c_beta_eq;
                    phi0[l].x = 1.0; 
                    comp[l].y = 0.0; 
                    phi0[l].y = 0.0; 
                }
                else
                {
                    comp[l].x = c0; 
                    phi0[l].x = 0.0; 
                    comp[l].y = 0.0; 
                    phi0[l].y = 0.0; 
                }
            }
        }
    }
}

__global__ void CreateNuclei(BoxIterator<cufftDoubleComplex> comp_begin,
                             BoxIterator<cufftDoubleComplex> comp_end,
                             BoxIterator<cufftDoubleComplex> phi0_begin,
                             BoxIterator<cufftDoubleComplex> phi0_end,
		                     double *c_eq, double c0, double *ppt_size,
                             double centx, double centy, double centz,
                             long nx_start, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));
    
    long glob_i = i + nx_start; 
    comp_begin += idx ; phi0_begin += idx; 
    if (comp_begin < comp_end)
    {
        
        if ((((double) glob_i - centx) * ((double) glob_i - centx)
            + ((double) j - centy) * ((double) j - centy) 
            + ((double) k - centz) * ((double) k - centz)) 
                < ((*ppt_size) * (*ppt_size)))
        {
            *comp_begin = {c_eq[1], 0.0};
            *phi0_begin = {1.0, 0.0};
        }
        else
        {
            *comp_begin = {c0, 0.0};
            *phi0_begin = {0.0, 0.0};
        }
    }
	__syncthreads();
}

void CreateMVrandom_Nuclei_h(cufftDoubleComplex *comp, cufftDoubleComplex *phi0, cufftDoubleComplex *phi1,
                             cufftDoubleComplex * phi2, cufftDoubleComplex *phi3,
                             double centx, double centy, double centz,  double rad,
                             double c_beta_eq, double c_alpha_eq, double c0,
                             int *occupancy, long nx, long ny, long nz, int f)
{ 
    for (long i=0; i<nx; i++)
    {
        for (long j=0; j<ny; j++)
        {
            for (long k=0; k<nz; k++)
            {
                long l = (k + nz*(j + (i*ny)));
                
                if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                        < (pow(2.0 * rad, 2.0)))
                {
                    if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                            < (pow(rad, 2.0)))
                    {
                        if (f==0)
                        {
                            comp[l].x = c_beta_eq;
                            comp[l].y = 0.0;
                            phi0[l].x = 1.0;
                            phi0[l].y = 0.0;
                        }


                        else if (f==1)
                        {
                            comp[l].x = c_beta_eq;
                            comp[l].y = 0.0;
                            phi1[l].x = 1.0;
                            phi1[l].y = 0.0;
                        }
                        else if (f==2)
                        {
                            comp[l].x = c_beta_eq;
                            comp[l].y = 0.0;
                            phi2[l].x = 1.0;
                            phi2[l].y = 0.0;
                        }
                        else if (f==3)
                        {
                            comp[l].x = c_beta_eq;
                            comp[l].y = 0.0;
                            phi3[l].x = 1.0;
                            phi3[l].y = 0.0;
                        }
                    }
                    occupancy[l] = 1;
                }
            }
        }
    }
}
            
__global__ void CreateMVRandomNuclei(cufftDoubleComplex *comp,
                                     cufftDoubleComplex *phi0,
                                     cufftDoubleComplex *phi1,
                                     cufftDoubleComplex *phi2,
                                     cufftDoubleComplex *phi3,
                                     double centx, double centy, double centz,  double rad,
                                     double c_beta_eq, double c_alpha_eq, double c0,
                                     int *occupancy, int f)
{ 
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int nx = nx_d; int ny = ny_d; int nz = nz_d;
    long idx = k + (nz * (j + (i*ny)));

    if (i >= nx || j >= ny || k >= nz) 
        return;
    
    if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
            < (pow(2.0 * rad, 2.0)))
    {
        if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                < (pow(rad, 2.0)))
        {
            comp[idx] = {c_beta_eq, 0.0};
            if (f==0)
                phi0[idx] = {1.0, 0.0};

            else if (f==1)
                phi1[idx] = {1.0, 0.0};
            
            else if (f==2)
                phi2[idx] = {1.0, 0.0};
            
            else if (f==3)
                phi3[idx] = {1.0, 0.0};
        }

        occupancy[idx] = 1;
    }
}

__global__ void Create_QUAD_SV_MGPU(BoxIterator<cufftDoubleComplex> comp_begin,
                                 BoxIterator<cufftDoubleComplex> comp_end,
                                 BoxIterator<cufftDoubleComplex> phi0_begin,
                                 const double centx, const double centy, const double centz,  
                                 const double rad, const double c_beta_eq, const double c_alpha_eq) 
{ 
    const long i = threadIdx.x + blockIdx.x*blockDim.x;
    const long j = threadIdx.y + blockIdx.y*blockDim.y;
    const long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nx_start = nx_start_d; const int ny = ny_d; const int nz = nz_d;
    const int glob_i = i + nx_start; 
    const long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx; phi0_begin += idx; 

    if (comp_begin < comp_end)
    {
        if ((pow((double) (glob_i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                < (pow(rad, 2.0)))
        {
            *phi0_begin = {1.0,0.0};
            *comp_begin = {c_beta_eq, 0.0};
        }
    }
}

__global__ void Create_QUAD_MV_MGPU(BoxIterator<cufftDoubleComplex> comp_begin,
                                 BoxIterator<cufftDoubleComplex> comp_end,
                                 BoxIterator<cufftDoubleComplex> phi0_begin,
                                 BoxIterator<cufftDoubleComplex> phi1_begin,
                                 BoxIterator<cufftDoubleComplex> phi2_begin,
                                 BoxIterator<cufftDoubleComplex> phi3_begin,
                                 const double centx, const double centy, const double centz,  
                                 const double rad, const double c_beta_eq, const double c_alpha_eq, int f) 
{ 
    const long i = threadIdx.x + blockIdx.x*blockDim.x;
    const long j = threadIdx.y + blockIdx.y*blockDim.y;
    const long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nx_start = nx_start_d; const int ny = ny_d; const int nz = nz_d;
    const int glob_i = i + nx_start; 
    const long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx; phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        if ((pow((double) (glob_i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                < (pow(rad, 2.0)))
        {
             
            if (f==0)
            {
                *phi0_begin = {1.0,0.0};
                *comp_begin = {c_beta_eq, 0.0};
            }
            else if (f==1)
            {
                *phi1_begin = {1.0,0.0};
                *comp_begin = {c_beta_eq, 0.0};
            }
            else if (f==2)
            {
                *phi2_begin = {1.0,0.0};
                *comp_begin = {c_beta_eq, 0.0};
            }
            else if (f==3)
            {
                *phi3_begin = {1.0,0.0};
                *comp_begin = {c_beta_eq, 0.0};
            }
            
        }
    }
}


__global__ void CreateMVRandomNuclei_MGPU(BoxIterator<cufftDoubleComplex> comp_begin,
                                          BoxIterator<cufftDoubleComplex> comp_end,
                                          BoxIterator<cufftDoubleComplex> phi0_begin,
                                          BoxIterator<cufftDoubleComplex> phi1_begin,
                                          BoxIterator<cufftDoubleComplex> phi2_begin,
                                          BoxIterator<cufftDoubleComplex> phi3_begin,
                                          const double centx, const double centy, const double centz,  
                                          const double rad, const double c_beta_eq, const double c_alpha_eq, 
                                          const double c0, int* __restrict__ occupancy, const int f)
{ 
    const long i = threadIdx.x + blockIdx.x*blockDim.x;
    const long j = threadIdx.y + blockIdx.y*blockDim.y;
    const long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nx_start = nx_start_d; const int ny = ny_d; const int nz = nz_d;
    const int glob_i = i + nx_start; 
    const long idx = k + (nz * (j + (i*ny)));
    comp_begin += idx; phi0_begin += idx; phi1_begin += idx; phi2_begin += idx; phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        if ((pow((double) (glob_i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                < (pow(2.0 * rad, 2.0)))
        {
            if ((pow((double) (glob_i - centx), 2.0) + pow((double) (j - centy), 2.0)+ pow((double) (k-centz),2.0))
                    < (pow(rad, 2.0)))
            {
                if (f==0)
                {
                    *phi0_begin = {1.0,0.0};
                    *comp_begin = {c_beta_eq, 0.0};
                }
                else if (f==1)
                {
                    *phi1_begin = {1.0,0.0};
                    *comp_begin = {c_beta_eq, 0.0};
                }
                else if (f==2)
                {
                    *phi2_begin = {1.0,0.0};
                    *comp_begin = {c_beta_eq, 0.0};
                }
                else if (f==3)
                {
                    *phi3_begin = {1.0,0.0};
                    *comp_begin = {c_beta_eq, 0.0};
                }
            }
            
            occupancy[idx] = 1;
        }
    }
}


void CheckOverlap_h(int *overlap, int *occupancy, double centx, double centy, double centz, 
                    double rad, long nx, long ny, long nz) 
{
    for (long i=0; i<nx; i++)
    {
        for (long j=0; j<ny; j++)
        {
            for (long k=0; k<nz; k++)
            {
                long l = (k + nz*(j + (i*ny)));

                if ((((double) i - centx) * ((double) i - centx)
                    +((double) j - centy) * ((double) j - centy)
                    +((double) k - centz) * ((double) k - centz))
                        <= ((2.0 * rad) * (2.0 * rad)))
                {
                    if (occupancy[l] == 1)
                        overlap[0] = 1;
                }
            }
        }
    }
}

__global__ void CheckOverlap(long nx, long ny,long nz, double centx, double centy, double centz,
		                     double rad, int* __restrict__ occupancy, int *overlap)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    long glob_i = i; 
    if (idx<nx*ny*nz)
    {

        if ((((double) glob_i - centx) * ((double) glob_i - centx)
            +((double) j - centy) * ((double) j - centy)
            +((double) k - centz) * ((double) k - centz))
                <= ((2.0 * rad) * (2.0 * rad)))
        {
            if (occupancy[idx] == 1)
                *overlap = 1;
        }
    }
    //__syncthreads();
}

__global__ void CheckOverlap_MGPU(const double centx, const double centy,const double centz, const double rad, 
                                  int* __restrict__ occupancy, int *overlap)
{
    const long i = threadIdx.x + blockIdx.x*blockDim.x;
    const long j = threadIdx.y + blockIdx.y*blockDim.y;
    const long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int nx_start = nx_start_d; const int ny = ny_d; const int nz = nz_d; const int nx_local = nx_local_d;
    const int glob_i = i + nx_start; 
    const long idx = k + (nz * (j + (i*ny))); 
    
    if (idx >= nx_local*ny*nz)
        return;

    if ((((double) glob_i - centx) * ((double) glob_i - centx)
        +((double) j - centy) * ((double) j - centy)
        +((double) k - centz) * ((double) k - centz))
            <= ((2.0 * rad) * (2.0 * rad)))
    {
        
        if (occupancy[idx] == 1)
            *overlap = 1;
    }
}

/*
__global__ void Create_Two_nuclei(BoxIterator<cufftDoubleComplex> comp_begin,
                                   BoxIterator<cufftDoubleComplex> comp_end,
                                   BoxIterator<cufftDoubleComplex> phi0_begin,
                                   double ppt_size, double *c_eq, double* centx, double* centy,
                                   double* centz, double cx, double cy, double cz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int ny = ny_d;
    const int nz = nz_d;
    const int nx_start = nx_start_d;
    long glob_i = i + nx_start;
    long idx = k + (nz * (j + (i*ny))); 
    
    if(comp_begin >= comp_end)
        return;
    
    comp_begin += idx;
    phi0_begin += idx;

    const double rad2 = (ppt_size * ppt_size);

    const double cx1 = centx[0];
    const double cx2 = centx[1];
    const double cy1 = centy[0];
    const double cy2 = centy[1];
    const double cz1 = centz[0];
    const double cz2 = centz[1];
    
    bool in0 = ((glob_i - cx)*(glob_i - cx) + (j - cy)*(j - cy) + (k - cz)*(k - cz) < rad2);
    
    bool in1 = ((glob_i - cx1)*(glob_i - cx1) + (j - cy1)*(j - cy1) + (k - cz1)*(k - cz1) < rad2);
    bool in2 = ((glob_i - cx2)*(glob_i - cx2) + (j - cy2)*(j - cy2) + (k - cz2)*(k - cz2) < rad2);
    
    if (in0) 
    {  // only if current thread is inside the nucleus
        if (in0 == in1) 
        {
            phi0_begin->x = 1.0; phi0_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in2)
        {
            phi0_begin->x = 1.0; phi0_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
    }

}

///// WORKS only for 1 and 2 GPUS.
__global__ void Create_QUAD_nuclei(BoxIterator<cufftDoubleComplex> comp_begin,
                                   BoxIterator<cufftDoubleComplex> comp_end,
                                   BoxIterator<cufftDoubleComplex> phi0_begin,
                                   BoxIterator<cufftDoubleComplex> phi1_begin,
                                   BoxIterator<cufftDoubleComplex> phi2_begin,
                                   BoxIterator<cufftDoubleComplex> phi3_begin,
                                   double *c_eq, double rad, double* centx, double* centy,
                                   double* centz, double cx, double cy, double cz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int ny = ny_d;
    const int nz = nz_d;
    const int nx_start = nx_start_d;
    long glob_i = i + nx_start;
    long idx = k + (nz * (j + (i*ny))); 
    
    if(comp_begin >= comp_end)
        return;
    
    comp_begin += idx;
    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;
    
    const double ppt_size = rad;
    const double rad2 = (ppt_size * ppt_size);

    const double cx1 = centx[0];
    const double cx2 = centx[1];
    const double cx3 = centx[2];
    const double cx4 = centx[3];
    
    const double cy1 = centy[0];
    const double cy2 = centy[1];
    const double cy3 = centy[2];
    const double cy4 = centy[3];

    const double cz1 = centz[0];
    const double cz2 = centz[1];
    const double cz3 = centz[2];
    const double cz4 = centz[3];
    
    bool in1 = ((glob_i - cx1)*(glob_i - cx1) + (j - cy1)*(j - cy1) + (k - cz1)*(k - cz1) < rad2);
    bool in2 = ((glob_i - cx2)*(glob_i - cx2) + (j - cy2)*(j - cy2) + (k - cz2)*(k - cz2) < rad2);
    bool in3 = ((glob_i - cx3)*(glob_i - cx3) + (j - cy3)*(j - cy3) + (k - cz3)*(k - cz3) < rad2);
    bool in4 = ((glob_i - cx4)*(glob_i - cx4) + (j - cy4)*(j - cy4) + (k - cz4)*(k - cz4) < rad2);
    
    const double cx0 = cx;
    const double cy0 = cy;
    const double cz0 = cz;
    
    bool in0 = ((glob_i - cx0)*(glob_i - cx0) + (j - cy0)*(j - cy0) + (k - cz0)*(k - cz0) < rad2);
    
    if (in0) 
    {  // only if current thread is inside the nucleus
        if (in0 == in1) 
        {
            phi0_begin->x = 1.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in2)
        {
            phi1_begin->x = 1.0; phi1_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in3)
        {
            phi2_begin->x = 1.0; phi2_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in4) 
        {
            phi3_begin->x = 1.0; phi3_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
    }
}

__global__ void Create_QUAD_nuclei2(BoxIterator<cufftDoubleComplex> comp_begin,
                                   BoxIterator<cufftDoubleComplex> comp_end,
                                   BoxIterator<cufftDoubleComplex> phi0_begin,
                                   BoxIterator<cufftDoubleComplex> phi1_begin,
                                   BoxIterator<cufftDoubleComplex> phi2_begin,
                                   BoxIterator<cufftDoubleComplex> phi3_begin,
                                   double *c_eq, double c0, double rad, double* centx, double* centy,
                                   double* centz, double cx, double cy, double cz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    const int ny = ny_d;
    const int nz = nz_d;
    const int nx_start = nx_start_d;
    long glob_i = i + nx_start;
    long idx = k + (nz * (j + (i*ny))); 
    
    if(comp_begin >= comp_end)
        return;
    
    comp_begin += idx;
    phi0_begin += idx;
    phi1_begin += idx;
    phi2_begin += idx;
    phi3_begin += idx;
    
    const double ppt_size = rad;
    const double rad2 = (ppt_size * ppt_size);

    const double cx1 = centx[0];
    const double cx2 = centx[1];
    const double cx3 = centx[2];
    const double cx4 = centx[3];
    const double cx5 = centx[4];
    const double cx6 = centx[5];
    const double cx7 = centx[6];
    const double cx8 = centx[7];
    
    const double cy1 = centy[0];
    const double cy2 = centy[1];
    const double cy3 = centy[2];
    const double cy4 = centy[3];
    const double cy5 = centy[4];
    const double cy6 = centy[5];
    const double cy7 = centy[6];
    const double cy8 = centy[7];

    const double cz1 = centz[0];
    const double cz2 = centz[1];
    const double cz3 = centz[2];
    const double cz4 = centz[3];
    const double cz5 = centz[4];
    const double cz6 = centz[5];
    const double cz7 = centz[6];
    const double cz8 = centz[7];
    
    bool in1 = ((glob_i - cx1)*(glob_i - cx1) + (j - cy1)*(j - cy1) + (k - cz1)*(k - cz1) < rad2);
    bool in2 = ((glob_i - cx2)*(glob_i - cx2) + (j - cy2)*(j - cy2) + (k - cz2)*(k - cz2) < rad2);
    bool in3 = ((glob_i - cx3)*(glob_i - cx3) + (j - cy3)*(j - cy3) + (k - cz3)*(k - cz3) < rad2);
    bool in4 = ((glob_i - cx4)*(glob_i - cx4) + (j - cy4)*(j - cy4) + (k - cz4)*(k - cz4) < rad2);
    bool in5 = ((glob_i - cx5)*(glob_i - cx5) + (j - cy5)*(j - cy5) + (k - cz5)*(k - cz5) < rad2);
    bool in6 = ((glob_i - cx6)*(glob_i - cx6) + (j - cy6)*(j - cy6) + (k - cz6)*(k - cz6) < rad2);
    bool in7 = ((glob_i - cx7)*(glob_i - cx7) + (j - cy7)*(j - cy7) + (k - cz7)*(k - cz7) < rad2);
    bool in8 = ((glob_i - cx8)*(glob_i - cx8) + (j - cy8)*(j - cy8) + (k - cz8)*(k - cz8) < rad2);
    
    const double cx0 = cx;
    const double cy0 = cy;
    const double cz0 = cz;
    
    bool in0 = ((glob_i - cx0)*(glob_i - cx0) + (j - cy0)*(j - cy0) + (k - cz0)*(k - cz0) < rad2);
    
    if (in0) 
    {  // only if current thread is inside the nucleus
        if (in0 == in1) 
        {
            phi0_begin->x = 1.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in2)
        {
            phi1_begin->x = 1.0; phi1_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in3)
        {
            phi2_begin->x = 1.0; phi2_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        } 
        else if (in0 == in4) 
        {
            phi3_begin->x = 1.0; phi3_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
        else if (in0 == in5) 
        {
            phi0_begin->x = 1.0; phi0_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
        else if (in0 == in6) 
        {
            phi1_begin->x = 1.0; phi1_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
        else if (in0 == in7) 
        {
            phi2_begin->x = 1.0; phi2_begin->y = 0.0;
            phi3_begin->x = 0.0; phi3_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
        else if (in0 == in8) 
        {
            phi3_begin->x = 1.0; phi3_begin->y = 0.0;
            phi0_begin->x = 0.0; phi0_begin->y = 0.0;
            phi1_begin->x = 0.0; phi1_begin->y = 0.0;
            phi2_begin->x = 0.0; phi2_begin->y = 0.0;
            comp_begin->x = c_eq[1]; comp_begin->y = 0.0;
        }
    }
}

__global__ void CreateQuadNuclei(cufftDoubleComplex *comp, cufftDoubleComplex *phi0,
		                         cufftDoubleComplex *phi1, cufftDoubleComplex *phi2,
                                 cufftDoubleComplex *phi3,
                                 double *c_eq, double c0, double *ppt_size,
                                 double width, int create_nuclei, long nx,long ny)
{

	int i = threadIdx.x + blockIdx.x * blockDim.x;
	int j = threadIdx.y + blockIdx.y * blockDim.y;

	int idx = (j + i * (ny));


	double cx1, cy1, cx2, cy2, cx3, cy3, cx4, cy4;

	cx1 = (double) nx / 4.0;
	cy1 = (double) ny / 4.0;
	cx2 = (double) (nx) * 3.0 / 4.0;
	cy2 = (double) ny / 4.0;
	cx3 = (double) nx / 4.0;
	cy3 = (double) (ny) * 3.0 / 4.0;
	cx4 = (double) (nx) * 3.0 / 4.0;
	cy4 = (double) (ny) * 3.0 / 4.0;

    if (create_nuclei == 0)
    {
        if (idx < nx*ny)
        {
            if ((((double) i - cx1) * ((double) i - cx1)
                    + ((double) j - cy1) * ((double) j - cy1))
                    < ((*ppt_size) * (*ppt_size)))
            {

                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else if ((((double) i - cx2) * ((double) i - cx2)
                    + ((double) j - cy2) * ((double) j - cy2))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else if ((((double) i - cx3) * ((double) i - cx3)
                    + ((double) j - cy3) * ((double) j - cy3))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else if ((((double) i - cx4) * ((double) i - cx4)
                    + ((double) j - cy4) * ((double) j - cy4))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else
            {
                comp[idx].x = c0;
                comp[idx].y = 0.0;
            }
        }

    }


    if (create_nuclei == 1)
    {
        if (idx < nx*ny)
        {
            if ((((double) i - cx1) * ((double) i - cx1)
                    + ((double) j - cy1) * ((double) j - cy1))
                    < ((*ppt_size) * (*ppt_size)))
            {

                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else if ((((double) i - cx2) * ((double) i - cx2)
                    + ((double) j - cy2) * ((double) j - cy2))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi1[idx].x = 1.0;
                phi1[idx].y = 0.0;
            }
            else if ((((double) i - cx3) * ((double) i - cx3)
                    + ((double) j - cy3) * ((double) j - cy3))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi2[idx].x = 1.0;
                phi2[idx].y = 0.0;
            }
            else if ((((double) i - cx4) * ((double) i - cx4)
                    + ((double) j - cy4) * ((double) j - cy4))
                    < ((*ppt_size) * (*ppt_size)))
            {
                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi3[idx].x = 1.0;
                phi3[idx].y = 0.0;
            }
            else
            {
                comp[idx].x = c0;
                comp[idx].y = 0.0;
            }
        }

    }
    if (create_nuclei == 2)
    {
        double cx=0, cy=0;
        cx = (double) nx / 2.0;
        cy = (double) ny / 2.0;
        //// hw -> half width, hh -> half height.
        double hw = (double) (nx*width);
        double hh = (*ppt_size);

        if (idx < nx*ny)
        {
            if (((double) i >= cx-hh && (double) i <= cx+hh) &&
                ((double) j >= cy-hw && (double) j <= cy+hw))
            {

                comp[idx].x = c_eq[1];
                comp[idx].y = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;
            }
            else
            {
                comp[idx].x = c0;
                comp[idx].y = 0.0;
            }
        }
    }

	__syncthreads();
}

__global__ void CreateRandomNuclei(cufftDoubleComplex *phi0,
                                   cufftDoubleComplex *comp_d,
                                   double centx, double centy, double centz, double rad,
                                   double c_beta_eq, double c_alpha_eq, double c0,
                                   int *occupancy,long nx, long ny, long nz)
{

    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    if (idx<nx*ny*nz)
    {
        if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0) + pow((double) (k-centz),2.0))
                < (pow(2.0 * rad, 2.0)))
        {
            if ((pow((double) (i - centx), 2.0) + pow((double) (j - centy), 2.0) + pow((double) (k-centz),2.0))
                    < (pow(rad, 2.0)))
            {
                comp_d[idx].x   = c_beta_eq;
                comp_d[idx].y   = 0.0;
                phi0[idx].x = 1.0;
                phi0[idx].y = 0.0;

            }

            occupancy[idx] = 1;
        }
    }
	__syncthreads();
}

__global__ void Initialize_comp_phi(long nx, long ny, long nz,
		                            cufftDoubleComplex *comp_d,
                                    cufftDoubleComplex *phi0, cufftDoubleComplex *phi1,
                                    cufftDoubleComplex *phi2, cufftDoubleComplex *phi3,
                                    double c0)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    if (idx<nx*ny*nz)
    {
        comp_d[idx].x = c0;
        comp_d[idx].y = 0.0;
		phi0[idx].x = 0.0;
		phi0[idx].y = 0.0;
		phi1[idx].x = 0.0;
		phi1[idx].y = 0.0;
		phi2[idx].x = 0.0;
		phi2[idx].y = 0.0;
		phi3[idx].x = 0.0;
		phi3[idx].y = 0.0;
	}
    __syncthreads();
}

*/

void Init_Conf(cudaLibXtDesc *comp, cudaLibXtDesc *phi0, cudaLibXtDesc *phi1,
               cudaLibXtDesc *phi2, cudaLibXtDesc *phi3)
{
    auto [comp_begin_r, comp_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)comp->descriptor->data[0]);
    
    auto [phi0_begin_r, phi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi0->descriptor->data[0]);

    auto [phi1_begin_r, phi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi1->descriptor->data[0]);

    
    auto [phi2_begin_r, phi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi2->descriptor->data[0]);

    auto [phi3_begin_r, phi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi3->descriptor->data[0]);
	double C11m, C12m, C44m;
	double C11p, C12p, C44p;
	long SEED = -787349927;
	//long Blocks_X, Blocks_Y, Blocks_Z;
	//long Thread_X, Thread_Y, Thread_Z;
	double ran(long *idum);
	
    //////Finding Grid size
	Num_of_blocks = (nx * ny * nz) / (NUM_THREADS_X * NUM_THREADS_Y * NUM_THREADS_Z);
	Blocks_X = (long) ceil(pow(Num_of_blocks, (1.0/3.0)));
	Blocks_Y = Blocks_X;
	Blocks_Z = Blocks_X;
	Thread_X = NUM_THREADS_X;
	Thread_Y = NUM_THREADS_Y;
	Thread_Z = NUM_THREADS_Z;
	Gridsize = dim3(Blocks_X, Blocks_Y, Blocks_Z);
	Blocksize = dim3(Thread_X, Thread_Y, Thread_Z);
    
    if(rank == 0)
    {
        printf("Grid Dimensions of GPU :  (%d,%ld, %ld, %ld)\n", rank, 
                    Blocks_X, Blocks_Y, Blocks_Z);
        printf("Block Dimensions of GPU : (%d,%ld, %ld, %ld)\n", rank, 
                    Thread_X, Thread_Y, Thread_Z);
    }

    Compute_f0_c_eq<<<1,1>>>(f0, c_eq, f0A, f0B,Vm, c_alpha_eq, c_beta_eq);
    
	if (initflag == 1)
    {

		// Generating Single particle of given size at center of the box.
		if (create_nuclei == 0)
        {
			//FindCriticalNucleus<<<1, 1>>>(f0A, Vm, c0, c_alpha_eq,
			//        c_beta_eq, mu_m, mu_p, nu_m, nu_p,
			//        epszero, ppt_size_d, gamma_intf,
			//        elast_int);
			//CUDA_CHECK(cudaMemcpy(&ppt_size, ppt_size_d,
			//            sizeof(double), cudaMemcpyDeviceToHost));
			//ppt_size /= dx;
			//CUDA_CHECK(cudaMemcpy(ppt_size_d, &ppt_size, sizeof(double),
			//				cudaMemcpyHostToDevice));
            if (rank == 0)
            {
                printf("Nondimensional precipitate radius = %lf\n", ppt_size_h);
                double centx, centy, centz;
                centx = nx / 2;
                centy = ny / 2;
                centz = nz / 2;
     
                CreateNuclei_h(glob_comp, glob_phi0, c_beta_eq, c0, 
                                ppt_size_h, centx, centy, centz, nx, ny, nz);
            }
            	
            //CreateNuclei<<<Gridsize,Blocksize>>>(comp_begin_r, comp_end_r,
            //                                     phi0_begin_r, phi0_end_r, c_eq, c0,
            //                                     ppt_size, centx, centy, centz,
            //                                     nx_start, ny, nz);
            
		}
    
		// Particle of critical nucleus size at the center.

		//else if (create_nuclei == 1)
        //{
		//	FindCriticalNucleus<<<1, 1>>>(f0A, Vm, c0, c_alpha_eq, c_beta_eq,
		//			mu_m, mu_p, nu_m, nu_p, epszero, ppt_size, gamma_intf,
		//			elast_int);
		//	CUDA_CHECK(cudaMemcpy(&ppt_size_h, ppt_size, sizeof(double),
        //                    cudaMemcpyDeviceToHost));
		//	ppt_size_h /= dx;
		//	CUDA_CHECK(cudaMemcpy(ppt_size, &ppt_size_h, sizeof(double),
		//					cudaMemcpyHostToDevice));
		//	printf("Nondimensional precipitate radius = %lf\n", ppt_size_h);
		//	double centx, centy;
		//	centx = nx / 2;
		//	centy = ny / 2;
		//	centy = nz / 2;
		//	CreateNuclei<<<Gridsize,Blocksize>>>(nx, ny, nz,centx, centy,centz,
		//		                                 ppt_size, comp, phi0,
        //                                         c_eq, c0);
		//}

		// Generating random particle distribution for given volume fraction
        
        else if (create_nuclei == 2)
        {
            if (rank == 0)
            {
                int *overlap_h, f;
                int ppts[4] = {0};

                occupancy_h = (int*) calloc ((nx*ny*nz), sizeof(int)); 
                overlap_h = (int*) calloc (1, sizeof(int)); 

                int part = 1;
                time_t current_time = time(NULL);
                seed += (int)current_time;
                for (i=0; i <nx*ny*nz; i++)
                {
                    glob_comp[i].x = c0;
                    glob_comp[i].y = 0.0;
                }

                while (part < NFP)
                {
                    double centx = (double) nx * ran(&SEED);
                    double centy = (double) ny * ran(&SEED);
                    double centz = (double) nz * ran(&SEED);
                    
                    double mdev = 0.2 * ppt_size_h;
                    double rad = ppt_size_h + (2.0 * ran(&SEED) - 1.0) * mdev;

                    if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                            || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                            || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                        continue;
                    
                    CheckOverlap_h(overlap_h, occupancy_h, centx,centy, centz, ppt_size_h, 
                                   nx, ny, nz); 
                    
                    if (overlap_h[0] == 0)
                    {
                        time_t c_t = time(NULL);
                        seed += (int)c_t;
                        srand(seed);
                        f = rand()%4;
                        
                        if (equal_nofps == 1)
                        {
                            proceed = 1;
                            if (f == 0)
                                ppts[0] += 1;
                            else if (f == 1)
                                ppts[1] += 1;
                            else if (f == 2)
                                ppts[2] += 1;
                            else if (f == 3)
                                ppts[3] += 1;
                            
                            for (i=0; i<4; i++)
                            {
                                if ((ppts[i] >= NFP/4 ) && (i == f))
                                    proceed = -1;
                            }
                            if (proceed == 1)
                            {
                                CreateMVrandom_Nuclei_h(glob_comp, glob_phi0, glob_phi1, glob_phi2, glob_phi3,
                                                        centx,centy, 
                                                        centz, ppt_size_h,c_beta_eq,c_alpha_eq,c0,occupancy_h, 
                                                        nx, ny, nz, f);

                                part++;
                            }
                            else 
                                overlap_h[0] = 0;	
                                continue;

                        }
                        else if (equal_nofps == 0)
                        {
                            CreateMVrandom_Nuclei_h(glob_comp, glob_phi0, glob_phi1, glob_phi2, glob_phi3,
                                                    centx,centy, 
                                                    centz, ppt_size_h,c_beta_eq,c_alpha_eq,c0,occupancy_h, 
                                                    nx, ny, nz, f);

                            part++;
                        }
                    }
                    else
                    {
                        overlap_h[0] = 0;	
                        continue;
                    }
                }
            }
		}
        else if (create_nuclei == 3)
        {
            if (rank == 0)
            {
                int *overlap;int *occupancy;
                int f, part = 0;
                cufftDoubleComplex *comp_d, *phi0_d, *phi1_d, *phi2_d, *phi3_d;
                CUDA_CHECK(cudaMalloc((void**) &comp_d, (nx*ny*nz) * sizeof(*comp_d)));
                CUDA_CHECK(cudaMalloc((void**) &phi0_d, (nx*ny*nz) * sizeof(*phi0_d)));
                CUDA_CHECK(cudaMalloc((void**) &phi1_d, (nx*ny*nz) * sizeof(*phi1_d)));
                CUDA_CHECK(cudaMalloc((void**) &phi2_d, (nx*ny*nz) * sizeof(*phi2_d)));
                CUDA_CHECK(cudaMalloc((void**) &phi3_d, (nx*ny*nz) * sizeof(*phi3_d)));
                
                CUDA_CHECK(cudaMemset(comp_d, 0, (nx*ny*nz) * sizeof(*comp_d)));
                CUDA_CHECK(cudaMemset(phi0_d, 0, (nx*ny*nz) * sizeof(*phi0_d)));
                CUDA_CHECK(cudaMemset(phi1_d, 0, (nx*ny*nz) * sizeof(*phi1_d)));
                CUDA_CHECK(cudaMemset(phi2_d, 0, (nx*ny*nz) * sizeof(*phi2_d)));
                CUDA_CHECK(cudaMemset(phi3_d, 0, (nx*ny*nz) * sizeof(*phi3_d)));
                
                CUDA_CHECK(cudaMalloc((void**) &occupancy, (nx*ny*nz) * sizeof(int)));
                CUDA_CHECK(cudaMemset(occupancy, 0, (nx*ny*nz) * sizeof(int)));
                CUDA_CHECK(cudaMallocManaged((void**) &overlap, sizeof(int)));
                CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                 
                Initialize_comp<<<Gridsize, Blocksize>>>(comp_d, c0);
                
                time_t current_time = time(NULL);
                seed += (int)current_time;
                while (part < NFP)
                {
                    double centx = (double) nx * ran(&SEED);
                    double centy = (double) ny * ran(&SEED);
                    double centz = (double) nz * ran(&SEED);
                    double mdev = 0.2 * ppt_size_h;
                    double rad = ppt_size_h + (2.0 * ran(&SEED) - 1.0) * mdev;

                    if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                            || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                            || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                        continue;
                    CheckOverlap<<<Gridsize,Blocksize>>>(nx, ny,nz, centx, centy, centz,rad, occupancy, overlap);
                    CUDA_CHECK(cudaStreamSynchronize(0));
                    if (*overlap == 0)
                    {
                        time_t c_t = time(NULL);
                        seed += (int)c_t;
                        srand(seed);
                        f = rand()%4;

                        CreateMVRandomNuclei<<<Gridsize,Blocksize>>>(comp_d, phi0_d, phi1_d, phi2_d, phi3_d, centx,centy,
                                                                     centz,rad,c_beta_eq, c_alpha_eq, c0, occupancy,f); 
                        part++;
                    }
                    else
                    {
                        CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                        continue;
                    }
                }

                CUDA_CHECK(cudaMemcpy(glob_comp, comp_d, (nx*ny*nz)*sizeof(cufftDoubleComplex),cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(glob_phi0, phi0_d, (nx*ny*nz)*sizeof(cufftDoubleComplex),cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(glob_phi1, phi1_d, (nx*ny*nz)*sizeof(cufftDoubleComplex),cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(glob_phi2, phi2_d, (nx*ny*nz)*sizeof(cufftDoubleComplex),cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(glob_phi3, phi3_d, (nx*ny*nz)*sizeof(cufftDoubleComplex),cudaMemcpyDeviceToHost));
                
                CUDA_CHECK(cudaFree(overlap));
                CUDA_CHECK(cudaFree(occupancy));
                CUDA_CHECK(cudaFree(comp_d));
                CUDA_CHECK(cudaFree(phi0_d));
                CUDA_CHECK(cudaFree(phi1_d));
                CUDA_CHECK(cudaFree(phi2_d));
                CUDA_CHECK(cudaFree(phi3_d));
            }
            
            MPI_Barrier(comm);
        }
        else if (create_nuclei == 4)
        {
            int *overlap;int *occupancy;
            int f, part = 0;

            CUDA_CHECK(cudaMalloc((void**) &occupancy, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMemset(occupancy, 0, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMallocManaged((void**) &overlap, sizeof(int)));
            CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
            
            
            Initialize_MGPU<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,phi0_begin_r, phi1_begin_r,
                                                     phi2_begin_r, phi3_begin_r, c0);
            //CUDA_CHECK(cudaStreamSynchronize(0));
     
            double centx, centy, centz, rad, mdev; 
            time_t current_time = time(NULL);
            seed += (int)current_time;
            int *f_list;

            if (equal_nofps == 1) 
            {
                f_list = (int*) malloc(NFP * sizeof(int));
                if (rank == 0) 
                {
                    for (int i = 0; i < NFP; i++)
                        f_list[i] = i % 4; 
                    for (int i = NFP - 1; i > 0; i--) 
                    {
                        int j = rand() % (i + 1);
                        int tmp = f_list[i];
                        f_list[i] = f_list[j];
                        f_list[j] = tmp;
                    }
                }
                MPI_Bcast(f_list, NFP, MPI_INT, 0, comm);
            }

            //SEED = seed;
            //srand(seed);
            while (part < NFP)
            {
                if (rank == 0)
                {
                    centx = (double) nx * ran(&SEED);
                    centy = (double) ny * ran(&SEED);
                    centz = (double) nz * ran(&SEED);
                    mdev = 0.2 * ppt_size_h;
                    rad = ppt_size_h + (2.0 * ran(&SEED) - 1.0) * mdev;
                }
                
                MPI_Bcast(&centx, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centy, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centz, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&rad,   1, MPI_DOUBLE, 0, comm);

                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                CheckOverlap_MGPU<<<Gridsize,Blocksize>>>(centx, centy, centz,rad, occupancy, overlap);
                ncclAllReduce(overlap, overlap, 1, ncclDouble, ncclMax, nccl_comm, 0);
                CUDA_CHECK(cudaDeviceSynchronize()); 
                 
                if (*overlap == 0)
                {
                    if (rank == 0)
                    {
                        if (equal_nofps == 0)
                        {
                            time_t c_t = time(NULL);
                            seed += (int)c_t;
                            srand(seed);
                        }
                        f = (equal_nofps) ? f_list[part] : (rand() % 4);
                        part++;
                        printf("Particle number is: %d\n", part);
                    }
                    
                    MPI_Bcast(&f, 1, MPI_INT, 0, comm);
                    MPI_Bcast(&part, 1, MPI_INT, 0, comm);

                    if (centx + rad >= nx_start && centx - rad < nx_end)
                        CreateMVRandomNuclei_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r,phi1_begin_r,
                                                                          phi2_begin_r,phi3_begin_r,centx,centy,
                                                                          centz,rad,c_beta_eq,c_alpha_eq, c0,occupancy,f); 
                    CUDA_CHECK(cudaDeviceSynchronize());
                    MPI_Barrier(comm);
                }
                else
                {
                    CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                    continue;
                }
                
            }
            
            CUDA_CHECK(cudaFree(overlap));
            CUDA_CHECK(cudaFree(occupancy));
        }     
        else if (create_nuclei == 5)
        {
            int *overlap;int *occupancy;
            int f, part = 0;

            CUDA_CHECK(cudaMalloc((void**) &occupancy, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMemset(occupancy, 0, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMallocManaged((void**) &overlap, sizeof(int)));
            CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
            
            
            Initialize_MGPU<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,phi0_begin_r, phi1_begin_r,
                                                     phi2_begin_r, phi3_begin_r, c0);
            //CUDA_CHECK(cudaStreamSynchronize(0));
     
            double centx, centy, centz, rad, mdev; 
            //time_t current_time = time(NULL);
            //seed += (int)current_time;
            int *f_list;

            if (equal_nofps == 1) 
            {
                f_list = (int*) malloc(NFP * sizeof(int));
                if (rank == 0) 
                {
                    for (int i = 0; i < NFP; i++)
                        f_list[i] = i % 4; 
                    for (int i = NFP - 1; i > 0; i--) 
                    {
                        int j = rand() % (i + 1);
                        int tmp = f_list[i];
                        f_list[i] = f_list[j];
                        f_list[j] = tmp;
                    }
                }
                MPI_Bcast(f_list, NFP, MPI_INT, 0, comm);
            }

            SEED = seed;
            srand(seed);
            while (part < NFP)
            {
                if (rank == 0)
                {
                    centx = (double) nx * ran(&SEED);
                    centy = (double) ny * ran(&SEED);
                    centz = (double) nz * ran(&SEED);
                    mdev = 0.2 * ppt_size_h;
                    rad = ppt_size_h + (2.0 * ran(&SEED) - 1.0) * mdev;
                }
                
                MPI_Bcast(&centx, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centy, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centz, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&rad,   1, MPI_DOUBLE, 0, comm);

                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                CheckOverlap_MGPU<<<Gridsize,Blocksize>>>(centx, centy, centz,rad, occupancy, overlap);
                ncclAllReduce(overlap, overlap, 1, ncclDouble, ncclMax, nccl_comm, 0);
                CUDA_CHECK(cudaDeviceSynchronize()); 
                 
                if (*overlap == 0)
                {
                    if (rank == 0)
                    {
                        if (equal_nofps == 0)
                        {
                            //time_t c_t = time(NULL);
                            //seed += (int)c_t;
                            //srand(seed);
                        }
                        f = (equal_nofps) ? f_list[part] : (rand() % 4);
                        part++;
                        printf("Particle number is: %d\n", part);
                    }
                    
                    MPI_Bcast(&f, 1, MPI_INT, 0, comm);
                    MPI_Bcast(&part, 1, MPI_INT, 0, comm);

                    if (centx + rad >= nx_start && centx - rad < nx_end)
                        CreateMVRandomNuclei_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r,phi1_begin_r,
                                                                          phi2_begin_r,phi3_begin_r,centx,centy,
                                                                          centz,rad,c_beta_eq,c_alpha_eq, c0,occupancy,f); 
                    CUDA_CHECK(cudaDeviceSynchronize());
                    MPI_Barrier(comm);
                }
                else
                {
                    CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                    continue;
                }
                
            }
            
            CUDA_CHECK(cudaFree(overlap));
            CUDA_CHECK(cudaFree(occupancy));
        }     
        else if (create_nuclei == 6)
        {// Allocate once OUTSIDE the while loop
            
            int *overlap;int *occupancy;
            int f, part = 0;

            CUDA_CHECK(cudaMalloc((void**) &occupancy, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMemset(occupancy, 0, (nx_local*ny*nz) * sizeof(int)));
            CUDA_CHECK(cudaMallocManaged((void**) &overlap, sizeof(int)));
            CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
            
            
            Initialize_MGPU<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,phi0_begin_r, phi1_begin_r,
                                                     phi2_begin_r, phi3_begin_r, c0);
            //CUDA_CHECK(cudaStreamSynchronize(0));
     
            double centx, centy, centz, rad, mdev; 
            
            int *nearby_flags;
            CUDA_CHECK(cudaMallocManaged((void**)&nearby_flags, 4 * sizeof(int)));

            double variant_exclusion_radius = spacing * ppt_size_h; // tune this as needed

            while (part < NFP)
            {
                if (rank == 0)
                {
                    centx = (double)nx * ran(&SEED);
                    centy = (double)ny * ran(&SEED);
                    centz = (double)nz * ran(&SEED);
                    mdev  = 0.2 * ppt_size_h;
                    rad   = ppt_size_h + (2.0 * ran(&SEED) - 1.0) * mdev;
                }

                MPI_Bcast(&centx, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centy, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&centz, 1, MPI_DOUBLE, 0, comm);
                MPI_Bcast(&rad,   1, MPI_DOUBLE, 0, comm);

                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                 || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                 || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;

                // ---- Original overlap check (unchanged) ----
                CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                CheckOverlap_MGPU<<<Gridsize, Blocksize>>>(centx, centy, centz, rad, occupancy, overlap);
                ncclAllReduce(overlap, overlap, 1, ncclInt, ncclMax, nccl_comm, 0);
                CUDA_CHECK(cudaDeviceSynchronize());

                if (*overlap != 0)
                {
                    CUDA_CHECK(cudaMemset(overlap, 0, sizeof(int)));
                    continue;
                }

                // ---- Overlap passed: now sense nearby variants ----
                CUDA_CHECK(cudaMemset(nearby_flags, 0, 4 * sizeof(int)));

                GetNearbyVariants_MGPU<<<Gridsize, Blocksize>>>(centx, centy, centz, variant_exclusion_radius, occupancy,
                                                                phi0_begin_r, phi1_begin_r, phi2_begin_r, phi3_begin_r, nearby_flags, 
                                                                nx_local, nx_start, ny, nz);

                ncclAllReduce(nearby_flags, nearby_flags, 4, ncclInt, ncclMax, nccl_comm, 0);
                CUDA_CHECK(cudaDeviceSynchronize());

                if (rank == 0)
                {
                    // Build candidate list: variants NOT present nearby
                    int candidates[4];
                    int n_candidates = 0;

                    for (int v = 0; v < 4; v++)
                    {
                        if (nearby_flags[v] == 0)       // variant v is NOT nearby → allowed
                            candidates[n_candidates++] = v;
                    }

                    if (n_candidates == 0)
                    {
                        // All 4 variants are nearby — no valid variant exists
                        // Options:
                        //   (a) skip this position entirely → continue
                        //   (b) pick least-present variant (if you track counts)
                        // Here we just skip and try a new random position
                        printf("Position (%f,%f,%f): all variants nearby, skipping.\n",
                               centx, centy, centz);
                        f = -1;  // sentinel
                    }
                    else
                    {
                        // Pick randomly from allowed candidates
                        f = candidates[rand() % n_candidates];
                        part++;
                        printf("Particle %d at (%.1f,%.1f,%.1f): "
                               "nearby_flags=[%d %d %d %d] -> assigned variant %d\n",
                               part, centx, centy, centz,
                               nearby_flags[0], nearby_flags[1],
                               nearby_flags[2], nearby_flags[3], f);
                    }
                }

                MPI_Bcast(&f,    1, MPI_INT, 0, comm);
                MPI_Bcast(&part, 1, MPI_INT, 0, comm);

                if (f == -1) continue;   // all variants were nearby, retry position

                if (centx + rad >= nx_start && centx - rad < nx_end)
                    CreateMVRandomNuclei_MGPU<<<Gridsize, Blocksize>>>(
                        comp_begin_r, comp_end_r,
                        phi0_begin_r, phi1_begin_r, phi2_begin_r, phi3_begin_r,
                        centx, centy, centz, rad,
                        c_beta_eq, c_alpha_eq, c0, occupancy, f
                    );

                CUDA_CHECK(cudaDeviceSynchronize());
                MPI_Barrier(comm);
            }

            CUDA_CHECK(cudaFree(nearby_flags));
            CUDA_CHECK(cudaFree(overlap));
            CUDA_CHECK(cudaFree(occupancy));


        }
        
	}

	else if (initflag == 2)
    {
        //// 4 spheres at each quarter of SV
        if (create_nuclei == 0)
        {
            Initialize_MGPU_SV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, c0, ny,nz);
            
            double *cx; double *cy; double *cz;
            cx = (double*) calloc (4, sizeof(double));
            cy = (double*) calloc (4, sizeof(double));
            cz = (double*) calloc (4, sizeof(double));
            
            double rad = ppt_size_h;
            cx[0] = (double) nx / 4.0;       cy[0] = 3.0 * (double) ny / 4.0;  cz[0] = 3.0 * (double) nz / 4.0;

            cx[1] = 3.0 * (double) nx / 4.0; cy[1] = 3.0 * (double) ny / 4.0;  cz[1] = (double) nz / 4.0;

            cx[2] = 3.0 * (double) nx / 4.0; cy[2] = (double) ny / 4.0;        cz[2] = 3.0 * (double) nz / 4.0;

            cx[3] = (double) nx / 4.0;       cy[3] = (double) ny / 4.0;        cz[3] = (double) nz / 4.0; 
            
            for (i=0; i<4; i++)
            {
                double centx = cx[i]; double centy = cy[i]; double centz = cz[i];
                
                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                if (centx + rad >= nx_start && centx - rad < nx_end)
                        Create_QUAD_SV_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, centx,centy,
                                                                 centz,rad,c_beta_eq,c_alpha_eq);

            }

        }
        
        //// 4 spheres at each quarter, MV
        if (create_nuclei == 1)
        {
            Initialize_MGPU<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,phi0_begin_r, phi1_begin_r,
                                                     phi2_begin_r, phi3_begin_r, c0);
            
            double *cx; double *cy; double *cz;
            cx = (double*) calloc (4, sizeof(double));
            cy = (double*) calloc (4, sizeof(double));
            cz = (double*) calloc (4, sizeof(double));
            
            double rad = ppt_size_h;
            
            cx[0] = (double) nx / 4.0;       cy[0] = (double) ny / 4.0;       cz[0] = (double) nz / 2.0; 
            cx[1] = 3.0 * (double) nx / 4.0; cy[1] = (double) ny / 4.0;       cz[1] = (double) nz / 2.0; 
            cx[2] = (double) nx / 4.0;       cy[2] = 3.0 * (double) ny / 4.0; cz[2] = (double) nz / 2.0;
            cx[3] = 3.0 * (double) nx / 4.0; cy[3] = 3.0 * (double) ny / 4.0; cz[3] = (double) nz / 2.0;
            
            for (i=0; i<4; i++)
            {
                double centx = cx[i]; double centy = cy[i]; double centz = cz[i];
                
                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                if (centx + rad >= nx_start && centx - rad < nx_end)
                        Create_QUAD_MV_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, phi1_begin_r, 
                                                                    phi2_begin_r, phi3_begin_r,
                                                                    centx,centy, centz,rad,c_beta_eq,c_alpha_eq,i);

            }

        }
        
        //// 8 spheres at each quarter of SV
        if (create_nuclei == 2)
        {
            Initialize_MGPU_SV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, c0, ny,nz);
            
            double *cx; double *cy; double *cz;
            cx = (double*) calloc (8, sizeof(double));
            cy = (double*) calloc (8, sizeof(double));
            cz = (double*) calloc (8, sizeof(double));

            double rad = ppt_size_h;
            cx[0] = (double)nx / 4.0;        cy[0] = (double)ny / 4.0;        cz[0] = (double)nz / 4.0;
            cx[1] = 3.0*(double)nx / 4.0;    cy[1] = (double)ny / 4.0;        cz[1] = (double)nz / 4.0;
            cx[2] = (double)nx / 4.0;        cy[2] = 3.0*(double)ny / 4.0;    cz[2] = (double)nz / 4.0;
            cx[3] = 3.0*(double)nx / 4.0;    cy[3] = 3.0*(double)ny / 4.0;    cz[3] = (double)nz / 4.0;
            
            cx[4] = (double)nx / 4.0;        cy[4] = (double)ny / 4.0;        cz[4] = 3.0*(double)nz / 4.0;
            cx[5] = 3.0*(double)nx / 4.0;    cy[5] = (double)ny / 4.0;        cz[5] = 3.0*(double)nz / 4.0;
            cx[6] = (double)nx / 4.0;        cy[6] = 3.0*(double)ny / 4.0;    cz[6] = 3.0*(double)nz / 4.0;
            cx[7] = 3.0*(double)nx / 4.0;    cy[7] = 3.0*(double)ny / 4.0;    cz[7] = 3.0*(double)nz / 4.0;

            
            for (i=0; i<8; i++)
            {
                double centx = cx[i]; double centy = cy[i]; double centz = cz[i];
                
                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                if (centx + rad >= nx_start && centx - rad < nx_end)
                        Create_QUAD_SV_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, centx,centy,
                                                                 centz,rad,c_beta_eq,c_alpha_eq);

            }

        }
        
        //// Two spheres along ny/2.
        if (create_nuclei == 3)
        {
            Initialize_MGPU_SV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, c0, ny,nz);
            
            double *cx; double *cy; double *cz;
            cx = (double*) calloc (2, sizeof(double));
            cy = (double*) calloc (2, sizeof(double));
            cz = (double*) calloc (2, sizeof(double));
            
            double rad = ppt_size_h;
            cx[0] = (double) nx / 2.0; cy[0] = (double) ny / 4.0; cz[0] = (double) nz / 2.0; 
            cx[1] = (double) nx / 2.0; cy[1] = 3.0 * (double) ny / 4.0; cz[1] = (double) nz / 2.0; 
            
            for (i=0; i<2; i++)
            {
                double centx = cx[i]; double centy = cy[i]; double centz = cz[i];
                
                if (((centx - rad) < 0.0) || ((centx + rad) > (nx - 1))
                        || ((centy - rad) < 0.0) || ((centy + rad) > (ny - 1))
                        || ((centz - rad) < 0.0) || ((centz + rad) > (nz - 1)))
                    continue;
                
                if (centx + rad >= nx_start && centx - rad < nx_end)
                        Create_QUAD_SV_MGPU<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, centx,centy,
                                                                 centz,rad,c_beta_eq,c_alpha_eq);

            }

        }
        if (create_nuclei == 4)
        {
            Initialize_MGPU<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,phi0_begin_r, phi1_begin_r,
                                                     phi2_begin_r, phi3_begin_r, c0);
            
            Create_SELP<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, phi1_begin_r, 
                                                        phi2_begin_r, phi3_begin_r, ppt_size_h,c_beta_eq,c_alpha_eq,
                                                        c0, spacing, nx, ny, nz);
        
        }
        if (create_nuclei == 5)
        {
            Initialize_MGPU_SV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, c0, ny,nz);
            
            Create_SELP_SV<<<Gridsize,Blocksize>>>(comp_begin_r,comp_end_r,phi0_begin_r, 
                                                        ppt_size_h,c_beta_eq,c_alpha_eq,
                                                        c0, spacing, nx, ny, nz);
        
        }
    
    }
	 
	else if (initflag == 3)
    {
        double *comp_real, *phi0_real;
        double *phi1_real, *phi2_real, *phi3_real;
        comp_real = (double*) calloc (nx_local*ny*nz, sizeof(double));
        phi0_real = (double*) calloc (nx_local*ny*nz, sizeof(double));
        read_field(comp_real, nx_local, ny, nz, nx_start, nx, path, "COMP", "mpkks", restart, comm);
        read_field(phi0_real, nx_local, ny, nz, nx_start, nx, path, "PHI0", "mpkks", restart, comm);

        Move_R2D(comp_h, comp_real, nx_local,ny,nz);
        Move_R2D(phi0_h, phi0_real, nx_local,ny,nz);
        
        if (nof_variants == 4)
        {
            phi1_real = (double*) calloc (nx_local*ny*nz, sizeof(double));
            phi2_real = (double*) calloc (nx_local*ny*nz, sizeof(double));
            phi3_real = (double*) calloc (nx_local*ny*nz, sizeof(double));
            
            read_field(phi1_real, nx_local, ny, nz, nx_start, nx, path, "PHI1", "mpkks", restart, comm);
            read_field(phi2_real, nx_local, ny, nz, nx_start, nx, path, "PHI2", "mpkks", restart, comm);
            read_field(phi3_real, nx_local, ny, nz, nx_start, nx, path, "PHI3", "mpkks", restart, comm);
            
            Move_R2D(phi1_h, phi1_real, nx_local,ny,nz);
            Move_R2D(phi2_h, phi2_real, nx_local,ny,nz);
            Move_R2D(phi3_h, phi3_real, nx_local,ny,nz);
        }
        
        MPI_Barrier(comm);
    
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)comp, (void *)comp_h, H2D)); 
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi0, (void *)phi0_h, H2D)); 
        if (nof_variants == 4)
        {
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi1, (void *)phi1_h, H2D)); 
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi2, (void *)phi2_h, H2D)); 
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi3, (void *)phi3_h, H2D));
        }
        CUDA_CHECK(cudaDeviceSynchronize());

        free(comp_real);
        free(phi0_real);
        if (nof_variants == 4)
        {
            free(phi1_real);
            free(phi2_real);
            free(phi3_real);
        }

	}
     
    if (create_nuclei < 4 && initflag == 1)
    {
        if (rank == 0) 
        {
        // Root process sends data to all other processes

            for (int dest_rank = 1; dest_rank < size; dest_rank++) 
            {
               int offset = dest_rank * nx_local * ny * nz;

               MPI_Send(glob_comp + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 
                        dest_rank, 0, comm);
               MPI_Send(glob_phi0 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 
                        dest_rank, 0, comm);
               if (nof_variants == 4)
               {
                   MPI_Send(glob_phi1 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 
                            dest_rank, 0, comm);
                   MPI_Send(glob_phi2 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 
                            dest_rank, 0, comm);
                   MPI_Send(glob_phi3 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 
                            dest_rank, 0, comm); 
               }
            }
            // Root process copies its own chunk
            memcpy(comp_h, glob_comp, nx_local * ny * nz * sizeof(cufftDoubleComplex));
            memcpy(phi0_h, glob_phi0, nx_local * ny * nz * sizeof(cufftDoubleComplex));
            if (nof_variants == 4)
            {
                memcpy(phi1_h, glob_phi1, nx_local * ny * nz * sizeof(cufftDoubleComplex));
                memcpy(phi2_h, glob_phi2, nx_local * ny * nz * sizeof(cufftDoubleComplex));
                memcpy(phi3_h, glob_phi3, nx_local * ny * nz * sizeof(cufftDoubleComplex)); 
            }

        } 
        else 
        {
        // Other processes receive their chunk from the root
            MPI_Recv(comp_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm, 
                     MPI_STATUS_IGNORE);
            MPI_Recv(phi0_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm, 
                     MPI_STATUS_IGNORE);
            if (nof_variants == 4)
            {
                MPI_Recv(phi1_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm, 
                         MPI_STATUS_IGNORE);
                MPI_Recv(phi2_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm, 
                         MPI_STATUS_IGNORE);
                MPI_Recv(phi3_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm, 
                         MPI_STATUS_IGNORE);
            }

        }
        
        MPI_Barrier(comm);
        
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)comp, (void *)comp_h, H2D)); 
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi0, (void *)phi0_h, H2D));
        if (nof_variants == 4)
        {
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi1, (void *)phi1_h, H2D)); 
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi2, (void *)phi2_h, H2D)); 
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi3, (void *)phi3_h, H2D));
        }

    }

    if (elast_int == 1)
    {
        double factor = 6.242;
        if (elast_consts == 0)
        {
            if (Non_dim_calc == 1)
            {
                mu_m *= factor;
                mu_p *= factor;
            }

            C11m = (mu_m*(2.0 * (2.0 + Az_m) / (1.0 + Az_m)-
                    (1.0 - 4.0 * nu_m) / (1.0 - 2.0 * nu_m)));

            C12m = (mu_m*(2.0 * (Az_m / (1.0 + Az_m)) -
                     (1.0 - 4.0 * nu_m) / (1.0 - 2.0 * nu_m)));

            C44m = mu_m * (2.0 * Az_m / (1.0 + Az_m));

            C11p = (mu_p*(2.0*(2.0 + Az_p)/(1.0 + Az_p)-
                    (1.0 - 4.0 * nu_p)/(1.0 - 2.0 * nu_p)));

            C12p = (mu_p* (2.0*(Az_p/(1.0+Az_p))-
                    (1.0 - 4.0 * nu_p) / (1.0 - 2.0 * nu_p)));

            C44p = mu_p * (2.0*Az_p /(1.0 + Az_p));
        }

        else
        {
            if (Non_dim_calc == 1)
            {
                C11m = c11m * factor;
                C12m = c12m * factor;
                C44m = c44m * factor;

                C11p = c11p * factor;
                C12p = c12p * factor;
                C44p = c44p * factor;
            }
            else
            {
                C11m = c11m;
                C12m = c12m;
                C44m = c44m;

                C11p = c11p;
                C12p = c12p;
                C44p = c44p;

            }

        }
        if (elast_int == 1)
        {
            if (rank == 0)
            {
                printf("c11m=%le\t c12m=%le\t c44m=%le\n", C11m, C12m, C44m);
                printf("c11p=%le\t c12p=%le\t c44p=%le\n", C11p, C12p, C44p);
            }
        }
        if (EC_calc == 0)
        {
            Chom11 = 0.5*(C11p + C11m);
            Chom12 = 0.5*(C12p + C12m);
            Chom44 = 0.5*(C44p + C44m);

            Chet11 = 0.5*(C11p - C11m);
            Chet12 = 0.5*(C12p - C12m);
            Chet44 = 0.5*(C44p - C44m);
        }
        

        else if (EC_calc == 1)
        {
            Chom11 = C11m;
            Chom12 = C12m;
            Chom44 = C44m;

            Chet11 = C11p - Chom11;
            Chet12 = C12p - Chom12;
            Chet44 = C44p - Chom44;
        }
        
        if (rank == 0)
        {
            printf("Chom11=%le\t Chom12=%le\t Chom44=%le\n", Chom11, Chom12, Chom44);
            printf("Chet11=%le\t Chet12=%le\t Chet44=%le\n", Chet11, Chet12, Chet44);
        }
        if (appl_stress == 1)
        {
            for (int i=0;i<6;i++)
                sigappl_v_h[i] *= (factor*1.0e-03);
            printf("Applied stress vector:%le\t%le\t%le\t%le\t%le\t%le\n", sigappl_v_h[0], sigappl_v_h[1],
                                                                           sigappl_v_h[2], sigappl_v_h[3],
                                                                           sigappl_v_h[4], sigappl_v_h[5]);
        }
        
    }
    
    FindCrit_Ncl_size(ppt_size, f0A, Vm, c0, c_alpha_eq, c_beta_eq, mu_m, mu_p, nu_m, nu_p, 
                      epszero, gamma_intf, elast_int);
    
    printf("Critical Nucleus size is : %le\n", *ppt_size);

    if (((initflag == 1 && create_nuclei < 4) && ((VTK_out == 1 && MPI_out != 1) || VTK_out == 2)) && rank == 0)
    {
        printf("free glob vars from init\n");
        free(glob_comp);
        free(glob_phi0);
        if (nof_variants == 4)
        {
            free(glob_phi1);
            free(glob_phi2);
            free(glob_phi3);
        }
    }

    if ((initflag == 1 && create_nuclei < 4) || VTK_out != 1 || initflag == 3) 
    {
        free(comp_h);
        free(phi0_h);
        if (nof_variants == 4)
        {
            free(phi1_h);
            free(phi2_h);
            free(phi3_h);
        }
        if (rank == 0)
            printf("free local host vars from init\n");
    }
}

#undef IA
#undef IM
#undef AM
#undef IQ
#undef IR
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX

