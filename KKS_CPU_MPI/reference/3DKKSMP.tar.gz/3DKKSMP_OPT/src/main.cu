#include "../include/binary.h"
#include "get_input.cu"
#include "init_conf.cu"
#include "evolve.cu"
//#include "out_conf.cu"


void write_vtk_1d_engs(const char *filename,
                       double *ftotal, double *felas, 
                       int n, double dx)
{
    FILE *f = fopen(filename, "w");
    if (!f) {
        printf("Error: Cannot open %s for writing\n", filename);
        return;
    }

    fprintf(f, "# vtk DataFile Version 3.0\n");
    fprintf(f, "Phasefield Data\n");
    fprintf(f, "ASCII\n");
    fprintf(f, "DATASET STRUCTURED_POINTS\n");
    fprintf(f, "DIMENSIONS %d %d %d\n", n, 1, 1);
    fprintf(f, "ORIGIN 0 0 0\n");
    fprintf(f, "SPACING %le %le %le\n", dx, dx, dx);

    // Only ONE POINT_DATA allowed → number of points = n*1*1 = n
    fprintf(f, "POINT_DATA %d\n", n);

    // FTOTAL
    fprintf(f, "SCALARS FTOTAL float 1\n");
    fprintf(f, "LOOKUP_TABLE default\n");
    for (int i = 0; i < n; i++)
        fprintf(f, "%le\n", ftotal[i]);

    // FELAS
    fprintf(f, "SCALARS FELAS float 1\n");
    fprintf(f, "LOOKUP_TABLE default\n");
    for (int i = 0; i < n; i++)
        fprintf(f, "%le\n", felas[i]);

    //// FSURF
    //fprintf(f, "SCALARS FSURF float 1\n");
    //fprintf(f, "LOOKUP_TABLE default\n");
    //for (int i = 0; i < n; i++)
    //    fprintf(f, "%le\n", fsurf[i]);

    fclose(f);
    printf("VTK file written: %s\n", filename);
}
/*
void SetColor(int colorCode) 
{
    printf("\033[%dm", colorCode);
}

// Function to reset color
void ResetColor() {
    printf("\033[0m");
}
*/
__global__ void Calc_ftotal(double *ftotal, double *fchem, double *fgrad, double *felas,
                            long nx, long ny, long nz)
{
    int i = threadIdx.x + blockIdx.x*blockDim.x;
    int j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny))); 
    if (idx<nx*ny*nz)
    {
        ftotal[idx] = fchem[idx] + fgrad[idx] + felas[idx];

    }
}

void Calc_avg(double *x, double y, long nx, long ny, int f)
{
    y = 0.0;
    for(int i=0; i<nx*ny; i++)
    {
       y += x[i];
    }
    y /= nx*ny;
    if (f == 0)
        printf("fchem: %lf\n",y);
    else if (f == 1)
        printf("fgrad: %lf\n",y);
    else if (f ==2)
        printf("felas: %lf\n",y);

}
__global__ void Compute_kappa(double *kappa, double kpa, long np)
{
    for (int i=0; i<np; i++)
        kappa[i] = kpa;
}

/*
__global__ void Normalize(BoxIterator<cufftDoubleComplex> iter_begin,
                          BoxIterator<cufftDoubleComplex> iter_end,
                          long nx, long ny, long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    iter_begin += idx;

    if (iter_begin < iter_end)
    {
        *iter_begin = { ((iter_begin->x)/(double)(nx*ny*nz)), 0.0}; 
    }

    __syncthreads();
}

__global__ void Normalize_main(cufftDoubleComplex *x, long nx, long ny)
{
   long gid = (long)threadIdx.x + (long)blockDim.x*(long)blockIdx.x;
   long stride = (long) blockDim.x*(long)gridDim.x;
   long idx;
   for(idx = gid; idx<nx*ny; idx+=stride)
   {
       x[idx].x /= (double)(nx*ny);
       x[idx].y /= (double)(nx*ny);
   }
}
*/

int main (int argc, char **argv)
{
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(comm, &rank);
    MPI_Comm_size(comm, &size);
    
    MPI_Barrier(comm);


    char    finput[15] = "bin1ary";
    char    fnin[30], fnout[30];
    FILE    *fp;

    if (!(fp = fopen (finput, "r"))) {
        printf ("File:%s could not be opened\n", finput);
        exit (EXIT_FAILURE);
    }
    if(fscanf (fp, "%s", fnin)==1){
        printf("Input Parameters Filename:%s\n",fnin);
    }
    if(fscanf (fp, "%s", fnout)==1){
        printf("Output Parameters Filename:%s\n",fnout);
    }
    if (!(fpout = fopen (fnout, "w"))) {
        printf ("File:%s could not be opened\n", fnout);
        exit (EXIT_FAILURE);
    }

    fclose (fp);
    fclose (fpout);
    

    //Reading simulation parameters
    Get_Input_Parameters (fnin, fnout);
    savet = ( num_steps > 100 ) ? num_steps/10 : 1;
    
    int ndevices;
    //CUDA_CHECK(cudaGetDeviceCount(&ndevices));
    //CUDA_CHECK(cudaSetDevice(rank % ndevices));
    
    CUDA_CHECK(cudaGetDeviceCount(&ndevices));

    MPI_Comm node_comm;
    MPI_Comm_split_type(comm, MPI_COMM_TYPE_SHARED, 0, MPI_INFO_NULL, &node_comm);

    int local_rank;
    MPI_Comm_rank(node_comm, &local_rank);

    CUDA_CHECK(cudaSetDevice(local_rank % ndevices));
     
    ////Nccl specifc commands:
    ncclUniqueId id;
    if (rank == 0)
        ncclGetUniqueId(&id);
    
    MPI_Bcast(&id, sizeof(id), MPI_BYTE, 0, comm);
    ncclCommInitRank(&nccl_comm, size, id, rank);

    nx_start = slabs_displacement(nx, rank, size);
    nx_end = slabs_displacement(nx, rank + 1, size);
    nx_local = nx_end - nx_start;

    num_items = (nx_local * ny *nz);
    sizescale = 1.0 /(double)(nx*ny*nz);
    printf("Rank %d: nx_start = %ld, nx_end = %ld, nx_local = %ld\n", rank, nx_start, 
            nx_end, nx_local);

    CUFFT_CHECK(cufftCreate(&plan));
    CUFFT_CHECK(cufftMpAttachComm(plan, CUFFT_COMM_MPI, &comm));
    
    size_t workspace;
    CUFFT_CHECK(cufftMakePlan3d(plan, nx,ny,nz, CUFFT_Z2Z, &workspace));
    //CUFFT_CHECK(cufftMpMakePlan3d(plan, nx, ny, nz, CUFFT_Z2Z, &comm, CUFFT_COMM_MPI, &workspace));
 
    if (nof_variants == 1 || engs_out == 0)
    {
        ////Needed dummy plan for saving memory.
        CUFFT_CHECK(cufftCreate(&dummy_plan));
        size_t dummy_workspace;
        CUFFT_CHECK(cufftMakePlan3d(dummy_plan, 1,1,1, CUFFT_Z2Z, &dummy_workspace));
    }
    
    if (rank == 0)
        printf("==============PARAMS FROM MAIN FILE==================\n");
    //// Non-dimensioning.
    if (Non_dim_calc == 1)
    {
        dx *= Lconv; 
        dy *= Lconv;
        dz *= Lconv;
        if (Ln_dx == 1)
            Ln *= dx;
        diffusivity *= ((Lconv*Lconv)/Tconv); 
        gamma_intf *= (Econv/(Lconv*Lconv)); 
        Vm *= (Lconv*Lconv*Lconv); 
        f0A *= Econv;
        f0B *= Econv;
        //// Need curv in J/m^3 for L calc.
        f0_alpha = f0A /Vm;
        f0_beta = f0B/Vm;
        f0_alpha /= 2.0;
        f0_beta /= 2.0;
        Am = (f0A/Na);
        Ap = (f0B/Na);
        Am /= 2.0;
        Ap /= 2.0;
        Nv = (Na/Vm);
        
        if (rank == 0)
        {
            printf("Calc the Non-dim values:\n");
            printf("dx = %lf\n", dx);
            printf("dy = %lf\n", dy);
            printf("dz = %lf\n", dz);
            printf("dt = %lf\n", dt);
            printf("Ln = %lf\n", Ln);
            printf("Diffusivity = %lf\n", diffusivity);
            printf("Nv = %lf\n",Nv);
            printf("Intf_energy(eV/nm^2) = %lf\n",gamma_intf);
            printf("molar vol(nm^3) = %lf\n",Vm);
            printf("f0A (eV/mole) = %lf\n",f0A);
            printf("f0B (eV/mole)= %lf\n",f0B);
            printf("Am (eV/atom)= %le\n",Am);
            printf("Ap (eV/atom)= %le\n",Ap);
        }
    }
    else if (Non_dim_calc == 2)
    {
        //Vm *= (Lconv*Lconv*Lconv); 
        //f0A *= Econv;
        //f0B *= Econv;
        Am = f0A/Vm;
        Ap = f0B/Vm;

        if (rank == 0)
        {
            printf("dx = %le\n", dx);
            printf("dy = %le\n", dy);
            printf("dz = %le\n", dz);
            printf("dt = %le\n", dt);
            printf("Ln = %le\n", Ln);
            printf("Diffusivity = %le\n", diffusivity);
            printf("Nv = %lf\n",Nv);
            printf("Intf_energy = %le\n",gamma_intf);
            printf("molar vol = %le\n",Vm);
            printf("f0A = %le\n",f0A);
            printf("f0B = %le\n",f0B);
            printf("Am = %le\n",Am);
            printf("Ap = %le\n",Ap);
        }
    }
    else
    {
        Am = f0A;
        Ap = f0B;
        //Nv = (Na/Vm);
        if (rank == 0)
        {
            printf("dx = %le\n", dx);
            printf("dy = %le\n", dy);
            printf("dz = %le\n", dz);
            printf("dt = %le\n", dt);
            printf("Ln = %le\n", Ln);
            printf("Diffusivity = %le\n", diffusivity);
            printf("Nv = %lf\n",Nv);
            printf("Intf_energy = %le\n",gamma_intf);
            printf("molar vol = %le\n",Vm);
            printf("f0A = %le\n",f0A);
            printf("f0B = %le\n",f0B);
            printf("Am = %le\n",Am);
            printf("Ap = %le\n",Ap);
        }
    }
    
    int nx_h = (int) nx;
    int ny_h = (int) ny;
    int nz_h = (int) nz;
    int nx_local_h = (int) nx_local;
    int nx_start_h = (int) nx_start;

    CUDA_CHECK(cudaMemcpyToSymbol(nx_d, &nx_h, sizeof(int)));
    CUDA_CHECK(cudaMemcpyToSymbol(ny_d, &ny_h, sizeof(int)));
    CUDA_CHECK(cudaMemcpyToSymbol(nz_d, &nz_h, sizeof(int)));
    CUDA_CHECK(cudaMemcpyToSymbol(nx_local_d, &nx_local_h, sizeof(int)));
    CUDA_CHECK(cudaMemcpyToSymbol(nx_start_d, &nx_start_h, sizeof(int)));
    CUDA_CHECK(cudaMemcpyToSymbol(dx_d, &dx, sizeof(double)));
    CUDA_CHECK(cudaMemcpyToSymbol(dy_d, &dy, sizeof(double)));
    CUDA_CHECK(cudaMemcpyToSymbol(dz_d, &dz, sizeof(double)));
    
    if(engs_out == 1)
        printf("Writing energies output to h5 files\n");
    else if(engs_out == 2)
        printf("Writing energies output to CSV files\n");
    
    if (VTK_out != 0) 
    {
        if (rank == 0)
        {
            const char *full_path = path; 
            // Check if the full path exists
            struct stat st = {0};
            if (stat(full_path, &st) == -1) 
            {
                // Doesn't exist, so create it
                if (mkdir(full_path, 0777) == 0) 
                    printf("Created folder: %s\n", full_path);
                else 
                {
                    fprintf(stderr, "Error: Rank %d failed to create DATA directory: %s\n", 
                                rank, strerror(errno));
                    MPI_Abort(comm, EXIT_FAILURE);
                }
            } 
            else 
                printf("Folder already exists: %s\n", full_path);
            
        }
        MPI_Barrier(comm);
        if (VTK_out == 6)
        {

            char dirpath[256];
            snprintf(dirpath, sizeof(dirpath), "%s/Processor_%d", path, rank);

            struct stat st2 = {0};
            if (stat(dirpath, &st2) == -1)
            {
                if (mkdir(dirpath, 0777) == 0)
                    printf("Rank %d created folder: %s\n", rank, dirpath);
                else
                {
                    fprintf(stderr, "Error: Rank %d failed to create directory %s: %s\n",
                            rank, dirpath, strerror(errno));
                    MPI_Abort(comm, EXIT_FAILURE);
                }
            }
        }
        
        if (VTK_out == 1 && MPI_out == 1)
        {
            if (rank == 0)
                printf("$$ Output will be written from all Processors in VTK format $$\n");
            char dir[1000];
            sprintf(dir, "%s/Processor_%d", path, rank);
            if (mkdir(dir, 0777) == -1 && errno != EEXIST) 
            {
                fprintf(stderr, "Error: Rank %d failed to create DATA directory: %s\n", 
                        rank, strerror(errno));
                MPI_Abort(comm, EXIT_FAILURE);
            }
        }
        
        if (rank == 0 && VTK_out == 1)
            printf("$$ Output will be written from root Processor in VTK format $$\n");
        if (rank == 0 && VTK_out == 2)
            printf("$$ PARALLEL HDF5 output writing is enabled $$\n");
    }
    else if (VTK_out == 0)
        if (rank == 0)
            printf("$$ No output will be written $$\n");
    
    if (VTK_out == 3)
    {
        Comp1D = (double*) calloc (nx, sizeof(double));
        Phi01D = (double*) calloc (nx, sizeof(double));
    }
 
    if ((initflag == 1 && create_nuclei < 4) || (VTK_out == 1 && MPI_out == 0) && rank == 0)
    {
        printf("alloc glob vars\n");
        glob_comp = (cufftDoubleComplex*) calloc ((nx*ny*nz), sizeof(cufftDoubleComplex));
        glob_phi0 = (cufftDoubleComplex*) calloc ((nx*ny*nz), sizeof(cufftDoubleComplex));
        if (nof_variants == 4)
        {
            glob_phi1 = (cufftDoubleComplex*) calloc ((nx*ny*nz), sizeof(cufftDoubleComplex));
            glob_phi2 = (cufftDoubleComplex*) calloc ((nx*ny*nz), sizeof(cufftDoubleComplex));
            glob_phi3 = (cufftDoubleComplex*) calloc ((nx*ny*nz), sizeof(cufftDoubleComplex));
        }
    }
    
    if ((initflag == 1 && create_nuclei < 4) ||  VTK_out == 1 || initflag == 3) 
    {
        printf("alloc local host vars\n");
        comp_h = (cufftDoubleComplex*) calloc ((nx_local*ny*nz), sizeof(cufftDoubleComplex));
        phi0_h = (cufftDoubleComplex*) calloc ((nx_local*ny*nz), sizeof(cufftDoubleComplex));
        if (nof_variants == 4)
        {
            phi1_h = (cufftDoubleComplex*) calloc ((nx_local*ny*nz), sizeof(cufftDoubleComplex));
            phi2_h = (cufftDoubleComplex*) calloc ((nx_local*ny*nz), sizeof(cufftDoubleComplex));
            phi3_h = (cufftDoubleComplex*) calloc ((nx_local*ny*nz), sizeof(cufftDoubleComplex));
        }
    }
    
    CUFFT_CHECK(cufftXtMalloc(plan, &comp, CUFFT_XT_FORMAT_INPLACE));
    CUFFT_CHECK(cufftXtMalloc(plan, &phi0, CUFFT_XT_FORMAT_INPLACE));
    if (nof_variants == 1)
    {
        ////To Save memopry alloc using dummy plan.
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &phi1, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &phi2, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(dummy_plan, &phi3, CUFFT_XT_FORMAT_INPLACE));
    }
    else if (nof_variants == 4)
    {
        CUFFT_CHECK(cufftXtMalloc(plan, &phi1, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &phi2, CUFFT_XT_FORMAT_INPLACE));
        CUFFT_CHECK(cufftXtMalloc(plan, &phi3, CUFFT_XT_FORMAT_INPLACE));
    }
    
    Vol_frac = ((Supersaturation - c_alpha_eq)/(c_beta_eq - c_alpha_eq));
    if (rank == 0)
        printf("Vol frac of gprime from supersaturation :%le\n",Vol_frac);
    
    double VOP;
    if (create_nuclei == 0)
        VOP = (4.0/3.0)*CUDART_PI * ppt_size_h*ppt_size_h*ppt_size_h;

    else if (create_nuclei > 2 && initflag != 2)
        VOP = (double) NFP * (4.0/3.0)*CUDART_PI * ppt_size_h*ppt_size_h*ppt_size_h;

    double TV = (double) nx* (double) ny* (double) nz;
    vf = (VOP/TV);
    c0 = ((Supersaturation - (vf*c_beta_eq))/(1.0-vf));
    if(c0 < c_alpha_eq)
    {
        printf("ERROR: Supersaturation cannot be lower than matrix eqm composition\n");
        MPI_Abort(comm, EXIT_FAILURE);

    }
 
    if (rank == 0)
        printf("Final Supersaturation intialized is :%lf\n",c0);
     
    CUDA_CHECK(cudaMallocManaged((void**)&ppt_size, sizeof(double)));
    CUDA_CHECK(cudaMemset(ppt_size, 0.0, sizeof(double)));
    
    ////sizes of complex and double variables
    complex_size = ((nx_local*ny*nz)* sizeof(cufftDoubleComplex));
    double_size = ((nx_local*ny*nz)* sizeof(double));
    CUDA_CHECK(cudaMallocManaged((void**)&Vf, sizeof(double)));
    CUDA_CHECK(cudaMalloc((void**)&vol_frac, sizeof(double)));

    CUDA_CHECK(cudaMalloc((void**)&f0, np*(sizeof(*f0))));
    CUDA_CHECK(cudaMalloc((void**)&c_eq, np*(sizeof(*c_eq))));
    CUDA_CHECK(cudaMalloc((void**)&kappa, np*(sizeof(*kappa))));

    CUDA_CHECK(cudaMemset(vol_frac, 0.0, sizeof(*vol_frac)));
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
    CUDA_CHECK(cudaMemset(f0, 0.0, sizeof(*f0)*2));
    CUDA_CHECK(cudaMemset(c_eq, 0.0, sizeof(*c_eq)*2));
    CUDA_CHECK(cudaMemset(kappa, 0.0, sizeof(*kappa)*np));
    
    //// SYSTEM INTIALIZATION.
    Init_Conf(comp, phi0, phi1, phi2, phi3);
    printf("after int\n");
    
    CALPHA_chk = c_alpha_eq + 1.0;
    CBETA_chk = c_beta_eq + 1.0;
    if (rank == 0)
    {
        printf("CAlpha check value is: %le\n", CALPHA_chk);
        printf("CBeta check value is: %le\n", CBETA_chk);
    }

    CUFFT_CHECK(cufftXtMalloc(plan, &dfdc, CUFFT_XT_FORMAT_INPLACE_SHUFFLED));
    CUDA_CHECK(cudaMalloc((void**)&hphisum, double_size));
    CUDA_CHECK(cudaMalloc((void**)&dhdphi0, double_size));
    
    CUDA_CHECK(cudaMallocManaged((void**)&abort_flag, sizeof(double)));
    CUDA_CHECK(cudaMemset(abort_flag, 0.0, sizeof(double)));
    //// Elasticity Vars.
    CUDA_CHECK(cudaMalloc((void**)&sigappl_v, 6*sizeof(double)));
    CUDA_CHECK(cudaMemset(sigappl_v, 0.0, 6*sizeof(double)));

    CUDA_CHECK(cudaMemset(hphisum, 0.0, double_size));
    CUDA_CHECK(cudaMemset(dhdphi0, 0.0, double_size));
    
    if (engs_out == 1)
    {
        CUDA_CHECK(cudaMalloc((void**)&ftotal, double_size));
        //CUDA_CHECK(cudaMalloc((void**)&felas, double_size));
         
        CUDA_CHECK(cudaMemset(ftotal, 0.0, double_size));
        //CUDA_CHECK(cudaMemset(felas, 0.0, double_size));
        ftotal_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
        felas_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
    }
    
    if (TRACK_TIME > 0)
    {
        CUDA_CHECK(cudaMalloc((void**)&Avg_ptr, 4*sizeof(double)));
        CUDA_CHECK(cudaMemset(Avg_ptr, 0.0, 4*sizeof(double)));

        Avg_ptr_h = (double*) calloc (4, sizeof(double));

    }
    /*
    if (engs_out != 0)
    {
        
        CUDA_CHECK(cudaMalloc((void**)&ftotal_avg, sizeof(double)));
        CUDA_CHECK(cudaMalloc((void**)&felas_avg, sizeof(double)));
        
        CUDA_CHECK(cudaMemset(ftotal_avg, 0.0, sizeof(double)));
        CUDA_CHECK(cudaMemset(felas_avg, 0.0, sizeof(double)));
        
    }*/
    if (nof_variants == 4 || TRACK_TIME > 0 || (elast_int == 1 && stress_strain_out != 0))
    {
        CUDA_CHECK(cudaMalloc((void**)&dhdphi1, double_size));
        CUDA_CHECK(cudaMalloc((void**)&dhdphi2, double_size));
        CUDA_CHECK(cudaMalloc((void**)&dhdphi3, double_size));

        CUDA_CHECK(cudaMemset(dhdphi1, 0.0, double_size));
        CUDA_CHECK(cudaMemset(dhdphi2, 0.0, double_size));
        CUDA_CHECK(cudaMemset(dhdphi3, 0.0, double_size));
    }

    if (elast_int == 1)
    { 
        CUDA_CHECK(cudaMallocManaged((void**)&ux_avg, sizeof(double)));
        CUDA_CHECK(cudaMallocManaged((void**)&uy_avg, sizeof(double)));
        CUDA_CHECK(cudaMallocManaged((void**)&uz_avg, sizeof(double)));      
        CUDA_CHECK(cudaMemset(ux_avg, 0.0, sizeof(double)));
        CUDA_CHECK(cudaMemset(uy_avg, 0.0, sizeof(double)));
        CUDA_CHECK(cudaMemset(uz_avg, 0.0, sizeof(double)));
        
        CUDA_CHECK(cudaMallocManaged((void**)&ux_avg2, sizeof(double)));
        CUDA_CHECK(cudaMallocManaged((void**)&uy_avg2, sizeof(double)));
        CUDA_CHECK(cudaMallocManaged((void**)&uz_avg2, sizeof(double)));      
        CUDA_CHECK(cudaMemset(ux_avg2, 0.0, sizeof(double)));
        CUDA_CHECK(cudaMemset(uy_avg2, 0.0, sizeof(double)));
        CUDA_CHECK(cudaMemset(uz_avg2, 0.0, sizeof(double)));

        
        if (stress_strain_out == 1)
        {
            s11_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            s22_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            s33_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            e11_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            e22_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            e33_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            if (inhom != 0.0)
            {
                s23_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                s13_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                s12_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                s_eq_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                e23_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                e13_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                e12_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
                e_eq_h = (double*) calloc((nx_local*ny*nz), sizeof(double));
            }    
        }
    }

    comp_out_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
    phi0_out_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
    if (nof_variants == 4)
    {
        phi1_out_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
        phi2_out_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
        phi3_out_h = (double*) calloc ((nx_local*ny*nz), sizeof(double));
    }

    CUDA_CHECK(cudaMalloc((void**)&dummy, double_size));
    CUDA_CHECK(cudaMalloc((void**)&dummy2, double_size));
    CUDA_CHECK(cudaMalloc((void**)&dummy3, double_size));
    if (nof_variants == 4 || TRACK_TIME > 0 || (elast_int == 1 && stress_strain_out != 0))
    {
        CUDA_CHECK(cudaMalloc((void**)&dummy4, double_size));
        CUDA_CHECK(cudaMalloc((void**)&dummy5, double_size));
        CUDA_CHECK(cudaMemset(dummy4, 0.0, double_size));
        CUDA_CHECK(cudaMemset(dummy5, 0.0, double_size));
    }
    
    
    CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
    CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
    CUDA_CHECK(cudaMemset(dummy3, 0.0, double_size));

    if (VTK_out == 4)
    {
        CUDA_CHECK(cudaMalloc((void**)&dummy_float, (nx_local*ny*nz)*sizeof(float)));
        CUDA_CHECK(cudaMalloc((void**)&dummy_float2, (nx_local*ny*nz)*sizeof(float)));
        
        CUDA_CHECK(cudaMemset(dummy_float, 0, (nx_local*ny*nz)*sizeof(float)));
        CUDA_CHECK(cudaMemset(dummy_float2, 0, (nx_local*ny*nz)*sizeof(float)));

        comp_float_h = (float*) calloc ((nx_local*ny*nz), sizeof(float));
        phi0_float_h = (float*) calloc ((nx_local*ny*nz), sizeof(float));

        if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMalloc((void**)&dummy_float3, (nx_local*ny*nz)*sizeof(float)));
            CUDA_CHECK(cudaMalloc((void**)&dummy_float4, (nx_local*ny*nz)*sizeof(float)));
            CUDA_CHECK(cudaMalloc((void**)&dummy_float5, (nx_local*ny*nz)*sizeof(float)));
            
            CUDA_CHECK(cudaMemset(dummy_float3, 0, (nx_local*ny*nz)*sizeof(float)));
            CUDA_CHECK(cudaMemset(dummy_float4, 0, (nx_local*ny*nz)*sizeof(float)));
            CUDA_CHECK(cudaMemset(dummy_float5, 0, (nx_local*ny*nz)*sizeof(float)));
            
            phi1_float_h = (float*) calloc ((nx_local*ny*nz), sizeof(float));
            phi2_float_h = (float*) calloc ((nx_local*ny*nz), sizeof(float));
            phi3_float_h = (float*) calloc ((nx_local*ny*nz), sizeof(float));
        }
    }
    if (VTK_out == 5)
    {
        CUDA_CHECK(cudaMalloc((void**)&dummy_int, (nx_local*ny*nz)*sizeof(int16_t)));
        CUDA_CHECK(cudaMalloc((void**)&dummy_int2, (nx_local*ny*nz)*sizeof(int16_t)));
        
        CUDA_CHECK(cudaMemset(dummy_int, 0, (nx_local*ny*nz)*sizeof(int16_t)));
        CUDA_CHECK(cudaMemset(dummy_int2, 0, (nx_local*ny*nz)*sizeof(int16_t)));

        comp_int_h = (int16_t*) calloc ((nx_local*ny*nz), sizeof(int16_t));
        phi0_int_h = (int16_t*) calloc ((nx_local*ny*nz), sizeof(int16_t));

        if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMalloc((void**)&dummy_int3, (nx_local*ny*nz)*sizeof(int16_t)));
            CUDA_CHECK(cudaMalloc((void**)&dummy_int4, (nx_local*ny*nz)*sizeof(int16_t)));
            CUDA_CHECK(cudaMalloc((void**)&dummy_int5, (nx_local*ny*nz)*sizeof(int16_t)));
            
            CUDA_CHECK(cudaMemset(dummy_int3, 0, (nx_local*ny*nz)*sizeof(int16_t)));
            CUDA_CHECK(cudaMemset(dummy_int4, 0, (nx_local*ny*nz)*sizeof(int16_t)));
            CUDA_CHECK(cudaMemset(dummy_int5, 0, (nx_local*ny*nz)*sizeof(int16_t)));
            
            phi1_int_h = (int16_t*) calloc ((nx_local*ny*nz), sizeof(int16_t));
            phi2_int_h = (int16_t*) calloc ((nx_local*ny*nz), sizeof(int16_t));
            phi3_int_h = (int16_t*) calloc ((nx_local*ny*nz), sizeof(int16_t));
        }
    }
    
    if (noise_int == 1)
        CUDA_CHECK(cudaMalloc(&d_states, (nx*ny*nz) * sizeof(curandStatePhilox4_32_10_t)));

    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, phisum, Vf, num_items);
    //CUDA_CHECK(cudaDeviceSynchronize());
    CUDA_CHECK(cudaMalloc(&t_storage, t_storage_bytes));
    
    if (kappa_omega_calc == 1)
    {
        omega = 6.0 * alpha * gamma_intf / Ln;
        //kpa = (3.0*(gamma_intf*Ln)/(2.0*alpha));
        ///// For KAPPA/2 formula changed from earlier
        kpa = (6.0*(gamma_intf*Ln)/(2.0*alpha));
    }
    else if (kappa_omega_calc == 2)
    {
        Mobility = (diffusivity/(2.0*f0_alpha));
        delta_C = c_beta_eq - c_alpha_eq;
        F = (delta_C*delta_C)/Mobility;
        a2 = 0.7833;
        phi_a = 0.05;
        phi_b = 0.95;
        Lambda = log((phi_b*(1.0-phi_a))/(phi_a*(1.0-phi_b)));
        omega = (3.0*gamma_intf*Lambda)/Ln;
        kpa = (6.0*gamma_intf*Ln)/Lambda;
        relax_coeff = omega/(3.0*kpa*a2*F);
    }
    else if (kappa_omega_calc == 3)
    {
        //// Weigthed avg curvature.
        CURV = ((1.0-vf)*f0_alpha) + (vf*f0_beta);
        Mobility = diffusivity/(2.0*CURV);
        delta_C = c_beta_eq - c_alpha_eq;
        F = (delta_C*delta_C)/Mobility;
        a2 = 0.7833;
        phi_a = 0.05;
        phi_b = 0.95;
        Lambda = log((phi_b*(1.0-phi_a))/(phi_a*(1.0-phi_b)));
        omega = (3.0*gamma_intf*Lambda)/Ln;
        kpa = (6.0*gamma_intf*Ln)/Lambda;
        relax_coeff = omega/(3.0*kpa*a2*F);

    }
    if (rank == 0)
    {
        printf("Kappa = %lf\n", kpa);
        printf("Barrier potential = %lf\n",omega);
        printf("F value = %lf\n", F);
        printf("a2 value = %lf\n", a2);
        printf("Lambda value = %lf\n", Lambda);
        printf("relax_coeff (L) value = %lf\n",relax_coeff);

    }

    Compute_kappa<<<1,1>>>(kappa,kpa,np);
    
    if (Method == 0)
    {
        Mobility = (diffusivity/(2.0*Am));
        if (rank == 0)
        {
            printf("Diffusivity is:%le\n", diffusivity);
            printf("Am is: %le\n", Am);
            printf("From METHOD 0, Mobility is:%le\n",Mobility);
        }
    }

    if (Method == 3)
    {
        //// Weighte Average Mobility.
        Mobility = ((Vol_frac*(diffusivity/Ap)) + (1.0-Vol_frac)*(diffusivity/Am));
        printf("Mobility(Weighted Avg):%le\n",Mobility);
        /* Since formualtion for both Consnatnt mobiltity and weighted mobility we use same Comp evolution. */
        Method = 0; 
    }
    
    sim_time = 0.0;
    
    Evolve(comp, phi0, phi1, phi2, phi3, dfdc);
    
    MPI_Barrier(comm);
    CUDA_CHECK(cudaDeviceSynchronize());
    
    if ((VTK_out == 1 && MPI_out == 0) && rank == 0)
    {
        printf("free glob vars\n");
        free(glob_comp);
        free(glob_phi0);
        if (nof_variants == 4)
        {
            free(glob_phi1);
            free(glob_phi2);
            free(glob_phi3);
        }
    }
    if (VTK_out == 1)
    {
        printf("free local host vars\n");
        free(comp_h);
        free(phi0_h);
        if (nof_variants == 4)
        {
            free(phi1_h);
            free(phi2_h);
            free(phi3_h);
        }
    }
    CUDA_CHECK(cudaFree(t_storage));
    CUDA_CHECK(cudaFree(dummy));
    CUDA_CHECK(cudaFree(dummy2));
    CUDA_CHECK(cudaFree(dummy3));
    if (nof_variants == 4 || TRACK_TIME > 0 || (elast_int == 1 && stress_strain_out != 0))
    {
        CUDA_CHECK(cudaFree(dummy4));
        CUDA_CHECK(cudaFree(dummy5));
        CUDA_CHECK(cudaFree(dhdphi1));
        CUDA_CHECK(cudaFree(dhdphi2));
        CUDA_CHECK(cudaFree(dhdphi3));
    }
    CUDA_CHECK(cudaFree(Vf));
    CUDA_CHECK(cudaFree(f0));
    CUDA_CHECK(cudaFree(c_eq));
    CUDA_CHECK(cudaFree(kappa));
    CUDA_CHECK(cudaFree(hphisum));
    CUDA_CHECK(cudaFree(dhdphi0));
    CUDA_CHECK(cudaFree(ppt_size));
    CUDA_CHECK(cudaFree(sigappl_v));
    if (elast_int == 1)
    {
        CUDA_CHECK(cudaFree(ux_avg));
        CUDA_CHECK(cudaFree(uy_avg));
        CUDA_CHECK(cudaFree(uz_avg));
        CUDA_CHECK(cudaFree(ux_avg2));
        CUDA_CHECK(cudaFree(uy_avg2));
        CUDA_CHECK(cudaFree(uz_avg2));
        /*
        if (stress_strain_out == 1)
        {
            CUDA_CHECK(cudaFree(s_eq));
            CUDA_CHECK(cudaFree(s11));
            CUDA_CHECK(cudaFree(s22));
            CUDA_CHECK(cudaFree(s33));
            CUDA_CHECK(cudaFree(s23));
            CUDA_CHECK(cudaFree(s13));
            CUDA_CHECK(cudaFree(s12));
            CUDA_CHECK(cudaFree(e_eq));
            CUDA_CHECK(cudaFree(e11));
            CUDA_CHECK(cudaFree(e22));
            CUDA_CHECK(cudaFree(e33));
            CUDA_CHECK(cudaFree(e23));
            CUDA_CHECK(cudaFree(e13));
            CUDA_CHECK(cudaFree(e12));
        }*/
    }
    
    CUFFT_CHECK(cufftXtFree(comp));
    CUFFT_CHECK(cufftXtFree(phi0));
    CUFFT_CHECK(cufftXtFree(phi1));
    CUFFT_CHECK(cufftXtFree(phi2));
    CUFFT_CHECK(cufftXtFree(phi3));
    CUFFT_CHECK(cufftXtFree(dfdc));
    if (noise_int == 1)
        CUDA_CHECK(cudaFree(d_states));
    
    if(engs_out == 1)
    {
        CUDA_CHECK(cudaFree(ftotal));
        //CUDA_CHECK(cudaFree(felas));
        free(ftotal_h);
        free(felas_h);
    }
    if (VTK_out == 4)
    {
        CUDA_CHECK(cudaFree(dummy_float));
        CUDA_CHECK(cudaFree(dummy_float2));
        CUDA_CHECK(cudaFree(dummy_float3));
        CUDA_CHECK(cudaFree(dummy_float4));
        CUDA_CHECK(cudaFree(dummy_float5));
        
        free(comp_float_h);
        free(phi0_float_h);
        free(phi1_float_h);
        free(phi2_float_h);
        free(phi3_float_h);

    }
    if (TRACK_TIME > 0)
    {
        CUDA_CHECK(cudaFree(Avg_ptr));
        free(Avg_ptr_h);
    }
    /* 
    if(engs_out !=0)
    {
        CUDA_CHECK(cudaFree(ftotal_avg));
        CUDA_CHECK(cudaFree(felas_avg));
        free(ftotal_out);
        free(felas_out);
    }*/

    CUFFT_CHECK(cufftDestroy(plan));
    if (nof_variants == 1 || engs_out == 0)
        CUFFT_CHECK(cufftDestroy(dummy_plan));
   
   
    ncclCommDestroy(nccl_comm);
    MPI_Barrier(comm);

    MPI_Finalize();
    CUDA_CHECK(cudaDeviceReset());
    printf("=====> DONE <=====\n");
    return 0;
}
