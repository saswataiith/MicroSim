//#include "../include/binary.h"
__global__ void MovecuFFTReal2int16_SV(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     BoxIterator<cufftDoubleComplex> phi0_begin,
                                     int16_t* __restrict__ dummy,  
                                     int16_t* __restrict__ dummy2, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;
    
    long idx = k + (nz * (j + (i * ny)));
    
    comp_begin += idx; phi0_begin += idx; 

    if (comp_begin < comp_end)
    {
        const double SCALE = 10000.0;
        dummy[idx]  = (int16_t)__double2int_rn((comp_begin->x) * SCALE);
        dummy2[idx] = (int16_t)__double2int_rn((phi0_begin->x) * SCALE);
    }
}

__global__ void MovecuFFTD2F(BoxIterator<cufftDoubleComplex> comp_begin,
                             BoxIterator<cufftDoubleComplex> comp_end,
                             BoxIterator<cufftDoubleComplex> phi0_begin,
                             float* __restrict__ dummy,  
                             float* __restrict__ dummy2, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;
    
    long idx = k + (nz * (j + (i * ny)));
    
    comp_begin += idx; phi0_begin += idx; 

    if (comp_begin < comp_end)
    {
        dummy[idx]  = (float)(comp_begin)->x;
        dummy2[idx] = (float)(phi0_begin)->x;
    }
}
__global__ void MovecuFFTD2F_MV(BoxIterator<cufftDoubleComplex> comp_begin,
                                 BoxIterator<cufftDoubleComplex> comp_end,
                                 BoxIterator<cufftDoubleComplex> phi0_begin,
                                 BoxIterator<cufftDoubleComplex> phi1_begin,
                                 BoxIterator<cufftDoubleComplex> phi2_begin,
                                 BoxIterator<cufftDoubleComplex> phi3_begin,
                                 float* __restrict__ dummy,  
                                 float* __restrict__ dummy2,
                                 float* __restrict__ dummy3,
                                 float* __restrict__ dummy4,
                                 float* __restrict__ dummy5, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;
    
    long idx = k + (nz * (j + (i * ny)));
    
    comp_begin += idx; phi0_begin += idx; phi1_begin += idx;
    phi2_begin += idx; phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        dummy[idx]  = (float)(comp_begin)->x;
        dummy2[idx] = (float)(phi0_begin)->x;
        dummy3[idx] = (float)(phi1_begin)->x;
        dummy4[idx] = (float)(phi2_begin)->x;
        dummy5[idx] = (float)(phi3_begin)->x;
    }
}

__global__ void MovecuFFTReal2int16(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     BoxIterator<cufftDoubleComplex> phi0_begin,
                                     BoxIterator<cufftDoubleComplex> phi1_begin,
                                     BoxIterator<cufftDoubleComplex> phi2_begin,
                                     BoxIterator<cufftDoubleComplex> phi3_begin,
                                     int16_t* __restrict__ dummy,  
                                     int16_t* __restrict__ dummy2,
                                     int16_t* __restrict__ dummy3,
                                     int16_t* __restrict__ dummy4,
                                     int16_t* __restrict__ dummy5, int ny, int nz)
{
    long i = threadIdx.x + blockIdx.x * blockDim.x;
    long j = threadIdx.y + blockIdx.y * blockDim.y;
    long k = threadIdx.z + blockIdx.z * blockDim.z;
    
    long idx = k + (nz * (j + (i * ny)));
    
    comp_begin += idx; phi0_begin += idx; phi1_begin += idx;
    phi2_begin += idx; phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        const double SCALE = 10000.0;
        
        dummy[idx]  = (int16_t)__double2int_rn((comp_begin->x) * SCALE);
        dummy2[idx] = (int16_t)__double2int_rn((phi0_begin->x) * SCALE);
        dummy3[idx] = (int16_t)__double2int_rn((phi1_begin->x) * SCALE);
        dummy4[idx] = (int16_t)__double2int_rn((phi2_begin->x) * SCALE);
        dummy5[idx] = (int16_t)__double2int_rn((phi3_begin->x) * SCALE);
    }
}

void write_single_field_int16(int16_t *packed_data, int nx_local, int ny, int nz,
                              int nx_offset, int nx_global,
                              const char *field_name, hid_t file_id, MPI_Comm comm)
{
    hid_t dset_id, filespace, memspace, plist_id;
    hsize_t global_dims[3] = {(hsize_t)nx_global, (hsize_t)ny, (hsize_t)nz};
    hsize_t local_dims[3]  = {(hsize_t)nx_local, (hsize_t)ny, (hsize_t)nz};
    hsize_t start[3]       = {(hsize_t)nx_offset, 0, 0};

    // Create dataset as NATIVE_INT16 (signed 2-byte)
    filespace = H5Screate_simple(3, global_dims, NULL);
    dset_id = H5Dcreate(file_id, field_name, H5T_NATIVE_INT16, filespace,
                        H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    H5Sclose(filespace);

    filespace = H5Dget_space(dset_id);
    H5Sselect_hyperslab(filespace, H5S_SELECT_SET, start, NULL, local_dims, NULL);

    memspace = H5Screate_simple(3, local_dims, NULL);
    plist_id = H5Pcreate(H5P_DATASET_XFER);
    H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_COLLECTIVE);

    // Write the short data
    H5Dwrite(dset_id, H5T_NATIVE_INT16, memspace, filespace, plist_id, packed_data);

    H5Pclose(plist_id);
    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
}

void write_all_fields_int16(int16_t *data0, int16_t *data1, int16_t *data2, int16_t *data3, int16_t *data4,
                            int nx_local, int ny, int nz, int nx_offset, 
                            int nx_global, int nfv, char *path,
                            const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    // Ensure write_single_field is updated to handle int16_t pointers
    write_single_field_int16(data0, nx_local, ny, nz, nx_offset, nx_global, "COMP", file_id, comm);
    write_single_field_int16(data1, nx_local, ny, nz, nx_offset, nx_global, "PHI0", file_id, comm);
    
    if (nfv == 4)
    {
        write_single_field_int16(data2, nx_local, ny, nz, nx_offset, nx_global, "PHI1", file_id, comm);
        write_single_field_int16(data3, nx_local, ny, nz, nx_offset, nx_global, "PHI2", file_id, comm);
        write_single_field_int16(data4, nx_local, ny, nz, nx_offset, nx_global, "PHI3", file_id, comm);
    }

    H5Fclose(file_id);
}
void write_attribute_int16(FILE *f, const char *attribute_name, const char *basename, int step, 
                           int nx, int ny, int nz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s_%d.h5", basename, step);
    fprintf(f,
            "      <Attribute Name=\"%s\" AttributeType=\"Scalar\" Center=\"Node\">\n"
            "        <DataItem Dimensions=\"%d %d %d\" NumberType=\"Int\" Precision=\"2\" Format=\"HDF\">\n"
            "          %s:/%s\n"
            "        </DataItem>\n"
            "      </Attribute>\n",
            attribute_name, nx, ny, nz, filename, attribute_name);
}

void write_xdmf_int16(const char *basename, int step, int nfv, char *path, int nx, int ny, int nz, 
                      double dx, double dy, double dz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");
    
    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
        "    <Grid Name=\"ScalarField\" GridType=\"Uniform\">\n"
        "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
        "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">0 0 0</DataItem>\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
        "      </Geometry>\n",
        nx, ny, nz, dx, dy, dz
    );

    write_attribute_int16(f, "COMP", "mpkks_int", step, nx, ny, nz);
    write_attribute_int16(f, "PHI0", "mpkks_int", step, nx, ny, nz);
    if (nfv == 4)
    {
        write_attribute_int16(f, "PHI1", "mpkks_int", step, nx, ny, nz);
        write_attribute_int16(f, "PHI2", "mpkks_int", step, nx, ny, nz);
        write_attribute_int16(f, "PHI3", "mpkks_int", step, nx, ny, nz);
    }

    fprintf(f, "    </Grid>\n  </Domain>\n</Xdmf>\n");
    fclose(f);
}


void write_attribute_mpi(FILE *f,
                         const char *attribute_name,
                         const char *basename,
                         int step,
                         int rank,
                         char *path,
                         int nx, int ny, int nz)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "Processor_%d/%s_%d.h5",
             rank, basename, step);

    fprintf(f,
        "      <Attribute Name=\"%s\" AttributeType=\"Scalar\" Center=\"Node\">\n"
        "        <DataItem Dimensions=\"%d %d %d\" NumberType=\"Float\" Precision=\"8\" Format=\"HDF\">\n"
        "          %s:/%s\n"
        "        </DataItem>\n"
        "      </Attribute>\n",
        attribute_name, nx, ny, nz, filename, attribute_name);
}

void write_xdmf_mpi(const char *basename, int step, int nfv, char *path,
                    int nproc, int nx_local, int ny, int nz,
                    double dx, double dy, double dz,
                    MPI_Comm comm)
{
    int rank;
    MPI_Comm_rank(comm, &rank);

    // Only rank 0 writes XDMF
    if (rank != 0) return;

    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");

    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
    );

    for (int r = 0; r < nproc; r++)
    {
        int nx_offset = r * nx_local;

        fprintf(f,
            "    <Grid Name=\"Rank%d\" GridType=\"Uniform\">\n"
            "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
            "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
            "        <DataItem Dimensions=\"3\" Format=\"XML\">%d 0 0</DataItem>\n"
            "        <DataItem Dimensions=\"3\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
            "      </Geometry>\n",
            r, nx_local, ny, nz,
            nx_offset, dx, dy, dz
        );

        // Attributes (now using new folder structure)
        write_attribute_mpi(f, "COMP", basename, step, r, path, nx_local, ny, nz);
        write_attribute_mpi(f, "PHI0", basename, step, r, path, nx_local, ny, nz);

        if (nfv == 4)
        {
            write_attribute_mpi(f, "PHI1", basename, step, r, path, nx_local, ny, nz);
            write_attribute_mpi(f, "PHI2", basename, step, r, path, nx_local, ny, nz);
            write_attribute_mpi(f, "PHI3", basename, step, r, path, nx_local, ny, nz);
        }

        fprintf(f, "    </Grid>\n");
    }

    fprintf(f,
        "  </Domain>\n"
        "</Xdmf>\n"
    );

    fclose(f);
}

void write_single_field_local(double *data,
                             int nx_local, int ny, int nz,
                             const char *field_name,
                             hid_t file_id)
{
    hid_t dset_id, filespace, memspace;

    hsize_t dims[3] = {
        (hsize_t)nx_local,
        (hsize_t)ny,
        (hsize_t)nz
    };

    filespace = H5Screate_simple(3, dims, NULL);

    dset_id = H5Dcreate(file_id, field_name,
                        H5T_NATIVE_DOUBLE,
                        filespace,
                        H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

    memspace = H5Screate_simple(3, dims, NULL);

    H5Dwrite(dset_id, H5T_NATIVE_DOUBLE,
             memspace, filespace,
             H5P_DEFAULT, data);

    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
}

void write_all_fields_local(double *data0, double *data1, double *data2,
                            double *data3, double *data4,
                            int nx_local, int ny, int nz,
                            int nx_offset, int nfv,
                            char *path,
                            const char *basename,
                            int step,
                            MPI_Comm comm)
{
    int rank;
    MPI_Comm_rank(comm, &rank);

    // File name now includes rank
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/Processor_%d/%s_%d.h5",
             path, rank, basename, step);

    // Open a new HDF5 file (independent, not parallel)
    hid_t file_id = H5Fcreate(filename, H5F_ACC_TRUNC,
                              H5P_DEFAULT, H5P_DEFAULT);

    // Optional: store rank offset as attribute (useful for ParaView XDMF)
    H5LTset_attribute_int(file_id, "/", "nx_offset", &nx_offset, 1);

    // Write each field locally
    write_single_field_local(data0, nx_local, ny, nz, "COMP", file_id);
    write_single_field_local(data1, nx_local, ny, nz, "PHI0", file_id);

    if (nfv == 4)
    {
        write_single_field_local(data2, nx_local, ny, nz, "PHI1", file_id);
        write_single_field_local(data3, nx_local, ny, nz, "PHI2", file_id);
        write_single_field_local(data4, nx_local, ny, nz, "PHI3", file_id);
    }

    H5Fclose(file_id);
}

void write_vtk_1D_out(const char *basename, const char *path,
                       int steps, double *comp, double *phi, 
                       int n, double dx)
{

    char fn[100];
    sprintf(fn, "%s/%s_%d.vtk", path, basename, steps);
    
    FILE *f = fopen(fn, "w");
    if (!f) {
        printf("Error: Cannot open %s for writing\n", fn);
        return;
    }

    fprintf(f, "# vtk DataFile Version 3.0\n");
    fprintf(f, "Phasefield Data\n");
    fprintf(f, "ASCII\n");
    fprintf(f, "DATASET STRUCTURED_POINTS\n");
    fprintf(f, "DIMENSIONS %d %d %d\n", n, 1, 1);
    fprintf(f, "ORIGIN 0 0 0\n");
    fprintf(f, "SPACING %le %le %le\n", dx, dx, dx);

    // Only ONE POINT_DATA allowed → number of points = n*1*1 = n
    fprintf(f, "POINT_DATA %d\n", n);

    //// COMP 
    fprintf(f, "SCALARS COMP float 1\n");
    fprintf(f, "LOOKUP_TABLE default\n");
    for (int i = 0; i < n; i++)
        fprintf(f, "%le\n", comp[i]);

    /// Phi
    fprintf(f, "SCALARS PHI float 1\n");
    fprintf(f, "LOOKUP_TABLE default\n");
    for (int i = 0; i < n; i++)
        fprintf(f, "%le\n", phi[i]);

    fclose(f);
}
/*
void write_single_field2(double *data, int nx_local, int ny, int nz,
                        int nx_offset, int nx_global,
                        const char *field_name, hid_t file_id, MPI_Comm comm)
{
    hid_t dset_id, filespace, memspace, plist_id;
    hsize_t global_dims[3] = {(hsize_t)nx_global, (hsize_t)ny, (hsize_t)nz};
    hsize_t local_dims[3]  = {(hsize_t)nx_local,  (hsize_t)ny, (hsize_t)nz};
    hsize_t start[3]       = {(hsize_t)nx_offset, 0, 0};

    int rank;
    MPI_Comm_rank(comm, &rank);

    // Debug: print one sample value from this rank
    if (nx_local > 0) {
        printf("[Rank %d] Writing %s: local_dims=(%d,%d,%d) offset=%d sample=%.6e\n",
               rank, field_name, nx_local, ny, nz, nx_offset, data[0]);
        fflush(stdout);
    }

    // Create dataset
    filespace = H5Screate_simple(3, global_dims, NULL);
    dset_id = H5Dcreate(file_id, field_name, H5T_NATIVE_DOUBLE, filespace,
                        H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    H5Sclose(filespace);

    // Select this rank’s hyperslab
    filespace = H5Dget_space(dset_id);
    H5Sselect_hyperslab(filespace, H5S_SELECT_SET, start, NULL, local_dims, NULL);

    // Define memory space
    memspace = H5Screate_simple(3, local_dims, NULL);

    // Transfer properties (prefer collective, fallback to independent)
    plist_id = H5Pcreate(H5P_DATASET_XFER);
    if (H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_COLLECTIVE) < 0) {
        H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_INDEPENDENT);
    }

    // ---- Unified Memory handling ----
    size_t nbytes = (size_t)nx_local * ny * nz * sizeof(double);

    // Ensure GPU kernels done
    cudaDeviceSynchronize();
    // Migrate managed memory to CPU before HDF5 write
    cudaMemPrefetchAsync(data, nbytes, cudaCpuDeviceId, 0);
    cudaDeviceSynchronize();

    // Now safe to write directly
    H5Dwrite(dset_id, H5T_NATIVE_DOUBLE, memspace, filespace, plist_id, data);

    // Cleanup
    H5Pclose(plist_id);
    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
}
*/

void Move_R2H(double *X, cufftDoubleComplex *Y, long nx_local, long ny, long nz)
{
    for (int i=0; i<nx_local*ny*nz; i++)
    {
        X[i] = Y[i].x;
    }

}

__global__ void MovecuFFTComp2double(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     double* __restrict__ dummy)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int nz = nz_d; int ny = ny_d;
    long idx = k + (nz * (j + (i*ny)));

    comp_begin += idx; 

    if (comp_begin < comp_end)
        dummy[idx] = comp_begin->x;

}

__global__ void MovecuFFTSV2double(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     BoxIterator<cufftDoubleComplex> phi0_begin,
                                     double* __restrict__ dummy,
                                     double* __restrict__ dummy2)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int nz = nz_d; int ny = ny_d;
    long idx = k + (nz * (j + (i*ny)));

    comp_begin += idx; 
    phi0_begin += idx; 

    if (comp_begin < comp_end)
    {
        dummy[idx] = comp_begin->x;
        dummy2[idx] = phi0_begin->x;
    }

}

__global__ void MovecuFFTReal2double(BoxIterator<cufftDoubleComplex> comp_begin,
                                     BoxIterator<cufftDoubleComplex> comp_end,
                                     BoxIterator<cufftDoubleComplex> phi0_begin,
                                     BoxIterator<cufftDoubleComplex> phi1_begin,
                                     BoxIterator<cufftDoubleComplex> phi2_begin,
                                     BoxIterator<cufftDoubleComplex> phi3_begin,
                                     double* __restrict__ dummy,
                                     double* __restrict__ dummy2,
                                     double* __restrict__ dummy3,
                                     double* __restrict__ dummy4,
                                     double* __restrict__ dummy5)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    int nz = nz_d; int ny = ny_d;
    long idx = k + (nz * (j + (i*ny)));

    comp_begin += idx; phi0_begin += idx; phi1_begin += idx;
    phi2_begin += idx; phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        dummy[idx] = comp_begin->x;
        dummy2[idx] = phi0_begin->x;
        dummy3[idx] = phi1_begin->x;
        dummy4[idx] = phi2_begin->x;
        dummy5[idx] = phi3_begin->x;

    }

}

void write_single_field_fl(float *data, int nx_local, int ny, int nz,
                              int nx_offset, int nx_global,
                              const char *field_name, hid_t file_id, MPI_Comm comm)
{
    hid_t dset_id, filespace, memspace, plist_id;
    hsize_t global_dims[3] = {(hsize_t)nx_global, (hsize_t) ny, (hsize_t) nz};
    hsize_t local_dims[3]  = {(hsize_t)nx_local, (hsize_t) ny, (hsize_t) nz};
    hsize_t start[3]       = {(hsize_t)nx_offset, 0, 0};

    filespace = H5Screate_simple(3, global_dims, NULL);

    // CHANGE 1: Use H5T_NATIVE_FLOAT for dataset creation
    dset_id = H5Dcreate(file_id, field_name, H5T_NATIVE_FLOAT, filespace,
                        H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    H5Sclose(filespace);

    filespace = H5Dget_space(dset_id);
    H5Sselect_hyperslab(filespace, H5S_SELECT_SET, start, NULL, local_dims, NULL);

    memspace = H5Screate_simple(3, local_dims, NULL);
    plist_id = H5Pcreate(H5P_DATASET_XFER);
    H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_COLLECTIVE);

    // CHANGE 2: Use H5T_NATIVE_FLOAT in H5Dwrite
    H5Dwrite(dset_id, H5T_NATIVE_FLOAT, memspace, filespace, plist_id, data);

    H5Pclose(plist_id);
    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
}

void write_single_field(double *data, int nx_local, int ny, int nz,
                        int nx_offset, int nx_global,
                        const char *field_name, hid_t file_id, MPI_Comm comm)
{
    hid_t dset_id, filespace, memspace, plist_id;
    hsize_t global_dims[3] = {(hsize_t)nx_global, (hsize_t) ny, (hsize_t) nz};
    hsize_t local_dims[3]  = {(hsize_t)nx_local, (hsize_t) ny, (hsize_t) nz};
    hsize_t start[3]       = {(hsize_t)nx_offset, 0, 0};

    filespace = H5Screate_simple(3, global_dims, NULL);
    dset_id = H5Dcreate(file_id, field_name, H5T_NATIVE_DOUBLE, filespace,
                        H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);
    H5Sclose(filespace);

    filespace = H5Dget_space(dset_id);
    H5Sselect_hyperslab(filespace, H5S_SELECT_SET, start, NULL, local_dims, NULL);

    memspace = H5Screate_simple(3, local_dims, NULL);
    plist_id = H5Pcreate(H5P_DATASET_XFER);
    H5Pset_dxpl_mpio(plist_id, H5FD_MPIO_COLLECTIVE);

    H5Dwrite(dset_id, H5T_NATIVE_DOUBLE, memspace, filespace, plist_id, data);

    H5Pclose(plist_id);
    H5Sclose(memspace);
    H5Sclose(filespace);
    H5Dclose(dset_id);
}
void write_all_fields_fl(float *data0, float *data1, float *data2, float *data3, float *data4,
                      int nx_local, int ny, int nz, int nx_offset, 
                      int nx_global, int nfv, char *path,
                      const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    // Ensure these calls match your updated float version of write_single_field
    write_single_field_fl(data0, nx_local, ny, nz, nx_offset, nx_global, "COMP", file_id, comm);
    write_single_field_fl(data1, nx_local, ny, nz, nx_offset, nx_global, "PHI0", file_id, comm);
    
    if (nfv == 4)
    {
        write_single_field_fl(data2, nx_local, ny, nz, nx_offset, nx_global, "PHI1", file_id, comm);
        write_single_field_fl(data3, nx_local, ny, nz, nx_offset, nx_global, "PHI2", file_id, comm);
        write_single_field_fl(data4, nx_local, ny, nz, nx_offset, nx_global, "PHI3", file_id, comm);
    }

    H5Fclose(file_id);
}


// Wrapper to write all three fields
void write_all_fields(double *data0, double *data1, double *data2, double *data3, double *data4,
                      int nx_local, int ny, int nz, int nx_offset, 
                      int nx_global, int nfv, char *path,
                      const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    write_single_field(data0, nx_local, ny, nz, nx_offset, nx_global, "COMP", file_id, comm);
    write_single_field(data1, nx_local, ny, nz, nx_offset, nx_global, "PHI0", file_id, comm);
    if (nfv == 4)
    {
        write_single_field(data2, nx_local, ny, nz, nx_offset, nx_global, "PHI1", file_id, comm);
        write_single_field(data3, nx_local, ny, nz, nx_offset, nx_global, "PHI2", file_id, comm);
        write_single_field(data4, nx_local, ny, nz, nx_offset, nx_global, "PHI3", file_id, comm);
    }

    H5Fclose(file_id);
}

void write_all_fields2(double *data0, double *data1, double *data2, double *data3, double *data4,
                       double *data5, double *data6,
                      int nx_local, int ny, int nz, int nx_offset, 
                      int nx_global, int nfv, char *path, int engs_out,
                      const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    write_single_field(data0, nx_local, ny, nz, nx_offset, nx_global, "COMP", file_id, comm);
    write_single_field(data1, nx_local, ny, nz, nx_offset, nx_global, "PHI0", file_id, comm);
    if (nfv == 4)
    {
        write_single_field(data2, nx_local, ny, nz, nx_offset, nx_global, "PHI1", file_id, comm);
        write_single_field(data3, nx_local, ny, nz, nx_offset, nx_global, "PHI2", file_id, comm);
        write_single_field(data4, nx_local, ny, nz, nx_offset, nx_global, "PHI3", file_id, comm);
    }
    if (engs_out == 1)
    {
        write_single_field(data5, nx_local, ny, nz, nx_offset, nx_global, "FTOTAL", file_id, comm);
        write_single_field(data6, nx_local, ny, nz, nx_offset, nx_global, "FELAS", file_id, comm);
    }

    H5Fclose(file_id);
}


void write_all_STR(double *data0, double *data1, double *data2, double *data3, double *data4, double *data5, double *data6,
                   int nx_local, int ny, int nz, int nx_offset, int nx_global, int nfv, char *path, int inhom,
                   const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    write_single_field(data0, nx_local, ny, nz, nx_offset, nx_global, "E11", file_id, comm);
    write_single_field(data1, nx_local, ny, nz, nx_offset, nx_global, "E22", file_id, comm);
    write_single_field(data2, nx_local, ny, nz, nx_offset, nx_global, "E33", file_id, comm);
    if (inhom != 1.0)
    {
        write_single_field(data3, nx_local, ny, nz, nx_offset, nx_global, "E23", file_id, comm);
        write_single_field(data4, nx_local, ny, nz, nx_offset, nx_global, "E13", file_id, comm);
        write_single_field(data5, nx_local, ny, nz, nx_offset, nx_global, "E12", file_id, comm);
        write_single_field(data6, nx_local, ny, nz, nx_offset, nx_global, "E_EQ", file_id, comm);
    }

    H5Fclose(file_id);
}

void write_all_STS(double *data0, double *data1, double *data2, double *data3, double *data4, double *data5, double *data6,
                   int nx_local, int ny, int nz, int nx_offset, int nx_global, int nfv, char *path, int inhom,
                   const char *basename, int step, MPI_Comm comm)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.h5", path, basename, step);
    hid_t plist_id, file_id;

    plist_id = H5Pcreate(H5P_FILE_ACCESS);
    H5Pset_fapl_mpio(plist_id, comm, MPI_INFO_NULL);
    file_id = H5Fcreate(filename, H5F_ACC_TRUNC, H5P_DEFAULT, plist_id);
    H5Pclose(plist_id);

    write_single_field(data0, nx_local, ny, nz, nx_offset, nx_global, "S11", file_id, comm);
    write_single_field(data1, nx_local, ny, nz, nx_offset, nx_global, "S22", file_id, comm);
    write_single_field(data2, nx_local, ny, nz, nx_offset, nx_global, "S33", file_id, comm);
    if (inhom != 1.0)
    {
        write_single_field(data3, nx_local, ny, nz, nx_offset, nx_global, "S23", file_id, comm);
        write_single_field(data4, nx_local, ny, nz, nx_offset, nx_global, "S13", file_id, comm);
        write_single_field(data5, nx_local, ny, nz, nx_offset, nx_global, "S12", file_id, comm);
        write_single_field(data6, nx_local, ny, nz, nx_offset, nx_global, "S_EQ", file_id, comm);
    }

    H5Fclose(file_id);
}

void write_attribute_float(FILE *f, const char *attribute_name, const char *basename, int step, 
                           int nx, int ny, int nz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s_%d.h5", basename, step);
    fprintf(f,
            "      <Attribute Name=\"%s\" AttributeType=\"Scalar\" Center=\"Node\">\n"
            // CHANGE: Precision changed from "8" to "4"
            "        <DataItem Dimensions=\"%d %d %d\" NumberType=\"Float\" Precision=\"4\" Format=\"HDF\">\n"
            "          %s:/%s\n"
            "        </DataItem>\n"
            "      </Attribute>\n",
            attribute_name, nx, ny, nz, filename, attribute_name);
}

void write_xdmf_fl(const char *basename, int step, int nfv, char *path, int engs_out, int nx, int ny, int nz,
                double dx, double dy, double dz)
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");

    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
        "    <Grid Name=\"ScalarField\" GridType=\"Uniform\">\n"
        "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
        "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
        "        <DataItem Dimensions=\"3\" NumberType=\"Float\" Precision=\"4\" Format=\"XML\">0 0 0</DataItem>\n"
        "        <DataItem Dimensions=\"3\" NumberType=\"Float\" Precision=\"4\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
        "      </Geometry>\n",
        nx, ny, nz, dx, dy, dz
    );

    // Ensure these call your NEW function that uses Precision="4"
    write_attribute_float(f, "COMP", "mpkks_fl", step, nx, ny, nz);
    write_attribute_float(f, "PHI0", "mpkks_fl", step, nx, ny, nz);

    if (nfv == 4)
    {
        write_attribute_float(f, "PHI1", "mpkks_fl", step, nx, ny, nz);
        write_attribute_float(f, "PHI2", "mpkks_fl", step, nx, ny, nz);
        write_attribute_float(f, "PHI3", "mpkks_fl", step, nx, ny, nz);
    }

    if (engs_out == 1)
    {
        write_attribute_float(f, "FTOTAL", "mpkks_fl", step, nx, ny, nz);
        write_attribute_float(f, "FELAS", "mpkks_fl", step, nx, ny, nz);
    }

    fprintf(f,
        "    </Grid>\n"
        "  </Domain>\n"
        "</Xdmf>\n"
    );
    fclose(f);
}

void write_attribute(FILE *f, const char *attribute_name, const char *basename, int step, 
                     int nx, int ny, int nz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s_%d.h5", basename, step);
    fprintf(f,
            "      <Attribute Name=\"%s\" AttributeType=\"Scalar\" Center=\"Node\">\n"
            "        <DataItem Dimensions=\"%d %d %d\" NumberType=\"Float\" Precision=\"8\" Format=\"HDF\">\n"
            "          %s:/%s\n"
            "        </DataItem>\n"
            "      </Attribute>\n",
            attribute_name, nx, ny, nz, filename, attribute_name);
}


void write_xdmf(const char *basename, int step, int nfv, char *path, int engs_out, int nx, int ny, int nz, 
                double dx, double dy, double dz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");
    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
        "    <Grid Name=\"ScalarField\" GridType=\"Uniform\">\n"
        "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
        "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">0 0 0</DataItem>\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
        "      </Geometry>\n",
        nx, ny, nz, dx, dy, dz
    );

    write_attribute(f, "COMP", "mpkks", step, nx, ny, nz);
    write_attribute(f, "PHI0", "mpkks", step, nx, ny, nz);
    if (nfv == 4)
    {
        write_attribute(f, "PHI1", "mpkks", step, nx, ny, nz);
        write_attribute(f, "PHI2", "mpkks", step, nx, ny, nz);
        write_attribute(f, "PHI3", "mpkks", step, nx, ny, nz);
    }
    if (engs_out == 1)
    {
        write_attribute(f, "FTOTAL", "mpkks", step, nx, ny, nz);
        write_attribute(f, "FELAS", "mpkks", step, nx, ny, nz);
    }

    fprintf(f,
        "    </Grid>\n"
        "  </Domain>\n"
        "</Xdmf>\n"
    );
    fclose(f);
}

void write_STR_xdmf(const char *basename, int step, int nfv, char *path, int inhom, int nx, int ny, int nz, 
                    double dx, double dy, double dz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");
    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
        "    <Grid Name=\"ScalarField\" GridType=\"Uniform\">\n"
        "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
        "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">0 0 0</DataItem>\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
        "      </Geometry>\n",
        nx, ny, nz, dx, dy, dz
    );

    write_attribute(f, "E11", "STR", step, nx, ny, nz);
    write_attribute(f, "E22", "STR", step, nx, ny, nz);
    write_attribute(f, "E33", "STR", step, nx, ny, nz);
    if (inhom != 1.0)
    {
        write_attribute(f, "E23", "STR", step, nx, ny, nz);
        write_attribute(f, "E13", "STR", step, nx, ny, nz);
        write_attribute(f, "E12", "STR", step, nx, ny, nz);
        write_attribute(f, "E_EQ", "STR", step, nx, ny, nz);
    }

    fprintf(f,
        "    </Grid>\n"
        "  </Domain>\n"
        "</Xdmf>\n"
    );
    fclose(f);
}

void write_STS_xdmf(const char *basename, int step, int nfv, char *path, int inhom, int nx, int ny, int nz, 
                    double dx, double dy, double dz) 
{
    char filename[256];
    snprintf(filename, sizeof(filename), "%s/%s_%d.xdmf", path, basename, step);
    FILE *f = fopen(filename, "w");
    fprintf(f,
        "<?xml version=\"1.0\" ?>\n"
        "<Xdmf Version=\"3.0\">\n"
        "  <Domain>\n"
        "    <Grid Name=\"ScalarField\" GridType=\"Uniform\">\n"
        "      <Topology TopologyType=\"3DCORECTMesh\" Dimensions=\"%d %d %d\"/>\n"
        "      <Geometry GeometryType=\"ORIGIN_DXDYDZ\">\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">0 0 0</DataItem>\n"
        "        <DataItem Dimensions=\"3\" Format=\"XML\">%.6f %.6f %.6f</DataItem>\n"
        "      </Geometry>\n",
        nx, ny, nz, dx, dy, dz
    );

    write_attribute(f, "S11", "STS", step, nx, ny, nz);
    write_attribute(f, "S22", "STS", step, nx, ny, nz);
    write_attribute(f, "S33", "STS", step, nx, ny, nz);
    if (inhom != 1.0)
    {
        write_attribute(f, "S23", "STS", step, nx, ny, nz);
        write_attribute(f, "S13", "STS", step, nx, ny, nz);
        write_attribute(f, "S12", "STS", step, nx, ny, nz);
        write_attribute(f, "S_EQ", "STS", step, nx, ny, nz);
    }

    fprintf(f,
        "    </Grid>\n"
        "  </Domain>\n"
        "</Xdmf>\n"
    );
    fclose(f);
}

void writeVTK(FILE *fp, cufftDoubleComplex *comp, cufftDoubleComplex *phi0, 
               cufftDoubleComplex *phi1, cufftDoubleComplex *phi2, 
               cufftDoubleComplex *phi3, int nfv,size_t nx, size_t ny, size_t nz, double dx)
{
    // Write VTK header
    fprintf(fp, "# vtk DataFile Version 3.0\n");
    fprintf(fp, "Phasefield Data\n");
    fprintf(fp, "ASCII\n");
    fprintf(fp, "DATASET STRUCTURED_POINTS\n");
    fprintf(fp, "DIMENSIONS %zu %zu %zu\n", nx, ny, nz);
    fprintf(fp, "ORIGIN 0 0 0\n");
    fprintf(fp, "SPACING %le %le %le\n", dx, dx, dx);
    fprintf(fp, "POINT_DATA %zu\n", nx * ny * nz);
   

    // Writing phi0 data (first array)
    fprintf(fp, "SCALARS PHI0 double\n");
    fprintf(fp, "LOOKUP_TABLE default\n");
    for (size_t i = 0; i < nx * ny * nz; i++)
    {
        fprintf(fp, "%le\n", phi0[i].x);
    }
    fprintf(fp, "\n");
    
    if (nfv == 4)
    {
        // Writing phi1 data (second array)
        fprintf(fp, "SCALARS PHI1 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", phi1[i].x);
        }
        fprintf(fp, "\n");

        // Writing phi2 data (third array)
        fprintf(fp, "SCALARS PHI2 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", phi2[i].x);
        }
        fprintf(fp, "\n");

        // Writing phi3 data (fourth array)
        fprintf(fp, "SCALARS PHI3 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", phi3[i].x);
        }
        fprintf(fp, "\n");
        
    }
    
    // Writing comp data
    fprintf(fp, "SCALARS COMP double \n");
    fprintf(fp, "LOOKUP_TABLE default\n");
    for (size_t i = 0; i < nx * ny * nz; i++)
    {
        fprintf(fp, "%le\n", comp[i].x);
    }
    fprintf(fp, "\n");
}
/*
    ////TODO:may need later 
    //// Elast driving forces out.
    if (drivf_out == 1)
    {
    
        fprintf(fp, "SCALARS dfeldphi0 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", dfeldphi0[i]);
        }
        fprintf(fp, "\n");
        
        if (nfv > 1)
        {
            fprintf(fp, "SCALARS dfeldphi1 double \n");
            fprintf(fp, "LOOKUP_TABLE default\n");
            for (size_t i = 0; i < nx * ny * nz; i++)
            {
                fprintf(fp, "%le\n", dfeldphi1[i]);
            }
            fprintf(fp, "\n");
            
            fprintf(fp, "SCALARS dfeldphi2 double \n");
            fprintf(fp, "LOOKUP_TABLE default\n");
            for (size_t i = 0; i < nx * ny * nz; i++)
            {
                fprintf(fp, "%le\n", dfeldphi2[i]);
            }
            fprintf(fp, "\n");
            
            fprintf(fp, "SCALARS dfeldphi3 double \n");
            fprintf(fp, "LOOKUP_TABLE default\n");
            for (size_t i = 0; i < nx * ny * nz; i++)
            {
                fprintf(fp, "%le\n", dfeldphi3[i]);
            }
            fprintf(fp, "\n");
        }

    }

    //// Stress & Strain out.
    if (sts_str_out == 1)
    {
        fprintf(fp, "SCALARS S11 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s11[i]);
        }
        fprintf(fp, "\n");
        

        fprintf(fp, "SCALARS S22 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s22[i]);
        }
        fprintf(fp, "\n");

        fprintf(fp, "SCALARS S33 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s33[i]);
        }
        fprintf(fp, "\n");

        fprintf(fp, "SCALARS S23 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s23[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS S13 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s13[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS S12 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", s12[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS e11 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e11[i]);
        }
        fprintf(fp, "\n");
        

        fprintf(fp, "SCALARS e22 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e22[i]);
        }
        fprintf(fp, "\n");

        fprintf(fp, "SCALARS e33 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e33[i]);
        }
        fprintf(fp, "\n");

        fprintf(fp, "SCALARS e23 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e23[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS e13 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e13[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS e12 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", e12[i]);
        }
        fprintf(fp, "\n");

    }

    //// elastic energy out.
    if (engs_out == 1)
    {
        fprintf(fp, "SCALARS felas double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", felas[i]);
        }
        fprintf(fp, "\n");
        
        fprintf(fp, "SCALARS felas2 double \n");
        fprintf(fp, "LOOKUP_TABLE default\n");
        for (size_t i = 0; i < nx * ny * nz; i++)
        {
            fprintf(fp, "%le\n", felas2[i]);
        }
        fprintf(fp, "\n");
    }
}


__global__ void KernelComplexToReal(double *real_comp, double *real_phi0,
                                    double *real_phi1, double *real_phi2,
                                    double *real_phi3, 
                                    BoxIterator <cufftDoubleComplex> comp_begin,
                                    BoxIterator <cufftDoubleComplex> comp_end,
                                    BoxIterator <cufftDoubleComplex> phi0_begin,
                                    BoxIterator <cufftDoubleComplex> phi0_end,
                                    BoxIterator <cufftDoubleComplex> phi1_begin,
                                    BoxIterator <cufftDoubleComplex> phi1_end,
                                    BoxIterator <cufftDoubleComplex> phi2_begin,
                                    BoxIterator <cufftDoubleComplex> phi2_end,
                                    BoxIterator <cufftDoubleComplex> phi3_begin,
                                    BoxIterator <cufftDoubleComplex> phi3_end,
                                    long nx_local, long ny,long nz)
{
    long i = threadIdx.x + blockIdx.x*blockDim.x;
    long j = threadIdx.y + blockIdx.y*blockDim.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;
    long idx = k + (nz * (j + (i*ny)));

    comp_begin += idx, phi0_begin += idx, phi1_begin += idx,
    phi2_begin += idx, phi3_begin += idx;

    if (comp_begin < comp_end)
    {
        real_comp[idx] = comp_begin->x;
        real_phi0[idx] = phi0_begin->x;
        real_phi1[idx] = phi1_begin->x;
        real_phi2[idx] = phi2_begin->x;
        real_phi3[idx] = phi3_begin->x;
    }
    __syncthreads();

}
*/

void Output_Conf (cudaLibXtDesc *comp, cudaLibXtDesc *phi0, cudaLibXtDesc *phi1,
                  cudaLibXtDesc *phi2, cudaLibXtDesc *phi3, int steps)
{
    auto [comp_begin_r, comp_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)comp->descriptor->data[0]);
    
    auto [phi0_begin_r, phi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi0->descriptor->data[0]);

    auto [phi1_begin_r, phi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi1->descriptor->data[0]);

    
    auto [phi2_begin_r, phi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi2->descriptor->data[0]);

    auto [phi3_begin_r, phi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)phi3->descriptor->data[0]);

    FILE *fp;
    char f[1000];
    double min, max;
    
    if (VTK_out == 0)
    {
        MovecuFFTComp2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r,dummy); 
        
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy, &comp_avg[0], num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, &comp_avg[1], num_items);
        
        ncclAllReduce(&comp_avg[0], &comp_avg[0], 1, ncclDouble, ncclMin, nccl_comm, 0);
        ncclAllReduce(&comp_avg[1], &comp_avg[1], 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        CUDA_CHECK(cudaMemcpy(comp_avg_h, comp_avg, 2*sizeof(double), cudaMemcpyDeviceToHost));
         
        if (rank == 0)
        {
            printf("Minimum in composition = %le\n", comp_avg_h[0]);
            printf("Maximum in composition = %le\n", comp_avg_h[1]);
        }
    }

    if (VTK_out == 1 && MPI_out == 0)
    {
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)comp_h, (void *)comp, D2H));
        CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi0_h, (void *)phi0, D2H));
        if (nof_variants ==4)
        {
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi1_h, (void *)phi1, D2H));
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi2_h, (void *)phi2, D2H));
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi3_h, (void *)phi3, D2H));
        }
        if (rank == 0)
        {
            //double start_time = MPI_Wtime();
            for (int source_rank = 1; source_rank < size; source_rank++) 
            {
               int offset = source_rank * nx_local * ny * nz;
               
               MPI_Recv(glob_comp + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, source_rank,
                        0, comm,MPI_STATUS_IGNORE); 
               MPI_Recv(glob_phi0 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, source_rank,
                        0, comm,MPI_STATUS_IGNORE);
               if (nof_variants == 4)
               {
                   MPI_Recv(glob_phi1 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, source_rank,
                            0, comm,MPI_STATUS_IGNORE);
                   MPI_Recv(glob_phi2 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, source_rank,
                            0, comm,MPI_STATUS_IGNORE);
                   MPI_Recv(glob_phi3 + offset, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, source_rank,
                            0, comm,MPI_STATUS_IGNORE);
               }
            }
            // Root process copies its own chunk
            memcpy(glob_comp, comp_h, nx_local * ny * nz * sizeof(cufftDoubleComplex));
            memcpy(glob_phi0, phi0_h, nx_local * ny * nz * sizeof(cufftDoubleComplex));
            if (nof_variants == 4)
            {
                memcpy(glob_phi1, phi1_h, nx_local * ny * nz * sizeof(cufftDoubleComplex));
                memcpy(glob_phi2, phi2_h, nx_local * ny * nz * sizeof(cufftDoubleComplex));
                memcpy(glob_phi3, phi3_h, nx_local * ny * nz * sizeof(cufftDoubleComplex));
            }
        }
        
        else 
        {
        // Other processes receive their chunk from the root
            MPI_Send(comp_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm);
            MPI_Send(phi0_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm);
            if (nof_variants == 4)
            {
                MPI_Send(phi1_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm);
                MPI_Send(phi2_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm);
                MPI_Send(phi3_h, nx_local * ny * nz, MPI_DOUBLE_COMPLEX, 0, 0, comm);
            }
        }
    }
     
     
    
   if (VTK_out == 1 && rank == 0 && MPI_out == 0)
   {
        min = 1.0;
        for (int i = 0; i < nx; i++) {
            for (int j = 0; j < ny; j++) {
                for (int k = 0; k < nz; k++) {
                    if(glob_comp[k+nz*(j+i*ny)].x < min)
                        min = glob_comp[k+nz*(j+i*ny)].x;
                }
            }
        }
        printf("Minimum in composition =%lf\n", min);
        max = 0.0;
        for (int i = 0; i < nx; i++) {
            for (int j = 0; j < ny; j++) {
                for (int k = 0; k < nz; k++) {
                    if (glob_comp[k+nz*(j+i*ny)].x > max)
                        max = glob_comp[k+nz*(j+i*ny)].x;
                }
            }
        }
        printf("Maximum in composition =%lf\n", max);
   }


   if (VTK_out == 1)
   {
        if (MPI_out == 1)
        {
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)comp_h, (void *)comp, D2H));
            CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi0_h, (void *)phi0, D2H));
            if (nof_variants ==4)
            {
                CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi1_h, (void *)phi1, D2H));
                CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi2_h, (void *)phi2, D2H));
                CUFFT_CHECK(cufftXtMemcpy(plan, (void *)phi3_h, (void *)phi3, D2H));
            }
            memset(dummy, 0.0, double_size);
            Move_R2H(dummy, comp_h, nx_local,ny,nz);
           
            cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy, &comp_avg[0], num_items);
            cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, &comp_avg[1], num_items);
            
            ncclAllReduce(&comp_avg[0], &comp_avg[0], 1, ncclDouble, ncclMin, nccl_comm, 0);
            ncclAllReduce(&comp_avg[1], &comp_avg[1], 1, ncclDouble, ncclMax, nccl_comm, 0);
            
            CUDA_CHECK(cudaMemcpy(comp_avg_h, comp_avg, 2*sizeof(double), cudaMemcpyDeviceToHost));
             
            if (rank == 0)
            {
                printf("Minimum in composition = %le\n", comp_avg_h[0]);
                printf("Maximum in composition = %le\n", comp_avg_h[1]);
            }
            sprintf(f, "%s/Processor_%d/3dkks_%d.vtk",path, rank, steps);

            fp = fopen(f, "w");
            if (fp == NULL) 
            {
                fprintf(stderr, "Error: Failed to open file %s\n", f);
                MPI_Abort(comm, EXIT_FAILURE);
            }
            if (nof_variants == 1) 
                writeVTK(fp,comp_h,phi0_h,NULL, NULL, NULL, nof_variants,nx_local,ny,nz,dx);
            else if (nof_variants == 4) 
                writeVTK(fp,comp_h,phi0_h,phi1_h,phi2_h,phi3_h,nof_variants,nx_local,ny,nz,dx);
            fclose(fp);
        }
        
        //printf("Writing output from root proc\n");
        else if (MPI_out == 0)
        {
            if (rank == 0)
            {
                sprintf(f, "%s/3dkks_%d.vtk",path, steps);

                fp = fopen(f, "w");
                if (fp == NULL) 
                {
                    fprintf(stderr, "Error: Failed to open file %s\n", f);
                    MPI_Abort(comm, EXIT_FAILURE); 
                }
                if (nof_variants == 1)
                    writeVTK(fp,glob_comp,glob_phi0,NULL, NULL, NULL, nof_variants, nx,ny,nz,dx);
                else if (nof_variants == 4)
                    writeVTK(fp,glob_comp,glob_phi0,glob_phi1,glob_phi2,glob_phi3,nof_variants, nx,ny,nz,dx);

                fclose(fp);
            }

        }

   }
   else if (VTK_out == 2 || VTK_out == 3)
   {    
        CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
        CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));

        if (nof_variants == 1)
            MovecuFFTSV2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy, dummy2); 

        if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMemset(dummy3, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy4, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy5, 0.0, double_size));

            MovecuFFTReal2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                          phi2_begin_r, phi3_begin_r, dummy, dummy2, dummy3, 
                                                          dummy4, dummy5);
        }
        
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy, &comp_avg[0], num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, &comp_avg[1], num_items);
        
        ncclAllReduce(&comp_avg[0], &comp_avg[0], 1, ncclDouble, ncclMin, nccl_comm, 0);
        ncclAllReduce(&comp_avg[1], &comp_avg[1], 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        CUDA_CHECK(cudaMemcpy(comp_avg_h, comp_avg, 2*sizeof(double), cudaMemcpyDeviceToHost));
           
        if (rank == 0)
        {
            printf("Minimum in composition = %le\n", comp_avg_h[0]);
            printf("Maximum in composition = %le\n", comp_avg_h[1]);
        }

        CUDA_CHECK(cudaMemcpy(comp_out_h, dummy, double_size, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(phi0_out_h, dummy2, double_size, cudaMemcpyDeviceToHost));
        if (nof_variants == 1)
        {
            if (engs_out == 1)
            {
                write_all_fields2(comp_out_h, phi0_out_h, NULL, NULL, NULL, ftotal_h, felas_h,  
                                  nx_local, ny, nz, nx_start, nx, nof_variants, path, engs_out, "mpkks", steps, comm);
            }
            else
                write_all_fields(comp_out_h, phi0_out_h, NULL, NULL, NULL, 
                                  nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);

        }
        
        else if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMemcpy(phi1_out_h, dummy3, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi2_out_h, dummy4, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi3_out_h, dummy5, double_size, cudaMemcpyDeviceToHost));
            
            if (engs_out == 1)
                write_all_fields2(comp_out_h, phi0_out_h, phi1_out_h, phi2_out_h, phi3_out_h, ftotal_h, felas_h, 
                                  nx_local, ny, nz, nx_start, nx, nof_variants, path, engs_out, "mpkks", steps, comm);
            else
                write_all_fields(comp_out_h, phi0_out_h, phi1_out_h, phi2_out_h, phi3_out_h, 
                                  nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);
            
        }
        // XDMF metadata
        if (rank == 0)
            write_xdmf("mpkks",steps, nof_variants, path, engs_out, nx, ny, nz, dx, dy, dz);
            //write_xdmf2("mpkks",steps, nof_variants, path, nx, ny, nz, dx, dy, dz);
        
        if (elast_int == 1 && stress_strain_out == 1)
        { 
            write_all_STR(e11_h, e22_h, e33_h, e23_h, e13_h, e12_h, e_eq_h,
                            nx_local, ny, nz, nx_start, nx, nof_variants, path, inhom, "STR", steps, comm);
            
            write_STR_xdmf("STR",steps, nof_variants, path, inhom, nx, ny, nz, dx, dy, dz);
            
            write_all_STS(s11_h, s22_h, s33_h, s23_h, s13_h, s12_h,s_eq_h,
                              nx_local, ny, nz, nx_start, nx, nof_variants, path, inhom, "STS", steps, comm);
            
            write_STS_xdmf("STS",steps, nof_variants, path, inhom, nx, ny, nz, dx, dy, dz);

        }

        /////NOTE:should be used only for when 1D profile is required and on single GPU.

        if (VTK_out == 3)
        {
            for (int i = 0; i < nx; i++) 
            {
                int l = i*(ny*nz) + (ny/2)*nz + (nz/2);
                Comp1D[i] = comp_out_h[l];
                Phi01D[i] = phi0_out_h[l];
            }
            write_vtk_1D_out("1dkks", path, steps, Comp1D, Phi01D, nx, dx);
        }

   }
    ////NOTE:Converting double to float to decrease the file size.
   else if (VTK_out == 4)
   {
        if (nof_variants == 1)
            MovecuFFTD2F<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy_float, dummy_float2, ny,nz); 

        if (nof_variants == 4)
        {
            MovecuFFTD2F_MV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                          phi2_begin_r, phi3_begin_r, dummy_float, dummy_float2, dummy_float3, 
                                                          dummy_float4, dummy_float5, ny,nz);
        }
        
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy_float, &comp_avg[0], num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy_float, &comp_avg[1], num_items);
        
        ncclAllReduce(&comp_avg[0], &comp_avg[0], 1, ncclDouble, ncclMin, nccl_comm, 0);
        ncclAllReduce(&comp_avg[1], &comp_avg[1], 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        CUDA_CHECK(cudaMemcpy(comp_avg_h, comp_avg, 2*sizeof(double), cudaMemcpyDeviceToHost));
           
        if (rank == 0)
        { 
            printf("Minimum in composition = %le\n", comp_avg_h[0]);
            printf("Maximum in composition = %le\n", comp_avg_h[1]);
        }
        MPI_Barrier(comm);
        
        CUDA_CHECK(cudaMemcpy(comp_float_h, dummy_float, (nx_local*ny*nz)*sizeof(float), cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(phi0_float_h, dummy_float2, (nx_local*ny*nz)*sizeof(float), cudaMemcpyDeviceToHost));
        if (nof_variants == 1)
        { 
            write_all_fields_fl(comp_float_h, phi0_float_h, NULL, NULL, NULL, 
                                    nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks_fl", steps, comm);

        }
        
        else if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMemcpy(phi1_float_h, dummy_float3, (nx_local*ny*nz)*sizeof(float), cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi2_float_h, dummy_float4, (nx_local*ny*nz)*sizeof(float), cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi3_float_h, dummy_float5, (nx_local*ny*nz)*sizeof(float), cudaMemcpyDeviceToHost));
            
            write_all_fields_fl(comp_float_h, phi0_float_h, phi1_float_h, phi2_float_h, phi3_float_h, 
                                   nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks_fl", steps, comm);

        }
        // XDMF metadata
        if (rank == 0)
            write_xdmf_fl("mpkks_fl",steps, nof_variants, path, engs_out,nx, ny, nz, dx, dy, dz);
        
        if (TRACK_OBS == 1)
        {
            CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
            
            if (nof_variants == 1)
                MovecuFFTSV2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy, dummy2); 
                

            if (nof_variants == 4)
            {
                CUDA_CHECK(cudaMemset(dummy3, 0.0, double_size));
                CUDA_CHECK(cudaMemset(dummy4, 0.0, double_size));
                CUDA_CHECK(cudaMemset(dummy5, 0.0, double_size));

                MovecuFFTReal2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                              phi2_begin_r, phi3_begin_r, dummy, dummy2, dummy3, 
                                                              dummy4, dummy5);
            }
            
            CUDA_CHECK(cudaMemcpy(comp_out_h, dummy, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi0_out_h, dummy2, double_size, cudaMemcpyDeviceToHost));
            
            if (nof_variants == 1)
                write_all_fields(comp_out_h, phi0_out_h, NULL, NULL, NULL, 
                                    nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);
 
            else if (nof_variants == 4)
            {
                CUDA_CHECK(cudaMemcpy(phi1_out_h, dummy3, double_size, cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(phi2_out_h, dummy4, double_size, cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(phi3_out_h, dummy5, double_size, cudaMemcpyDeviceToHost));
                
                write_all_fields(comp_out_h, phi0_out_h, phi1_out_h, phi2_out_h, phi3_out_h, 
                                      nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);
            }
            // XDMF metadata
            if (rank == 0)
                write_xdmf("mpkks",steps, nof_variants, path, engs_out, nx, ny, nz, dx, dy, dz);
        }
   }


    ////NOTE:Converting double to int to decrease the file size.
   else if (VTK_out == 5)
   {
        if (nof_variants == 1)
            MovecuFFTReal2int16_SV<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy_int, dummy_int2, ny,nz); 

        if (nof_variants == 4)
        {

            MovecuFFTReal2int16<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                          phi2_begin_r, phi3_begin_r, dummy_int, dummy_int2, dummy_int3, 
                                                          dummy_int4, dummy_int5, ny,nz);
        }
        
        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy_int, &comp_avg[0], num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy_int, &comp_avg[1], num_items);
        
        ncclAllReduce(&comp_avg[0], &comp_avg[0], 1, ncclDouble, ncclMin, nccl_comm, 0);
        ncclAllReduce(&comp_avg[1], &comp_avg[1], 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        CUDA_CHECK(cudaMemcpy(comp_avg_h, comp_avg, 2*sizeof(double), cudaMemcpyDeviceToHost));
           
        if (rank == 0)
        {
            ////NOTE:Since int rounded.
            const double int_scale = (int) (1.0/10000.0);
            comp_avg_h[0] *= int_scale;
            comp_avg_h[1] *= int_scale;
            
            printf("Minimum in composition = %le\n", comp_avg_h[0]);
            printf("Maximum in composition = %le\n", comp_avg_h[1]);
        }
        MPI_Barrier(comm);
        
        CUDA_CHECK(cudaMemcpy(comp_int_h, dummy_int, (nx_local*ny*nz)*sizeof(int16_t), cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(phi0_int_h, dummy_int2, (nx_local*ny*nz)*sizeof(int16_t), cudaMemcpyDeviceToHost));
        if (nof_variants == 1)
        { 
            write_all_fields_int16(comp_int_h, phi0_int_h, NULL, NULL, NULL, 
                                    nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks_int", steps, comm);

        }
        
        else if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMemcpy(phi1_int_h, dummy_int2, (nx_local*ny*nz)*sizeof(int16_t), cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi2_int_h, dummy_int2, (nx_local*ny*nz)*sizeof(int16_t), cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi3_int_h, dummy_int2, (nx_local*ny*nz)*sizeof(int16_t), cudaMemcpyDeviceToHost));
            
            write_all_fields_int16(comp_int_h, phi0_int_h, phi1_int_h, phi2_int_h, phi3_int_h, 
                                   nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks_int", steps, comm);

        }
        // XDMF metadata
        if (rank == 0)
            write_xdmf_int16("mpkks_int",steps, nof_variants, path, nx, ny, nz, dx, dy, dz);
        
        if (TRACK_OBS == 1)
        {
            CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
            
            if (nof_variants == 1)
                MovecuFFTSV2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy, dummy2); 
                

            if (nof_variants == 4)
            {
                CUDA_CHECK(cudaMemset(dummy3, 0.0, double_size));
                CUDA_CHECK(cudaMemset(dummy4, 0.0, double_size));
                CUDA_CHECK(cudaMemset(dummy5, 0.0, double_size));

                MovecuFFTReal2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                              phi2_begin_r, phi3_begin_r, dummy, dummy2, dummy3, 
                                                              dummy4, dummy5);
            }
            
            CUDA_CHECK(cudaMemcpy(comp_out_h, dummy, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(phi0_out_h, dummy2, double_size, cudaMemcpyDeviceToHost));
            
            if (nof_variants == 1)
                write_all_fields(comp_out_h, phi0_out_h, NULL, NULL, NULL, 
                                    nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);
 
            else if (nof_variants == 4)
            {
                CUDA_CHECK(cudaMemcpy(phi1_out_h, dummy3, double_size, cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(phi2_out_h, dummy4, double_size, cudaMemcpyDeviceToHost));
                CUDA_CHECK(cudaMemcpy(phi3_out_h, dummy5, double_size, cudaMemcpyDeviceToHost));
                
                write_all_fields(comp_out_h, phi0_out_h, phi1_out_h, phi2_out_h, phi3_out_h, 
                                      nx_local, ny, nz, nx_start, nx, nof_variants, path, "mpkks", steps, comm);
            }
            // XDMF metadata
            if (rank == 0)
                write_xdmf("mpkks",steps, nof_variants, path, engs_out, nx, ny, nz, dx, dy, dz);
        }
    }


    /* 
   else if (VTK_out == 5)
   {
        CUDA_CHECK(cudaMemset(dummy, 0.0, double_size));
        CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));

        if (nof_variants == 1)
            MovecuFFTSV2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, dummy, dummy2); 

        if (nof_variants == 4)
        {
            CUDA_CHECK(cudaMemset(dummy3, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy4, 0.0, double_size));
            CUDA_CHECK(cudaMemset(dummy5, 0.0, double_size));

            MovecuFFTReal2double<<<Gridsize, Blocksize>>>(comp_begin_r, comp_end_r, phi0_begin_r, phi1_begin_r, 
                                                          phi2_begin_r, phi3_begin_r, dummy, dummy2, dummy3, 
                                                          dummy4, dummy5);
        }

        cub::DeviceReduce::Min(t_storage, t_storage_bytes, dummy, min_comp, num_items);
        cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy, max_comp, num_items);
        ncclAllReduce(min_comp, min_comp, 1, ncclDouble, ncclMin, nccl_comm, 0);
        ncclAllReduce(max_comp, max_comp, 1, ncclDouble, ncclMax, nccl_comm, 0);
        
        CUDA_CHECK(cudaMemcpy(&min_comp_h, min_comp, sizeof(double), cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(&max_comp_h, max_comp, sizeof(double), cudaMemcpyDeviceToHost));
        
        //CUDA_CHECK(cudaDeviceSynchronize());
        //CUDA_CHECK(cudaStreamSynchronize(0));
        //MPI_Barrier(comm);
        if (rank == 0)
        {
            //printf("Minimum in composition = %le\n", *min_comp);
            //printf("Maximum in composition = %le\n", *max_comp);
            printf("Minimum in composition = %le\n", min_comp_h);
            printf("Maximum in composition = %le\n", max_comp_h);
            
            //if (*min_comp > CALPHA_chk || *max_comp > CBETA_chk)
            if (min_comp_h > CALPHA_chk || max_comp_h > CBETA_chk)
            {
                printf("COMPOSITION IS BLOWING UP\n");
                fprintf(stderr, "COMPOSITION IS BLOWING UP\n");

                MPI_Abort(comm,EXIT_FAILURE);

            }
        }

        if (nof_variants == 1)
        {
            write_all_fields_local(dummy, dummy2, NULL, NULL, NULL, 
                              nx_local, ny, nz, nx_start, nof_variants, path, "mpkks", steps, comm);

        }
        
        else if (nof_variants == 4)
        {
            write_all_fields_local(dummy, dummy2, dummy3, dummy4, dummy5, 
                              nx_local, ny, nz, nx_start, nof_variants, path, "mpkks", steps, comm);
            
        }
        MPI_Barrier(comm);
        if (rank == 0)
            write_xdmf_mpi("mpkks",steps, nof_variants, path, np, nx_local, ny, nz, dx, dy, dz, comm);

   }*/
   //if (rank == 0)
   //{
   //    double end_time = MPI_Wtime();
   //    printf("Time taken in writing in GPU:%d %le\n", rank,end_time - start_time);
   //}

    /*
    if (MPI_out == 0)
    {
        if (conf_out == 1)
        {
            if (rank == 0)
            {
                sprintf(f, "DATA/conf.%d", steps);

                fpt2 = fopen(fn2, "w");
                fwrite(&glob_comp[0], sizeof(double), nx*ny*nz, fpt2);
                fwrite(&glob_phi0[0], sizeof(double), nx*ny*nz, fpt2);
                fwrite(&glob_phi1[0], sizeof(double), nx*ny*nz, fpt2);
                fwrite(&glob_phi2[0], sizeof(double), nx*ny*nz, fpt2);
                fwrite(&glob_phi3[0], sizeof(double), nx*ny*nz, fpt2);
                fclose(fpt2);
            }
        }
    }*/

}
