//#include "../include/binary.h"

void Print_MAD(size_t t_storage_bytes, void *t_storage, double *hphi0, double *Vf, long num_items,
                   double sizescale, char* hphi)
{
    cub::DeviceReduce::Max(t_storage, t_storage_bytes, hphi0, Vf, num_items);
    CUDA_CHECK(cudaDeviceSynchronize());
    MPI_Allreduce(MPI_IN_PLACE, Vf, 1, MPI_DOUBLE, MPI_MAX, comm); 
    if (rank == 0)
        printf("Max value in %s: %le\n",hphi, *Vf);
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
    
    cub::DeviceReduce::Min(t_storage, t_storage_bytes, hphi0, Vf, num_items);
    CUDA_CHECK(cudaDeviceSynchronize());
    MPI_Allreduce(MPI_IN_PLACE, Vf, 1, MPI_DOUBLE, MPI_MIN, comm); 
    if (rank == 0)
        printf("Min value in %s: %le\n",hphi, *Vf);
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
    
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, hphi0, Vf, num_items);
    CUDA_CHECK(cudaDeviceSynchronize()); 
    MPI_Allreduce(MPI_IN_PLACE, Vf, 1, MPI_DOUBLE, MPI_SUM, comm); 
    *Vf *= sizescale;
    if (rank == 0)
        printf("Avg value in %s: %le\n",hphi , *Vf);
    CUDA_CHECK(cudaMemset(Vf, 0.0, sizeof(*Vf)));
}

__device__ void get_Ct_Cin(double *Ct, double *Cin,
                           double *Chet, double *Chom, double *hphisum, long idx)
{
    double temp = (2.0*hphisum[idx] - 1.0);
    
    Cin[0] = (Chet[0]*temp);
    Cin[1] = (Chet[1]*temp);
    Cin[2] = (Chet[2]*temp);
        
    Ct[0] = Chom[0] + Cin[0];
    Ct[1] = Chom[1] + Cin[1];
    Ct[2] = Chom[2] + Cin[2];

}

__device__ void get_Ct(double *Ct, 
                       double *Chet, double *Chom, double *hphisum, long idx)
{
    double temp = (2.0*hphisum[idx] - 1.0);
    
    Ct[0] = Chom[0] + (Chet[0]*temp);
    Ct[1] = Chom[1] + (Chet[1]*temp);
    Ct[2] = Chom[2] + (Chet[2]*temp);
        
}
/*
__global__ void Compute_hphisum(double *hphisum, double *hphi0, double *hphi1,
                                 double *hphi2, double *hphi3, long nx_local, long ny,long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    if (idx < nx_local*ny*nz)
    {
        hphisum[idx] = hphi0[idx] + hphi1[idx] + hphi2[idx] + hphi3[idx];

    }
    __syncthreads();
}
*/

__global__ void Compute_Ctotal(double *C11, double *C12, double *C44, 
                               const double* __restrict__ hphisum, 
                               double Chom11, double Chet11, double Chom12, double Chet12,
                               double Chom44, double Chet44, int nx_local, int ny, int nz) 
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    
    if (idx < nx_local*ny*nz)
    {
        const double temp = (2.0*hphisum[idx] - 1.0);
        C11[idx] = (Chom11 + Chet11*temp);
        C12[idx] = (Chom12 + Chet12*temp);
        C44[idx] = (Chom44 + Chet44*temp);

    }

}
/*
__global__ void Compute_Ctotal(double *Ctotal, double *hphisum, double Chom_d,
                               double Chet_d, int EC_calc, long nx_local, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    if (idx < nx_local*ny*nz)
    {
        if (EC_calc == 0)
            Ctotal[idx]  =  Chom_d + Chet_d*(2.0*hphisum[idx] - 1.0);
        else if (EC_calc == 1)
            Ctotal[idx]  =  Chom_d + (Chet_d*hphisum[idx]);

    }

}
*/

__global__ void Compute_Sij(double *Cavg, double *S_d, int nx, int ny, int nz)
{
    double size_scale = 1.0/(double)(nx*ny*nz);
    
    Cavg[0] *= size_scale; Cavg[1] *= size_scale; Cavg[2] *= size_scale;

    S_d[0] = ((Cavg[0]) + (Cavg[1]))/((Cavg[0])*(Cavg[0]) + (Cavg[0])*(Cavg[1])-
              2.0*(Cavg[1])*(Cavg[1]));
    S_d[1] = (-1.0*(Cavg[1]))/((Cavg[0])*(Cavg[0]) + (Cavg[0])*(Cavg[1]) -
              2.0*(Cavg[1])*(Cavg[1]));
    S_d[2] = 1.0/(Cavg[2]);

}


__global__ void Compute_perstr(BoxIterator<cufftDoubleComplex> unewx_begin,
                              BoxIterator<cufftDoubleComplex> unewy_begin,
                              BoxIterator<cufftDoubleComplex> unewz_begin,
                              BoxIterator<cufftDoubleComplex> str_v0_begin,
                              BoxIterator<cufftDoubleComplex> str_v0_end,
                              BoxIterator<cufftDoubleComplex> str_v1_begin,
                              BoxIterator<cufftDoubleComplex> str_v2_begin,
                              BoxIterator<cufftDoubleComplex> str_v3_begin,
                              BoxIterator<cufftDoubleComplex> str_v4_begin,
                              BoxIterator<cufftDoubleComplex> str_v5_begin)
{


    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    double  nk[3];
    long idx = k + nz_d*(j + i*ny_d);

    unewx_begin += idx; unewy_begin += idx; unewz_begin += idx;
    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        const cufftDoubleComplex ux = *unewx_begin;
        const cufftDoubleComplex uy = *unewy_begin;
        const cufftDoubleComplex uz = *unewz_begin;

        get_kx_ky_kz(&nk[0], &nk[1], &nk[2], str_v0_begin);
        
        *str_v0_begin = {-1.0*ux.y * nk[0], ux.x * nk[0]}; //XX
        *str_v1_begin = {-1.0*uy.y * nk[1], uy.x * nk[1]}; //YY
        *str_v2_begin = {-1.0*uz.y * nk[2], uz.x * nk[2]}; //ZZ

        *str_v3_begin = {-0.5*(uy.y * nk[2] + uz.y * nk[1]), 0.5*(uy.x * nk[2] + uz.x * nk[1])}; //YZ
        *str_v4_begin = {-0.5*(ux.y * nk[2] + uz.y * nk[0]), 0.5*(ux.x * nk[2] + uz.x * nk[0])}; //XZ
        *str_v5_begin = {-0.5*(ux.y * nk[1] + uy.y * nk[0]), 0.5*(ux.x * nk[1] + uy.x * nk[0])}; //XY
        
    }
   // __syncthreads();

}

__global__ void Compute_eigsts_1(double *eigsts, const double* __restrict__ hphisum, 
                                double Chom11_d, double Chom12_d, double Chet11_d, double Chet12_d,
                                double epszero_d, int nx_local, int ny , int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
     
    if (idx < nx_local*ny*nz)
    {
        const double hsum = hphisum[idx];
        const double temp = 2.0*hsum - 1.0;
        const double Ct11 = Chom11_d + Chet11_d * temp; 
        const double Ct12 = Chom12_d + Chet12_d * temp; 
        const double eig11 = epszero_d * hsum;
        
        ////Assuming misfit is zero and so eig11 = eig22 = eig33.
        eigsts[idx] = (Ct11*eig11 + 2.0*Ct12*eig11);
    }


    //__syncthreads();
}

__global__ void Compute_eigsts_2(double *eigsts11, double *eigsts22, const double* __restrict__ hphisum, 
                                double Chom11_d, double Chom12_d, double Chet11_d, double Chet12_d,
                                double epszero_d, double misfit_aniso, int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
     
    if (idx < nx_local*ny*nz)
    {
        const double hsum = hphisum[idx];
        const double temp = 2.0*hsum - 1.0;
        const double Ct11 = Chom11_d + Chet11_d * temp; 
        const double Ct12 = Chom12_d + Chet12_d * temp; 
        const double eig11 = epszero_d * hsum;
        
        eigsts11[idx] = (Ct11*eig11 + 2.0*Ct12*eig11);
        ////Assuming misfit is same in 2&3 directions and so eig22 = eig33.
        eigsts22[idx] = (Ct11*eig11*misfit_aniso + Ct12*eig11*(1.0 + misfit_aniso));
    }


    //__syncthreads();
}
/*
__global__ void Compute_eigsts0(double *eigsts, double *hphisum, double Chom11_d,
                                double Chom12_d, double Chet11_d, double Chet12_d,
                                double epszero_d, double misfit_aniso, int EC_calc,
                                long nx_local, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    
    double Ct11, Ct12, eig11; 
    
    if (idx < nx_local*ny*nz)
    {
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;
        
        eig11 = epszero_d * hphisum[idx];
        
        //// if misfitaniso is needed diff in other 2 directions use below with diff aniso value.
        //eigsts[idx] = Ct11*eig11 + Ct12*eig11*misfit_aniso + Ct12*eig11*misfit_aniso;
        //If misit_aniso is diff in Y,Z we have to take another misfit_aniso.

        eigsts[idx] = Ct11*eig11 + 2.0 * Ct12*eig11*misfit_aniso; 

    }

    __syncthreads();
}

__global__ void Compute_eigsts1(double *eigsts, double *hphisum, double Chom11_d,
                                double Chom12_d, double Chet11_d, double Chet12_d,
                                double epszero_d, double misfit_aniso, int EC_calc,
                                long nx_local, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    double Ct11, Ct12, eig11; 
    if (idx < nx_local*ny*nz)
    {
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;
        
        eig11 = epszero_d * hphisum[idx];
         
        //eigsts[idx] = Ct12*eig11 + Ct11*eig22 + Ct12*eig33;
        //If misit_aniso is diff in Y,Z we have to take another misfit_aniso.

        eigsts[idx] = Ct11*eig11*misfit_aniso + Ct12*eig11*(1.0 + misfit_aniso);

    }
    __syncthreads();
}

__global__ void Compute_eigsts2(double *eigsts, double *hphisum, double Chom11_d,
                                double Chom12_d, double Chet11_d, double Chet12_d,
                                double epszero_d, double misfit_aniso, int EC_calc, 
                                long nx_local, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    double  Ct11, Ct12, eig11; 
    if (idx < nx_local*ny*nz)
    {
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;
        eig11 = epszero_d * hphisum[idx];
        
        //eigsts[idx] = Ct12*eig11 + Ct12*eig22 + Ct11*eig33;
        //If misit_aniso is diff in Y,Z we have to take another misfit_aniso.

        eigsts[idx] = Ct11*eig11*misfit_aniso + Ct12*eig11*(1.0 + misfit_aniso);

    }
    __syncthreads();
}*/

__global__ void Compute_persts_N(double *persts11, double *persts22, double *persts33,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                const double* __restrict__ hphisum,
                                const double* __restrict__ Chom,const double* __restrict__ Chet,
                                int ny, int nz)


{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        
        const double temp = 2.0*hphisum[idx] - 1.0;
        const double Ct11 = Chom[0] + Chet[0] * temp; 
        const double Ct12 = Chom[1] + Chet[1] * temp;

        //persts[idx] = (Ct11*(str_v0_begin->x) + Ct12*(str_v1_begin->x) + Ct12*(str_v2_begin->x));
        persts11[idx] = (fma(Ct11, (str_v0_begin->x), Ct12*((str_v1_begin->x)+(str_v2_begin->x))));
        persts22[idx] = (fma(Ct11, (str_v1_begin->x), Ct12*((str_v0_begin->x)+(str_v2_begin->x))));
        persts33[idx] = (fma(Ct11, (str_v2_begin->x), Ct12*((str_v0_begin->x)+(str_v1_begin->x))));

    }
    //__syncthreads();
}

__global__ void Compute_persts_S(double *persts23, double *persts13, double *persts12,
                                BoxIterator<cufftDoubleComplex> str_v3_begin,
                                BoxIterator<cufftDoubleComplex> str_v3_end,
                                BoxIterator<cufftDoubleComplex> str_v4_begin,
                                BoxIterator<cufftDoubleComplex> str_v5_begin,
                                const double* __restrict__ hphisum, 
                                const double* __restrict__ Chom, 
                                const double* __restrict__ Chet, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v3_begin += idx;
    str_v4_begin += idx;
    str_v5_begin += idx;

    if (str_v3_begin < str_v3_end)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        const double Ct44 = Chom[2] + Chet[2] * temp; 

        persts23[idx] = (2.0*Ct44*(str_v3_begin->x));
        persts13[idx] = (2.0*Ct44*(str_v4_begin->x));
        persts12[idx] = (2.0*Ct44*(str_v5_begin->x));
    }
    //__syncthreads();
}
/*
__global__ void Compute_persts0(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double *hphisum, double Chom11_d,
                                double Chom12_d, double Chet11_d, double Chet12_d,
                                int EC_calc, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    double Ct11, Ct12;
    if (str_v0_begin < str_v0_end)
    {
        if (EC_calc == 0)
        {
            Ct11 = Chom11_d + Chet11_d * (2.0*hphisum[idx] - 1.0);
            Ct12 = Chom12_d + Chet12_d * (2.0*hphisum[idx] - 1.0);
        }
        else if (EC_calc == 1)
        {
            Ct11 = Chom11_d + (Chet11_d * hphisum[idx]);
            Ct12 = Chom12_d + (Chet12_d * hphisum[idx]);
        }
        
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;

        //persts[idx] = (Ct11*(str_v0_begin->x) + Ct12*(str_v1_begin->x) + Ct12*(str_v2_begin->x));
        persts[idx] = fma(Ct11, (str_v0_begin->x), Ct12*((str_v1_begin->x)+(str_v2_begin->x)));

    }
    __syncthreads();
}

__global__ void Compute_persts1(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double *hphisum, double Chom11_d,
                                double Chom12_d, double Chet11_d, double Chet12_d,
                                int EC_calc, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    double Ct11, Ct12;
    if (str_v0_begin < str_v0_end)
    {
        
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;

        //persts[idx] = (Ct12*(str_v0_begin->x) + Ct11*(str_v1_begin->x) + Ct12*(str_v2_begin->x));
        persts[idx] = fma(Ct11, (str_v1_begin->x), Ct12*((str_v0_begin->x)+(str_v2_begin->x)));

    }
    __syncthreads();
}

__global__ void Compute_persts2(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double *hphisum, double Chom11_d,  double Chet11_d,
                                double Chom12_d,  double Chet12_d,
                                int EC_calc, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    double Ct11, Ct12;
    if (str_v0_begin < str_v0_end)
    {   
        if (EC_calc == 0)
        {
            Ct11 = Chom11_d + Chet11_d * (2.0*hphisum[idx] - 1.0);
            Ct12 = Chom12_d + Chet12_d * (2.0*hphisum[idx] - 1.0);
        }
        else if (EC_calc == 1)
        {
            Ct12 = Chom12_d + (Chet12_d * hphisum[idx]);
            Ct12 = Chom12_d + (Chet12_d * hphisum[idx]);
        }
        double temp = 2.0*hphisum[idx] - 1.0;
        Ct11 = Chom11_d + Chet11_d * temp; 
        Ct12 = Chom12_d + Chet12_d * temp;

        //persts[idx] = (Ct12*(str_v0_begin->x) + Ct12*(str_v1_begin->x) + Ct11*(str_v2_begin->x));
        persts[idx] = fma(Ct11, (str_v2_begin->x), Ct12*((str_v0_begin->x)+(str_v1_begin->x)));

    }
    __syncthreads();
}

__global__ void Compute_perstsxy(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v_begin,
                                BoxIterator<cufftDoubleComplex> str_v_end,
                                double *hphisum, double Chom44_d,
                                double Chet44_d,int EC_calc, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v_begin += idx;

    double Ct44;
    if (str_v_begin < str_v_end)
    {
        if (EC_calc == 0)
        {
            Ct44 = Chom44_d + Chet44_d * (2.0*hphisum[idx] - 1.0);
        }
        else if (EC_calc == 1)
        {
            Ct44 = Chom44_d + (Chet44_d * hphisum[idx]);
        }

        double temp = 2.0*hphisum[idx] - 1.0;
        Ct44 = Chom44_d + Chet44_d * temp; 

        persts[idx] = Ct44*(str_v_begin->x);
    }
    __syncthreads();
}
*/
//// This is called inside time loop so for a timestep eigsts and S_d pointers are scaled already outside timeloop
__global__ void Compute_homstr2(double* __restrict__ hom_strain_v, double *S_d, 
                                   const double* __restrict__ sigappl, double* __restrict__ avgeigsts,
                                   double* __restrict__ avgpersts, int misfit_aniso, int nx, int ny, int nz)
{
    double sizescale = 1.0/((double)(nx*ny*nz));
    
    const double S11  = S_d[0];
    const double S12  = S_d[1];
    const double S44  = S_d[2];
    
    avgpersts[0] *= sizescale;
    avgpersts[1] *= sizescale;
    avgpersts[2] *= sizescale;
    avgpersts[3] *= sizescale;
    avgpersts[4] *= sizescale;
    avgpersts[5] *= sizescale;
    
    const double ts0 = sigappl[0] + avgeigsts[0] - avgpersts[0];
    const double ts1 = sigappl[1] + avgeigsts[1] - avgpersts[1];
    const double ts2 = sigappl[2] + avgeigsts[2] - avgpersts[2];
    const double ts3 = sigappl[3] - avgpersts[3];
    const double ts4 = sigappl[4] - avgpersts[4];
    const double ts5 = sigappl[5] - avgpersts[5];
    
    hom_strain_v[0] = (S11 * ts0) + (S12 * ts1) + (S12 * ts2);
    hom_strain_v[1] = (S12 * ts0) + (S11 * ts1) + (S12 * ts2);
    hom_strain_v[2] = (S12 * ts0) + (S12 * ts1) + (S11 * ts2);
    
    hom_strain_v[3] = 0.5*S44 * ts3;
    hom_strain_v[4] = 0.5*S44 * ts4;
    hom_strain_v[5] = 0.5*S44 * ts5;
}

__global__ void Compute_homstr(double *hom_strain_v, double *S_d,  double *sigappl,
                               double *avgeigsts, double *avgpersts, int misfit_aniso,
                               int nx, int ny, int nz)
{
    double size_scale = 1.0/((double)(nx*ny*nz));
    
    avgpersts[0] *= size_scale;
    avgpersts[1] *= size_scale;
    avgpersts[2] *= size_scale;
    avgpersts[3] *= size_scale;
    avgpersts[4] *= size_scale;
    avgpersts[5] *= size_scale;
    
    if (misfit_aniso == 1)
    {
        avgeigsts[0] *= size_scale;
        avgeigsts[1] = avgeigsts[0];
        avgeigsts[2] = avgeigsts[0];
    }
    else
    {
        avgeigsts[0] *= size_scale;
        avgeigsts[1] *= size_scale;
        avgeigsts[2] = avgeigsts[1];
    }
    const double S11  = S_d[0];
    const double S12  = S_d[1];
    const double S44  = S_d[2];
    
    //// NOTE:homstrain = appl_sts - persts + eigsts;

    const double ts0 = sigappl[0] - avgpersts[0] + avgeigsts[0];
    const double ts1 = sigappl[1] - avgpersts[1] + avgeigsts[1];
    const double ts2 = sigappl[2] - avgpersts[2] + avgeigsts[2];
    const double ts3 = sigappl[3] - avgpersts[3]; 
    const double ts4 = sigappl[4] - avgpersts[4]; 
    const double ts5 = sigappl[5] - avgpersts[5];
    
    hom_strain_v[0] = S11*(ts0) + S12*(ts1) + S12*(ts2);
    hom_strain_v[1] = S12*(ts0) + S11*(ts1) + S12*(ts2);
    hom_strain_v[2] = S12*(ts0) + S12*(ts1) + S11*(ts2);

    hom_strain_v[3] = 0.5*S44 * ts3;
    hom_strain_v[4] = 0.5*S44 * ts4;
    hom_strain_v[5] = 0.5*S44 * ts5;
}

__global__ void Compute_ts(BoxIterator<cufftDoubleComplex> str_v0_begin,
                             BoxIterator<cufftDoubleComplex> str_v0_end,
                             BoxIterator<cufftDoubleComplex> str_v1_begin,
                             BoxIterator<cufftDoubleComplex> str_v2_begin,
                             BoxIterator<cufftDoubleComplex> str_v3_begin,
                             BoxIterator<cufftDoubleComplex> str_v4_begin,
                             BoxIterator<cufftDoubleComplex> str_v5_begin,
                             const double* __restrict__ hom_strain_v, 
                             const double* __restrict__ hphisum, 
                             const double* __restrict__ Chom, 
                             const double* __restrict__ Chet,
                             double epszero_d, double misfit_aniso)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz_d*(j + i*ny_d);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        const double hsum = hphisum[idx];
        const double tmp = (2.0*hsum - 1.0); 
        const double eig11 = epszero_d*hsum;
        const double eig22 = eig11 * misfit_aniso;
        ////Assumed misfit_aniso is same in 22 & 33.

        const double Ct0 = Chom[0] + Chet[0]*tmp; ////Ct11.
        const double Ct1 = Chom[1] + Chet[1]*tmp; ////Ct12.
        const double Ct2 = Chom[2] + Chet[2]*tmp; ////Ct44.

        const double Cin0 = Ct0 - Chom[0];
        const double Cin1 = Ct1 - Chom[1];
        const double Cin2 = Ct2 - Chom[2];

        const double hom0 = hom_strain_v[0]; 
        const double hom1 = hom_strain_v[1]; 
        const double hom2 = hom_strain_v[2]; 
        const double hom3 = hom_strain_v[3]; 
        const double hom4 = hom_strain_v[4]; 
        const double hom5 = hom_strain_v[5];

        const double temp0 = str_v0_begin->x;
        const double temp1 = str_v1_begin->x;
        const double temp2 = str_v2_begin->x;
        const double temp3 = str_v3_begin->x;
        const double temp4 = str_v4_begin->x;
        const double temp5 = str_v5_begin->x;

        *str_v0_begin = {(Ct0*(eig11-(hom0)) - Cin0*temp0 + 
                          Ct1*(eig22-(hom1)) - Cin1*temp1 + 
                          Ct1*(eig22-(hom2)) - Cin1*temp2 ), 0.0};
        
        *str_v1_begin = {(Ct1*(eig11-(hom0)) - Cin1*temp0 + 
                          Ct0*(eig22-(hom1)) - Cin0*temp1 + 
                          Ct1*(eig22-(hom2)) - Cin1*temp2 ), 0.0};
        
        *str_v2_begin = {(Ct1*(eig11-(hom0)) - Cin1*temp0 + 
                          Ct1*(eig22-(hom1)) - Cin1*temp1 + 
                          Ct0*(eig22-(hom2)) - Cin0*temp2 ), 0.0};
        
        *str_v3_begin = {2.0*(Ct2*(-1.0*(hom3)) - Cin2*temp3), 0.0};
        *str_v4_begin = {2.0*(Ct2*(-1.0*(hom4)) - Cin2*temp4), 0.0};
        *str_v5_begin = {2.0*(Ct2*(-1.0*(hom5)) - Cin2*temp5), 0.0};

    }
   // __syncthreads();
}
/*
__global__ void Compute_ts_N(BoxIterator<cufftDoubleComplex> ts0_begin,
                             BoxIterator<cufftDoubleComplex> ts0_end,
                             BoxIterator<cufftDoubleComplex> ts1_begin,
                             BoxIterator<cufftDoubleComplex> ts1_end,
                             BoxIterator<cufftDoubleComplex> ts2_begin,
                             BoxIterator<cufftDoubleComplex> ts2_end,
                             BoxIterator<cufftDoubleComplex> str_v0_begin,
                             BoxIterator<cufftDoubleComplex> str_v0_end,
                             BoxIterator<cufftDoubleComplex> str_v1_begin,
                             BoxIterator<cufftDoubleComplex> str_v1_end,
                             BoxIterator<cufftDoubleComplex> str_v2_begin,
                             BoxIterator<cufftDoubleComplex> str_v2_end,
                             double *hom_strain_v, double *hphisum, 
                             double epszero_d, double misfit_aniso,
                             double *Chom, double *Chet,
                             long nx, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    //ts0_begin += idx; 
    ts0_begin += idx; ts1_begin += idx; ts2_begin += idx;

    double Ct[3] = {0.0};
    double Cin[3] = {0.0};
    double eig11, eig22, eig33;
    double temp_v[3];
    if (ts0_begin < ts0_end)
    { 
        get_Ct_Cin(Ct, Cin, Chet, Chom, hphisum, idx);
        
        eig11 = (epszero_d)*hphisum[idx];
        eig22 = eig11 * misfit_aniso;
        eig33 = eig22;

        temp_v[0] = str_v0_begin->x;
        temp_v[1] = str_v1_begin->x;
        temp_v[2] = str_v2_begin->x;

        *ts0_begin = {(Ct[0]*(eig11-(hom_strain_v[0])) - Cin[0]*temp_v[0] + 
                       Ct[1]*(eig22-(hom_strain_v[1])) - Cin[1]*temp_v[1] + 
                       Ct[1]*(eig33-(hom_strain_v[2])) - Cin[1]*temp_v[2] ), 0.0};
        
        *ts1_begin = {(Ct[1]*(eig11-(hom_strain_v[0])) - Cin[1]*temp_v[0] + 
                       Ct[0]*(eig22-(hom_strain_v[1])) - Cin[0]*temp_v[1] + 
                       Ct[1]*(eig33-(hom_strain_v[2])) - Cin[1]*temp_v[2] ), 0.0};
        
        *ts2_begin = {(Ct[1]*(eig11-(hom_strain_v[0])) - Cin[1]*temp_v[0] + 
                       Ct[1]*(eig22-(hom_strain_v[1])) - Cin[1]*temp_v[1] + 
                       Ct[0]*(eig33-(hom_strain_v[2])) - Cin[0]*temp_v[2] ), 0.0};

    }
    __syncthreads();
}

__global__ void Compute_ts_S(BoxIterator<cufftDoubleComplex> ts3_begin,
                             BoxIterator<cufftDoubleComplex> ts3_end,
                             BoxIterator<cufftDoubleComplex> ts4_begin,
                             BoxIterator<cufftDoubleComplex> ts4_end,
                             BoxIterator<cufftDoubleComplex> ts5_begin,
                             BoxIterator<cufftDoubleComplex> ts5_end,
                             BoxIterator<cufftDoubleComplex> str_v3_begin,
                             BoxIterator<cufftDoubleComplex> str_v3_end,
                             BoxIterator<cufftDoubleComplex> str_v4_begin,
                             BoxIterator<cufftDoubleComplex> str_v4_end,
                             BoxIterator<cufftDoubleComplex> str_v5_begin,
                             BoxIterator<cufftDoubleComplex> str_v5_end,
                             double *hom_strain_v, double *hphisum, 
                             double *Chom, double *Chet,
                             long nx, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;
    ts3_begin += idx; ts4_begin += idx; ts5_begin += idx;

    double Ct[3] = {0.0};
    double Cin[3] = {0.0};
    double temp_v[3];
    if (ts3_begin < ts3_end)
    {
        get_Ct_Cin(Ct, Cin, Chet, Chom, hphisum, idx);
        
        temp_v[0] = str_v3_begin->x;
        temp_v[1] = str_v4_begin->x;
        temp_v[2] = str_v5_begin->x;

        *ts3_begin = {(Ct[2]*(-1.0*(hom_strain_v[3])) - Cin[2]*temp_v[0]), 0.0};
        *ts4_begin = {(Ct[2]*(-1.0*(hom_strain_v[4])) - Cin[2]*temp_v[1]), 0.0};
        *ts5_begin = {(Ct[2]*(-1.0*(hom_strain_v[5])) - Cin[2]*temp_v[2]), 0.0};
    }
    __syncthreads();
}
*/

__global__ void Update_disp(BoxIterator<cufftDoubleComplex> unewx_begin,
                            BoxIterator<cufftDoubleComplex> unewx_end,
                            BoxIterator<cufftDoubleComplex> unewy_begin,
                            BoxIterator<cufftDoubleComplex> unewz_begin,
                            BoxIterator<cufftDoubleComplex> ts0_begin,
                            BoxIterator<cufftDoubleComplex> ts1_begin,
                            BoxIterator<cufftDoubleComplex> ts2_begin,
                            BoxIterator<cufftDoubleComplex> ts3_begin,
                            BoxIterator<cufftDoubleComplex> ts4_begin,
                            BoxIterator<cufftDoubleComplex> ts5_begin,
                            const double* __restrict__ Chom)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz_d*(j + i*ny_d);

    unewx_begin += idx; unewy_begin += idx; unewz_begin += idx;
    ts0_begin += idx; ts1_begin += idx; ts2_begin += idx;
    ts3_begin += idx; ts4_begin += idx; ts5_begin += idx;

    cufftDoubleComplex fk11, fk22, fk33;
    double n[3], omega[6]; 
    
    if (unewx_begin < unewx_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], ts0_begin); 
        get_omega(omega, n, Chom);

        const cufftDoubleComplex stmp0 = *ts0_begin;
        const cufftDoubleComplex stmp1 = *ts1_begin;
        const cufftDoubleComplex stmp2 = *ts2_begin;
        const cufftDoubleComplex stmp3 = *ts3_begin;
        const cufftDoubleComplex stmp4 = *ts4_begin;
        const cufftDoubleComplex stmp5 = *ts5_begin;
         
        fk11.x = stmp0.x * n[0] + stmp5.x * n[1] + stmp4.x*n[2];
        fk22.x = stmp5.x * n[0] + stmp1.x * n[1] + stmp3.x*n[2];
        fk33.x = stmp4.x * n[0] + stmp3.x * n[1] + stmp2.x*n[2];

        fk11.y = stmp0.y * n[0] + stmp5.y * n[1] + stmp4.y*n[2];
        fk22.y = stmp5.y * n[0] + stmp1.y * n[1] + stmp3.y*n[2];
        fk33.y = stmp4.y * n[0] + stmp3.y * n[1] + stmp2.y*n[2];

        *unewx_begin = {(omega[0]*fk11.y + omega[5]*fk22.y + omega[4]*fk33.y), 
                        -1.0*(omega[0]*fk11.x + omega[5]*fk22.x + omega[4]*fk33.x)};
        
        *unewy_begin = {(omega[5]*fk11.y + omega[1]*fk22.y + omega[3]*fk33.y), 
                        -1.0*(omega[5]*fk11.x + omega[1]*fk22.x + omega[3]*fk33.x)};
        
        *unewz_begin = {(omega[4]*fk11.y + omega[3]*fk22.y + omega[2]*fk33.y), 
                        -1.0*(omega[4]*fk11.x + omega[3]*fk22.x + omega[2]*fk33.x)};
    }
    //__syncthreads();
}


__global__ void Compute_diff_disp(BoxIterator<cufftDoubleComplex> unewx_begin,
                                  BoxIterator<cufftDoubleComplex> unewx_end,
                                  BoxIterator<cufftDoubleComplex> unewy_begin,
                                  BoxIterator<cufftDoubleComplex> unewz_begin,
                                  BoxIterator<cufftDoubleComplex> ux_begin,
                                  BoxIterator<cufftDoubleComplex> uy_begin,
                                  BoxIterator<cufftDoubleComplex> uz_begin,
                                  double* __restrict__ diff_disp, double* __restrict__ diff_disp2, 
                                  double* __restrict__ diff_disp3, int norm_calc) 
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz_d*(j + i*ny_d);

    unewx_begin += idx; unewy_begin += idx; unewz_begin += idx;
    ux_begin += idx; uy_begin += idx; uz_begin += idx;

    if (unewx_begin < unewx_end)
    {
        const double unewx = unewx_begin->x;
        const double unewy = unewy_begin->x;
        const double unewz = unewz_begin->x;
        
        const double ux = ux_begin->x;
        const double uy = uy_begin->x;
        const double uz = uz_begin->x;
        if (norm_calc == 0)
        {
            double dx = unewx - ux;
            double dy = unewy - uy;
            double dz = unewz - uz;

            diff_disp[idx] = (dx*dx + dy*dy + dz*dz); 
        }
        if (norm_calc == 1)
        {
            diff_disp[idx] =  (unewx - ux);
            diff_disp2[idx] = (unewy - uy); 
            diff_disp3[idx] = (unewz - uz); 
        }
    }
   // __syncthreads();

}

__global__ void Copy_new_sol(BoxIterator<cufftDoubleComplex> unewx_begin,
                             BoxIterator<cufftDoubleComplex> unewx_end,
                             BoxIterator<cufftDoubleComplex> unewy_begin,
                             BoxIterator<cufftDoubleComplex> unewz_begin,
                             BoxIterator<cufftDoubleComplex> ux_begin,
                             BoxIterator<cufftDoubleComplex> uy_begin,
                             BoxIterator<cufftDoubleComplex> uz_begin)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz_d*(j + i*ny_d);

    unewx_begin += idx; unewy_begin += idx; unewz_begin += idx;
    ux_begin += idx; uy_begin += idx; uz_begin += idx;

    if (unewx_begin < unewx_end)
    {
        *ux_begin = {unewx_begin->x, unewx_begin->y};
        *uy_begin = {unewy_begin->x, unewy_begin->y};
        *uz_begin = {unewz_begin->x, unewz_begin->y};
    }
   // __syncthreads();
}

__global__ void Compute_dfeldphi_inhomsv(BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                                         BoxIterator<cufftDoubleComplex> dfdphi0_end,
                                         BoxIterator<cufftDoubleComplex> str_v0_begin,
                                         BoxIterator<cufftDoubleComplex> str_v1_begin,
                                         BoxIterator<cufftDoubleComplex> str_v2_begin,
                                         BoxIterator<cufftDoubleComplex> str_v3_begin,
                                         BoxIterator<cufftDoubleComplex> str_v4_begin,
                                         BoxIterator<cufftDoubleComplex> str_v5_begin,
                                         double* __restrict__ felas, const double* __restrict__ hphisum, 
                                         const double* __restrict__ dhdphi, const double* __restrict__ hom_strain_v, 
                                         double Chom11_d, double Chom12_d, double Chom44_d, 
                                         double Chet11_d, double Chet12_d, double Chet44_d, 
                                         double epszero_d, double misfit_aniso, 
                                         int engs_out, int output, int TRACK_OBS, long nx, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));
    
    dfdphi0_begin += idx;
    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (dfdphi0_begin < dfdphi0_end)
    {
        double df = dfdphi0_begin->x;
        double temp = 2.0*hphisum[idx] - 1.0;
        double Ct11 = Chom11_d + Chet11_d * temp; 
        double Ct12 = Chom12_d + Chet12_d * temp;
        double Ct44 = Chom44_d + Chet44_d * temp;
        
        double hphi = hphisum[idx];
        double eig11 = epszero_d; 
        double eig22 = eig11 * misfit_aniso;

        double e11 = hom_strain_v[0] + str_v0_begin->x - eig11*hphi;
        double e22 = hom_strain_v[1] + str_v1_begin->x - eig22*hphi;
        double e33 = hom_strain_v[2] + str_v2_begin->x - eig22*hphi; ////eig33 since misfit_aniso is same so using eig22.
        double e23 = hom_strain_v[3] + str_v3_begin->x;
        double e13 = hom_strain_v[4] + str_v4_begin->x;
        double e12 = hom_strain_v[5] + str_v5_begin->x;
        
        *dfdphi0_begin = {df + (dhdphi[idx]*(0.5*(2.0*Chet11_d*(e11*e11 + e22*e22 + e33*e33) +
                                                    4.0*Chet12_d*(e11*e22 + e11*e33 + e22*e33) +
                                                    8.0*Chet44_d*(e23*e23 + e13*e13 + e12*e12)) -

                                               1.0*(Ct11*(e11*eig11 + e22*eig22 + e33*eig22) +
                                                    Ct12*(e11*eig22 + e22*eig11 + e11*eig22 + 
                                                    e33*eig11 + e22*eig22 + e33*eig22)))), 0.0};
        
        if (TRACK_OBS == 1 || (engs_out != 0 && output == 1))
        {
            felas[idx] = 0.5*(Ct11*(e11*e11 + e22*e22 + e33*e33)+
                              Ct12*2.0*(e11*e22 + e11*e33 + e22*e33)+
                              Ct44*4.0*(e23*e23 + e13*e13 + e12*e12));
        }
    }
}

__global__ void Compute_dfeldphi_inhom(BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                                         BoxIterator<cufftDoubleComplex> dfdphi0_end,
                                         BoxIterator<cufftDoubleComplex> dfdphi1_begin,
                                         BoxIterator<cufftDoubleComplex> dfdphi2_begin,
                                         BoxIterator<cufftDoubleComplex> dfdphi3_begin,
                                         BoxIterator<cufftDoubleComplex> str_v0_begin,
                                         BoxIterator<cufftDoubleComplex> str_v1_begin,
                                         BoxIterator<cufftDoubleComplex> str_v2_begin,
                                         BoxIterator<cufftDoubleComplex> str_v3_begin,
                                         BoxIterator<cufftDoubleComplex> str_v4_begin,
                                         BoxIterator<cufftDoubleComplex> str_v5_begin,
                                         double* __restrict__ felas,
                                         const double* __restrict__ hphisum, const double* __restrict__ dhdphi0, 
                                         const double* __restrict__ dhdphi1,  const double* __restrict__ dhdphi2, 
                                         const double* __restrict__ dhdphi3, double *hom_strain_v, 
                                         double Chom11_d, double Chom12_d, double Chom44_d, 
                                         double Chet11_d, double Chet12_d, double Chet44_d, 
                                         double epszero_d, double misfit_aniso,int engs_out, 
                                         int output, int TRACK_OBS, long nx, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));
    
    dfdphi0_begin += idx;
    dfdphi1_begin += idx;
    dfdphi2_begin += idx;
    dfdphi3_begin += idx;
    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (dfdphi0_begin < dfdphi0_end)
    {
        double df0 = dfdphi0_begin->x;
        double df1 = dfdphi1_begin->x;
        double df2 = dfdphi2_begin->x;
        double df3 = dfdphi3_begin->x;
        
        double temp = 2.0*hphisum[idx] - 1.0;
        double Ct11 = Chom11_d + Chet11_d * temp; 
        double Ct12 = Chom12_d + Chet12_d * temp;
        double Ct44 = Chom44_d + Chet44_d * temp;
        
        double hphi = hphisum[idx];
        double eig11 = epszero_d; 
        double eig22 = eig11 * misfit_aniso;

        double e11 = hom_strain_v[0] + str_v0_begin->x - eig11*hphi;
        double e22 = hom_strain_v[1] + str_v1_begin->x - eig22*hphi;
        double e33 = hom_strain_v[2] + str_v2_begin->x - eig22*hphi; ////eig33 since misfit_aniso is same so using eig22.
        double e23 = hom_strain_v[3] + str_v3_begin->x;
        double e13 = hom_strain_v[4] + str_v4_begin->x;
        double e12 = hom_strain_v[5] + str_v5_begin->x;
        
        double dfelas = (0.5*(2.0*Chet11_d*(e11*e11 + e22*e22 + e33*e33) +
                              4.0*Chet12_d*(e11*e22 + e11*e33 + e22*e33) +
                              8.0*Chet44_d*(e23*e23 + e13*e13 + e12*e12)) -

                              1.0*(Ct11*(e11*eig11 + e22*eig22 + e33*eig22) +
                                   Ct12*(e11*eig22 + e22*eig11 + e11*eig22 + 
                                          e33*eig11 + e22*eig22 + e33*eig22)));
        
        *dfdphi0_begin = {(df0 + (dhdphi0[idx]*dfelas)), 0.0};
        *dfdphi1_begin = {(df1 + (dhdphi1[idx]*dfelas)), 0.0};
        *dfdphi2_begin = {(df2 + (dhdphi2[idx]*dfelas)), 0.0};
        *dfdphi3_begin = {(df3 + (dhdphi3[idx]*dfelas)), 0.0};
        
        if (TRACK_OBS == 1 || (engs_out != 0 && output == 1))
        {
            felas[idx] = 0.5*(Ct11*(e11*e11 + e22*e22 + e33*e33)+
                              Ct12*2.0*(e11*e22 + e11*e33 + e22*e33)+
                              Ct44*4.0*(e23*e23 + e13*e13 + e12*e12));
        }
    }
    //__syncthreads();
}
/*
__global__ void Compute_dfeldphi(double *dfeldphi,
                                 BoxIterator<cufftDoubleComplex> str_v0_begin,
                                 BoxIterator<cufftDoubleComplex> str_v0_end,
                                 BoxIterator<cufftDoubleComplex> str_v1_begin,
                                 BoxIterator<cufftDoubleComplex> str_v1_end,
                                 BoxIterator<cufftDoubleComplex> str_v2_begin,
                                 BoxIterator<cufftDoubleComplex> str_v2_end,
                                 BoxIterator<cufftDoubleComplex> str_v3_begin,
                                 BoxIterator<cufftDoubleComplex> str_v3_end,
                                 BoxIterator<cufftDoubleComplex> str_v4_begin,
                                 BoxIterator<cufftDoubleComplex> str_v4_end,
                                 BoxIterator<cufftDoubleComplex> str_v5_begin,
                                 BoxIterator<cufftDoubleComplex> str_v5_end,
                                 double *hphisum, double *dhdphi, double *hom_strain_v, 
                                 double Chom11_d, double Chom12_d, double Chom44_d, 
                                 double Chet11_d, double Chet12_d, double Chet44_d, 
                                 double epszero_d, double misfit_aniso, 
                                 long nx, long ny, long nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (str_v0_begin < str_v0_end)
    { 
        double temp = 2.0*hphisum[idx] - 1.0;
        double Ct11 = Chom11_d + Chet11_d * temp; 
        double Ct12 = Chom12_d + Chet12_d * temp;
        
        double hphi = hphisum[idx];
        double eig11 = epszero_d; 
        double eig22 = eig11 * misfit_aniso;

        double e11 = hom_strain_v[0] + str_v0_begin->x - eig11*hphi;
        double e22 = hom_strain_v[1] + str_v1_begin->x - eig22*hphi;
        double e33 = hom_strain_v[2] + str_v2_begin->x - eig22*hphi; ////eig33 since misfit_aniso is same so using eig22.
        double e23 = hom_strain_v[3] + str_v3_begin->x;
        double e13 = hom_strain_v[4] + str_v4_begin->x;
        double e12 = hom_strain_v[5] + str_v5_begin->x;
        
        dfeldphi[idx] = dhdphi[idx]*(0.5*(2.0*Chet11_d*(e11*e11 + e22*e22 + e33*e33) +
                                          4.0*Chet12_d*(e11*e22 + e11*e33 + e22*e33) +
                                          2.0*Chet44_d*(e23*e23 + e13*e13 + e12*e12)) -

                                     1.0*(Ct11*(e11*eig11 + e22*eig22 + e33*eig22) +
                                          Ct12*(e11*eig22 + e22*eig11 + e11*eig22 + 
                                                e33*eig11 + e22*eig22 + e33*eig22)));


    }
    __syncthreads();
}
*/

__global__ void Compute_str_sts(double* __restrict__ e11, double* __restrict__ e22, double* __restrict__ e33, 
                                double* __restrict__ s11, double* __restrict__ s22, double* __restrict__ s33, 
                                BoxIterator<cufftDoubleComplex> str_v0_begin, BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin, BoxIterator<cufftDoubleComplex> str_v2_begin, 
                                const double* __restrict__ hphisum, const double* __restrict__ Chom,
                                const double* __restrict__ Chet, double *hom_strain_v, double epszero_d, double misfit_aniso, 
                                int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom11 = Chom[0];
        const double Chom12 = Chom[1];

        const double Chet11 = Chet[0];
        const double Chet12 = Chet[1];
        
        const double Ct11 = Chom11 + (Chet11 * temp); 
        const double Ct12 = Chom12 + (Chet12 * temp);
        
        const double eig11 = epszero_d*hphisum[idx];
        const double eig22 = eig11*misfit_aniso;
        
        const double homstrain0 = hom_strain_v[0];
        const double homstrain1 = hom_strain_v[1];
        const double homstrain2 = hom_strain_v[2];

        const double E11 = homstrain0 + str_v0_begin->x - eig11;
        const double E22 = homstrain1 + str_v1_begin->x - eig22;
        const double E33 = homstrain2 + str_v2_begin->x - eig22; ////eig33 since misfit_aniso is same so using eig22.
        
        const double S11 = Ct11*E11 + Ct12*E22 + Ct12*E33;
        const double S22 = Ct12*E11 + Ct11*E22 + Ct12*E33;
        const double S33 = Ct12*E11 + Ct12*E22 + Ct11*E33;
        
        //e_eq[idx] = sqrt((2.0/3.0)* ((E1*E1) + (E2*E2) + (E3*E3) + 6.0*((E23*E23) + (E13*E13) + (E12*E12))));
        
        e11[idx] = E11;
        e22[idx] = E22;
        e33[idx] = E33;
        
        s11[idx] = S11;
        s22[idx] = S22;
        s33[idx] = S33;
    }
}

__global__ void Compute_str_sts2(double* __restrict__ e23, double* __restrict__ e13, double* __restrict__ e12, 
                                double* __restrict__ s23, double* __restrict__ s13, double* __restrict__ s12, 
                            BoxIterator<cufftDoubleComplex> str_v3_begin, BoxIterator<cufftDoubleComplex> str_v4_begin,
                            BoxIterator<cufftDoubleComplex> str_v5_begin, BoxIterator<cufftDoubleComplex> str_v5_end, 
                            const double* __restrict__ hphisum, const double* __restrict__ Chom,
                            const double* __restrict__ Chet, double *hom_strain_v, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));

    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (str_v5_begin < str_v5_end)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom44 = Chom[2];
        const double Chet44 = Chet[2];
        const double Ct44 = Chom44 + (Chet44 * temp);
        
        const double homstrain3 = hom_strain_v[3];
        const double homstrain4 = hom_strain_v[4];
        const double homstrain5 = hom_strain_v[5];

        const double E23 = homstrain3 + str_v3_begin->x;
        const double E13 = homstrain4 + str_v4_begin->x;
        const double E12 = homstrain5 + str_v5_begin->x; 

        e23[idx] = E23;
        e13[idx] = E13;
        e12[idx] = E12;
         
        const double S13 = 2.0*Ct44*E13;
        const double S12 = 2.0*Ct44*E12;
        const double S23 = 2.0*Ct44*E23; 
        
        s23[idx] = S23;
        s13[idx] = S13;
        s12[idx] = S12;

    }
}


__global__ void Compute_str(double* __restrict__ e11, double* __restrict__ e22, double* __restrict__ e33, 
                            double* __restrict__ e23, double* __restrict__ e13, double* __restrict__ e12, 
                            double* __restrict__ e_eq,
                            BoxIterator<cufftDoubleComplex> str_v0_begin, BoxIterator<cufftDoubleComplex> str_v0_end,
                            BoxIterator<cufftDoubleComplex> str_v1_begin, BoxIterator<cufftDoubleComplex> str_v2_begin, 
                            BoxIterator<cufftDoubleComplex> str_v3_begin, BoxIterator<cufftDoubleComplex> str_v4_begin,
                            BoxIterator<cufftDoubleComplex> str_v5_begin, const double* __restrict__ hphisum, 
                            double *hom_strain_v, double epszero_d, double misfit_aniso, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        const double eig11 = epszero_d*hphisum[idx];
        const double eig22 = eig11*misfit_aniso;
        
        const double homstrain0 = hom_strain_v[0];
        const double homstrain1 = hom_strain_v[1];
        const double homstrain2 = hom_strain_v[2];
        const double homstrain3 = hom_strain_v[3];
        const double homstrain4 = hom_strain_v[4];
        const double homstrain5 = hom_strain_v[5];

        const double E11 = homstrain0 + str_v0_begin->x - eig11;
        const double E22 = homstrain1 + str_v1_begin->x - eig22;
        const double E33 = homstrain2 + str_v2_begin->x - eig22; ////eig33 since misfit_aniso is same so using eig22.
        const double E23 = homstrain3 + str_v3_begin->x;
        const double E13 = homstrain4 + str_v4_begin->x;
        const double E12 = homstrain5 + str_v5_begin->x; 
        
        const double E1 = E11-E22;
        const double E2 = E22-E33;
        const double E3 = E33-E11;
        
        e_eq[idx] = sqrt((2.0/3.0)* ((E1*E1) + (E2*E2) + (E3*E3) + 6.0*((E23*E23) + (E13*E13) + (E12*E12))));
        
        e11[idx] = E11;
        e22[idx] = E22;
        e33[idx] = E33;
        e23[idx] = E23;
        e13[idx] = E13;
        e12[idx] = E12;
    }
}

__global__ void Compute_sts(double* __restrict__ s11, double* __restrict__ s22, double* __restrict__ s33, 
                            double* __restrict__ s23, double* __restrict__ s13, double* __restrict__ s12,
                            double* __restrict__ s_eq, 
                            const double* __restrict__ e11, const double* __restrict__ e22, const double* __restrict__ e33, 
                            const double* __restrict__ e23, const double* __restrict__ e13, const double* __restrict__ e12,
                            const double* __restrict__ hphisum, const double* __restrict__ Chom, const double* __restrict__ Chet, 
                            int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + (nz*(j + i*ny));
    if (idx < nx_local*ny*nz)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom11 = Chom[0];
        const double Chom12 = Chom[1];
        const double Chom44 = Chom[2];

        const double Chet11 = Chet[0];
        const double Chet12 = Chet[1];
        const double Chet44 = Chet[2];
        
        const double Ct11 = Chom11 + (Chet11 * temp); 
        const double Ct12 = Chom12 + (Chet12 * temp);
        const double Ct44 = Chom44 + (Chet44 * temp);
        
        const double S13 = 2.0*Ct44*e13[idx];
        const double S12 = 2.0*Ct44*e12[idx];
        const double S23 = 2.0*Ct44*e23[idx];
        
        const double S11 = Ct11*e11[idx] + Ct12*e22[idx] + Ct12*e33[idx];
        const double S22 = Ct12*e11[idx] + Ct11*e22[idx] + Ct12*e33[idx];
        const double S33 = Ct12*e11[idx] + Ct12*e22[idx] + Ct11*e33[idx];
        
        
        const double S1 = S11-S22;
        const double S2 = S22-S33;
        const double S3 = S33-S11;        
     
        s_eq[idx] = sqrt(0.5*((S1*S1) + (S2*S2) + (S3*S3) + 6.0*((S23*S23) + (S13*S13) + (S12*S12))));
        
        s11[idx] = S11;
        s22[idx] = S22;
        s33[idx] = S33;
        s23[idx] = S23;
        s13[idx] = S13;
        s12[idx] = S12;
    }
    
}

////Reusing the vars
__global__ void Compute_sts2(double* __restrict__ s11, double* __restrict__ s22, double* __restrict__ s33, 
                            double* __restrict__ s23, double* __restrict__ s13, double* __restrict__ s12,
                            double* __restrict__ s_eq, 
                            const double* __restrict__ hphisum, const double* __restrict__ Chom, const double* __restrict__ Chet, 
                            int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + (nz*(j + i*ny));
    if (idx < nx_local*ny*nz)
    {
        const double e11 = s11[idx];
        const double e22 = s22[idx];
        const double e33 = s33[idx];
        const double e23 = s23[idx];
        const double e13 = s13[idx];
        const double e12 = s12[idx];
        
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom11 = Chom[0];
        const double Chom12 = Chom[1];
        const double Chom44 = Chom[2];

        const double Chet11 = Chet[0];
        const double Chet12 = Chet[1];
        const double Chet44 = Chet[2];
        
        const double Ct11 = Chom11 + (Chet11 * temp); 
        const double Ct12 = Chom12 + (Chet12 * temp);
        const double Ct44 = Chom44 + (Chet44 * temp);
        
        const double S13 = 2.0*Ct44*e13;
        const double S12 = 2.0*Ct44*e12;
        const double S23 = 2.0*Ct44*e23;
        
        const double S11 = Ct11*e11 + Ct12*e22 + Ct12*e33;
        const double S22 = Ct12*e11 + Ct11*e22 + Ct12*e33;
        const double S33 = Ct12*e11 + Ct12*e22 + Ct11*e33;
        
        
        const double S1 = S11-S22;
        const double S2 = S22-S33;
        const double S3 = S33-S11;        
     
        s_eq[idx] = sqrt(0.5*((S1*S1) + (S2*S2) + (S3*S3) + 6.0*((S23*S23) + (S13*S13) + (S12*S12))));
        
        s11[idx] = S11;
        s22[idx] = S22;
        s33[idx] = S33;
        s23[idx] = S23;
        s13[idx] = S13;
        s12[idx] = S12;
    }
    
}

__global__ void Compute_sts_N(double* __restrict__ s11, double* __restrict__ s22, double* __restrict__ s33, 
                            const double* __restrict__ e11, const double* __restrict__ e22, const double* __restrict__ e33, 
                            const double* __restrict__ hphisum, const double* __restrict__ Chom, const double* __restrict__ Chet, 
                            int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + (nz*(j + i*ny));
    if (idx < nx_local*ny*nz)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom11 = Chom[0];
        const double Chom12 = Chom[1];

        const double Chet11 = Chet[0];
        const double Chet12 = Chet[1];
        
        const double Ct11 = Chom11 + (Chet11 * temp); 
        const double Ct12 = Chom12 + (Chet12 * temp);
         
        const double S11 = Ct11*e11[idx] + Ct12*e22[idx] + Ct12*e33[idx];
        const double S22 = Ct12*e11[idx] + Ct11*e22[idx] + Ct12*e33[idx];
        const double S33 = Ct12*e11[idx] + Ct12*e22[idx] + Ct11*e33[idx];
         
        s11[idx] = S11;
        s22[idx] = S22;
        s33[idx] = S33;
    }
    
}

__global__ void Compute_sts_S(double* __restrict__ s23, double* __restrict__ s13, double* __restrict__ s12,
                            const double* __restrict__ e23, const double* __restrict__ e13, const double* __restrict__ e12,
                            const double* __restrict__ hphisum, const double* __restrict__ Chom, const double* __restrict__ Chet, 
                            int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + (nz*(j + i*ny));
    if (idx < nx_local*ny*nz)
    {
        const double temp = 2.0*hphisum[idx] - 1.0;
        
        const double Chom44 = Chom[2];

        const double Chet44 = Chet[2];
        
        const double Ct44 = Chom44 + (Chet44 * temp);
        
        const double S13 = 2.0*Ct44*e13[idx];
        const double S12 = 2.0*Ct44*e12[idx];
        const double S23 = 2.0*Ct44*e23[idx];
         
        s23[idx] = S23;
        s13[idx] = S13;
        s12[idx] = S12;
    }
    
}



__global__ void Compute_EQ_terms (double* __restrict__ S_eq, double* __restrict__ E_eq,
                                  const double* __restrict__ s11, const double* __restrict__ s22, const double* __restrict__ s33, 
                                  const double* __restrict__ s23, const double* __restrict__ s13, const double* __restrict__ s12,
                                  const double* __restrict__ e11, const double* __restrict__ e22, const double* __restrict__ e33, 
                                  const double* __restrict__ e23, const double* __restrict__ e13, const double* __restrict__ e12,
                                  int nx_local, int ny, int nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + (nz*(j + i*ny));
    if (idx < nx_local*ny*nz)
    {
        const double S11 = s11[idx];
        const double S22 = s22[idx];
        const double S33 = s33[idx];
        const double S23 = s23[idx];
        const double S13 = s13[idx];
        const double S12 = s12[idx];
        
        const double S1 = S11-S22;
        const double S2 = S22-S33;
        const double S3 = S33-S11;
        
        const double E11 = e11[idx];
        const double E22 = e22[idx];
        const double E33 = e33[idx];
        const double E23 = e23[idx];
        const double E13 = e13[idx];
        const double E12 = e12[idx];
        
        const double E1 = E11-E22;
        const double E2 = E22-E33;
        const double E3 = E33-E11;
        
        S_eq[idx] = sqrt(0.5*((S1*S1) + (S2*S2) + (S3*S3) + 6.0*((S23*S23) + (S13*S13) + (S12*S12))));
        E_eq[idx] = sqrt((2.0/3.0)* ((E1*E1) + (E2*E2) + (E3*E3) + 6.0*((E23*E23) + (E13*E13) + (E12*E12))));
    }

}


__global__ void Compute_felas(double *felas, double *felas2, double *sigappl_v_d,
                              BoxIterator<cufftDoubleComplex> str_v0_begin,
                              BoxIterator<cufftDoubleComplex> str_v0_end,
                              BoxIterator<cufftDoubleComplex> str_v1_begin,
                              BoxIterator<cufftDoubleComplex> str_v1_end,
                              BoxIterator<cufftDoubleComplex> str_v2_begin,
                              BoxIterator<cufftDoubleComplex> str_v2_end,
                              BoxIterator<cufftDoubleComplex> str_v3_begin,
                              BoxIterator<cufftDoubleComplex> str_v3_end,
                              BoxIterator<cufftDoubleComplex> str_v4_begin,
                              BoxIterator<cufftDoubleComplex> str_v4_end,
                              BoxIterator<cufftDoubleComplex> str_v5_begin,
                              BoxIterator<cufftDoubleComplex> str_v5_end,
                              double *hphisum, double *hom_strain_v,double Chom11_d,
                              double Chom12_d, double Chom44_d, double Chet11_d,
                              double Chet12_d, double Chet44_d, double epszero_d,
                              double misfit_aniso, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;
    str_v3_begin += idx; str_v4_begin += idx; str_v5_begin += idx;

    double Ct11, Ct12, Ct44;
    double e11, e22, e33, e23, e13, e12, eig11, eig22;

    if (str_v0_begin < str_v0_end)
    {
        double hsum = hphisum[idx];
        Ct11 = (Chom11_d) + (Chet11_d)*(2.0*hsum - 1.0);
        Ct12 = (Chom12_d) + (Chet12_d)*(2.0*hsum - 1.0);
        Ct44 = (Chom44_d) + (Chet44_d)*(2.0*hsum - 1.0);

        eig11 = epszero_d*hsum;
        eig22 = eig11*misfit_aniso;

        e11 = hom_strain_v[0] + str_v0_begin->x - eig11;
        e22 = hom_strain_v[1] + str_v1_begin->x - eig22;
        e33 = hom_strain_v[2] + str_v2_begin->x - eig22;
        e23 = hom_strain_v[3] + str_v3_begin->x;
        e13 = hom_strain_v[4] + str_v4_begin->x;
        e12 = hom_strain_v[5] + str_v5_begin->x;


        felas[idx] = 0.5*(Ct11*(e11*e11 + e22*e22 + e33*e33)+
                          Ct12*2.0*(e11*e22 + e11*e33 + e22*e33)+
                          Ct44*1.0*(e23*e23 + e13*e13 + e12*e12));
        
        //felas2[idx] = felas[idx]-0.5*(sigappl_v_d[0]*hom_strain_v[0]+sigappl_v_d[1]*hom_strain_v[1]+ 
        //                              sigappl_v_d[2]*hom_strain_v[2]+sigappl_v_d[3]*hom_strain_v[3]+
        //                              sigappl_v_d[4]*hom_strain_v[4]+sigappl_v_d[5]*hom_strain_v[5]);

    }
    //__syncthreads();
}

void InhomElast (cudaLibXtDesc *dfdphi0, cudaLibXtDesc *dfdphi1, 
                 cudaLibXtDesc *dfdphi2, cudaLibXtDesc *dfdphi3,
                 cudaLibXtDesc *ux, cudaLibXtDesc *uy, cudaLibXtDesc *uz,
                 cudaLibXtDesc *unewx, cudaLibXtDesc *unewy, cudaLibXtDesc *unewz,
                 cudaLibXtDesc *str_v0_d, cudaLibXtDesc *str_v1_d, cudaLibXtDesc *str_v2_d, 
                 cudaLibXtDesc *str_v3_d, cudaLibXtDesc *str_v4_d, cudaLibXtDesc *str_v5_d) 
{
    
    auto [ux_begin_r, ux_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);

    auto [ux_begin_f, ux_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);
    
    auto [uy_begin_r, uy_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);

    auto [uy_begin_f, uy_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);
    
    auto [uz_begin_r, uz_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);

    auto [uz_begin_f, uz_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);
    
    auto [dfdphi0_begin_r, dfdphi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi0->descriptor->data[0]);
    
    auto [dfdphi1_begin_r, dfdphi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi1->descriptor->data[0]);
    
    auto [dfdphi2_begin_r, dfdphi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi2->descriptor->data[0]);
    
    auto [dfdphi3_begin_r, dfdphi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi3->descriptor->data[0]);
    
    auto [str_v0_begin_r, str_v0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v0_d->descriptor->data[0]);

    auto [str_v0_begin_f, str_v0_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v0_d->descriptor->data[0]);

    auto [str_v1_begin_r, str_v1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v1_d->descriptor->data[0]);

    auto [str_v1_begin_f, str_v1_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v1_d->descriptor->data[0]);

    auto [str_v2_begin_r, str_v2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v2_d->descriptor->data[0]);

    auto [str_v2_begin_f, str_v2_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v2_d->descriptor->data[0]);
    
    auto [str_v3_begin_r, str_v3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v3_d->descriptor->data[0]);

    auto [str_v3_begin_f, str_v3_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v3_d->descriptor->data[0]);
    
    auto [str_v4_begin_r, str_v4_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v4_d->descriptor->data[0]);

    auto [str_v4_begin_f, str_v4_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v4_d->descriptor->data[0]);
    
    auto [str_v5_begin_r, str_v5_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v5_d->descriptor->data[0]);

    auto [str_v5_begin_f, str_v5_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)str_v5_d->descriptor->data[0]);


    auto [unewx_begin_r, unewx_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewx->descriptor->data[0]);

    auto [unewx_begin_f, unewx_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewx->descriptor->data[0]);

    auto [unewy_begin_r, unewy_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewy->descriptor->data[0]);

    auto [unewy_begin_f, unewy_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewy->descriptor->data[0]);
    
    auto [unewz_begin_r, unewz_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewz->descriptor->data[0]);

    auto [unewz_begin_f, unewz_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                                rank, size, nx, ny, nz,
                                                (cufftDoubleComplex*)unewz->descriptor->data[0]);

    if (count == time_elast)
    {
    
        Compute_perstr<<< Gridsize, Blocksize >>>(ux_begin_f, uy_begin_f,uz_begin_f, 
                                                  str_v0_begin_f, str_v0_end_f,
                                                  str_v1_begin_f, str_v2_begin_f, 
                                                  str_v3_begin_f, str_v4_begin_f, 
                                                  str_v5_begin_f);

        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v0_d, str_v0_d, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v1_d, str_v1_d, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v2_d, str_v2_d, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v3_d, str_v3_d, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v4_d, str_v4_d, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v5_d, str_v5_d, CUFFT_INVERSE));


        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, ux, ux, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, uy, uy, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, uz, uz, CUFFT_INVERSE));

        Normalize_6d<<< Gridsize, Blocksize >>>(str_v0_begin_r, str_v0_end_r,str_v1_begin_r, str_v2_begin_r,
                                                str_v3_begin_r, str_v4_begin_r, str_v5_begin_r);
 
        if (print_elas_vectors == 2 && OUTPUT == 1)
        {
            Print_elas_MA2(str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
                          (char*)"perstr11", (char*)"perstr22", (char*)"perstr33");
            
            Print_elas_MA2(str_v3_begin_r, str_v3_end_r, str_v4_begin_r, str_v5_begin_r,
                          (char*)"perstr23", (char*)"perstr13", (char*)"perstr12");
        }
        
        Normalize_3d<<< Gridsize, Blocksize >>>(ux_begin_r, ux_end_r,uy_begin_r, uz_begin_r, nx,ny,nz);
 
        if (print_elas_vectors == 2 && OUTPUT == 1)
            Print_elas_MA2(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,
                          (char*)"ux", (char*)"uy", (char*)"uz");
    }
    
    Compute_Ctotal<<< Gridsize, Blocksize >>>(dummy, dummy2, dummy3,
                                              hphisum, Chom11, Chet11, Chom12, Chet12, Chom44, Chet44,
                                              nx_local, ny,nz);

    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &Cavg[0], num_items);
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &Cavg[1], num_items);
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy3, &Cavg[2], num_items);
    
    ncclAllReduce(Cavg, Cavg, 3, ncclDouble, ncclSum, nccl_comm, 0);
  
    //Finding eigen stress
    if (misfit_aniso == 1.0)
    {
        Compute_eigsts_1<<<Gridsize,Blocksize>>>(dummy, hphisum, Chom11, Chom12, Chet11,
                                                Chet12, epszero, nx_local, ny, nz);
        ////No misfit_aniso so eig11 = eig22 = eig33. 
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgeigsts[0], num_items);
        ncclAllReduce(avgeigsts, avgeigsts, 1, ncclDouble, ncclSum, nccl_comm, 0);
    }
    else
    {
        Compute_eigsts_2<<<Gridsize,Blocksize>>>(dummy, dummy2, hphisum, Chom11, Chom12, Chet11,
                                                Chet12, epszero, misfit_aniso, nx_local,ny,nz);
        
        ////Since misfit_aniso is same for 22 and 33, so eigsts22 = eigsts33.
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgeigsts[0], num_items);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &avgeigsts[1], num_items);
        ncclAllReduce(avgeigsts, avgeigsts, 2, ncclDouble, ncclSum, nccl_comm, 0);
    }
   
    Compute_Sij<<<1,1>>>(Cavg, S_d, nx,ny,nz);
    
    if(print_elas_vectors == 3  && OUTPUT == 1 && count == time_elast)
    {
        memset(eigsts_h, 0.0, 3*sizeof(double));  
        memset(persts_h, 0.0, 6*sizeof(double));  
        CUDA_CHECK(cudaMemcpy(eigsts_h, S_d, 3*sizeof(double), cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(persts_h, Cavg, 3*sizeof(double), cudaMemcpyDeviceToHost));
        if (rank == 0)
        {
            printf("C11 value: %le\n", persts_h[0]);
            printf("C12 value: %le\n", persts_h[1]);
            printf("C44 value: %le\n", persts_h[2]);
            printf("S11 value: %le\n", eigsts_h[0]);
            printf("S12 value: %le\n", eigsts_h[1]);
            printf("S44 value: %le\n", eigsts_h[2]);
        }
    }
 
    Compute_persts_N<<<Gridsize,Blocksize>>>(dummy,dummy2,dummy3, str_v0_begin_r, str_v0_end_r,
                                             str_v1_begin_r, str_v1_end_r, 
                                             str_v2_begin_r, str_v2_end_r, hphisum,Chom,Chet, ny,nz);
    
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgpersts[0], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy2, &avgpersts[1], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy3, &avgpersts[2], num_items);
     
    Compute_persts_S<<<Gridsize,Blocksize>>>(dummy,dummy2,dummy3, str_v3_begin_r, str_v3_end_r, 
                                             str_v4_begin_r, str_v5_begin_r, hphisum,Chom,Chet, ny,nz);

    cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy, &avgpersts[3], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy2,&avgpersts[4], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy3,&avgpersts[5], num_items);
    
    ncclAllReduce(avgpersts, avgpersts, 6, ncclDouble, ncclSum, nccl_comm, 0);
    //CUDA_CHECK(cudaDeviceSynchronize()); 
    //Finding homogeneous strain
    ////Since misfit_aniso is same in 22 & 33,so avgeigsts22 & 33 are same here.
    
    Compute_homstr<<<1,1>>>(hom_strain_v, S_d, sigappl_v,
                            avgeigsts,avgpersts,misfit_aniso, nx,ny,nz);
    
     
    if(print_elas_vectors == 2 && OUTPUT == 1)
    {
            
        memset(eigsts_h, 0.0, 3*sizeof(double));  
        memset(persts_h, 0.0, 6*sizeof(double));  
        
        CUDA_CHECK(cudaMemcpy(eigsts_h, avgeigsts, 3*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(hom_strain_h, hom_strain_v, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
         
        if (rank == 0)
        {
            printf("Avgeigsts0 value: %le\n", eigsts_h[0]);
            printf("Avgeigsts1 value: %le\n", eigsts_h[1]);
            printf("Avgeigsts2 value: %le\n", eigsts_h[2]);
            
            printf("Avgpersts0 value: %le\n", persts_h[0]);
            printf("Avgpersts1 value: %le\n", persts_h[1]);
            printf("Avgpersts2 value: %le\n", persts_h[2]);
            printf("Avgpersts3 value: %le\n", persts_h[3]);
            printf("Avgpersts4 value: %le\n", persts_h[4]);
            printf("Avgpersts5 value: %le\n", persts_h[5]);

            printf("Homstrain0 value: %le\n", hom_strain_h[0]);
            printf("Homstrain1 value: %le\n", hom_strain_h[1]);
            printf("Homstrain2 value: %le\n", hom_strain_h[2]);
            printf("Homstrain3 value: %le\n", hom_strain_h[3]);
            printf("Homstrain4 value: %le\n", hom_strain_h[4]);
            printf("Homstrain5 value: %le\n", hom_strain_h[5]);
        }
    }
    
    
    if (norm_calc == 0)
        blas_stat = cublasCreate(&blas_handle);
        
        converge = 1;
        iter = 1;
        while (converge != FALSE)
        {
            if (print_elas_vectors == 2 && OUTPUT == 1)
            {
                if(rank == 0) 
                    printf("Elast iter: %d \n",iter);
            } 
            
            if (print_elas_vectors == 2 && OUTPUT == 1)
            {
                Print_elas_MA2(str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
                              (char*)"perstr11", (char*)"perstr22", (char*)"perstr33");
                
                Print_elas_MA2(str_v3_begin_r, str_v3_end_r, str_v4_begin_r, str_v5_begin_r, 
                              (char*)"perstr23", (char*)"perstr13", (char*)"perstr12");
            
            }

            Compute_ts<<<Gridsize, Blocksize>>>(str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r,
                                                str_v3_begin_r, str_v4_begin_r, str_v5_begin_r,
                                                hom_strain_v, hphisum, Chom, Chet, epszero, misfit_aniso);
            
            if (print_elas_vectors == 2 && OUTPUT == 1)
            {
                Print_elas_MA2(str_v0_begin_r, str_v0_end_r, str_v1_begin_r,str_v2_begin_r, 
                              (char*)"ts0", (char*)"ts1", (char*)"ts2");
                
                Print_elas_MA2(str_v3_begin_r, str_v3_end_r, str_v4_begin_r, str_v5_begin_r, 
                              (char*)"ts3", (char*)"ts3", (char*)"ts5");
                 
            }
 
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v0_d, str_v0_d, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v1_d, str_v1_d, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v2_d, str_v2_d, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v3_d, str_v3_d, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v4_d, str_v4_d, CUFFT_FORWARD));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v5_d, str_v5_d, CUFFT_FORWARD));

            //Update displacements
            // Required for bringing data to the correct format
            unewx->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
            unewy->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
            unewz->subFormat = CUFFT_XT_FORMAT_INPLACE_SHUFFLED;
            
            Update_disp<<< Gridsize,Blocksize >>>(unewx_begin_f, unewx_end_f, unewy_begin_f, 
                                                  unewz_begin_f, str_v0_begin_f, str_v1_begin_f, 
                                                  str_v2_begin_f, str_v3_begin_f, str_v4_begin_f, 
                                                  str_v5_begin_f, Chom);
 
            Compute_perstr<<< Gridsize, Blocksize >>>(unewx_begin_f,unewy_begin_f, unewz_begin_f, 
                                                      str_v0_begin_f, str_v0_end_f, str_v1_begin_f, 
                                                      str_v2_begin_f, str_v3_begin_f, str_v4_begin_f, 
                                                      str_v5_begin_f);

            //CUDA_CHECK(cudaDeviceSynchronize());

            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, unewx, unewx, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, unewy, unewy, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, unewz, unewz, CUFFT_INVERSE));

            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v0_d, str_v0_d, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v1_d, str_v1_d, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v2_d, str_v2_d, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v3_d, str_v3_d, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v4_d, str_v4_d, CUFFT_INVERSE));
            CUFFT_CHECK(cufftXtExecDescriptorZ2Z(plan, str_v5_d, str_v5_d, CUFFT_INVERSE));

            Normalize_3d<<< Gridsize, Blocksize >>>(unewx_begin_r, unewx_end_r,unewy_begin_r, unewz_begin_r, nx,ny,nz);
            
            Normalize_6d<<< Gridsize, Blocksize >>>(str_v0_begin_r, str_v0_end_r,str_v1_begin_r, str_v2_begin_r,
                                                    str_v3_begin_r, str_v4_begin_r, str_v5_begin_r);
 
            if (print_elas_vectors == 2 && OUTPUT == 1)
            {
                Print_elas_MA2(str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
                              (char*)"perstr11", (char*)"perstr22", (char*)"perstr33");
                
                Print_elas_MA2(str_v3_begin_r, str_v3_end_r, str_v4_begin_r, str_v5_begin_r, 
                              (char*)"perstr23", (char*)"perstr13", (char*)"perstr12");
            
            }
            
            Compute_persts_N<<<Gridsize,Blocksize>>>(dummy,dummy2,dummy3, str_v0_begin_r, str_v0_end_r,
                                                     str_v1_begin_r, str_v1_end_r, 
                                                     str_v2_begin_r, str_v2_end_r, hphisum,Chom,Chet, ny,nz);
            
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgpersts[0], num_items);
            cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy2, &avgpersts[1], num_items);
            cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy3, &avgpersts[2], num_items);
             
            Compute_persts_S<<<Gridsize,Blocksize>>>(dummy,dummy2,dummy3, str_v3_begin_r, str_v3_end_r, 
                                                     str_v4_begin_r, str_v5_begin_r, hphisum,Chom,Chet, ny,nz);

            cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy, &avgpersts[3], num_items);
            cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy2,&avgpersts[4], num_items);
            cub::DeviceReduce::Sum(t_storage,t_storage_bytes,dummy3,&avgpersts[5], num_items);
         
            ncclAllReduce(avgpersts, avgpersts, 6, ncclDouble, ncclSum, nccl_comm, 0);
            
            //CUDA_CHECK(cudaDeviceSynchronize()); 
            //Finding homogeneous strain
            Compute_homstr2<<<1,1>>>(hom_strain_v, S_d, sigappl_v,
                                    avgeigsts,avgpersts,misfit_aniso, nx,ny,nz);
            

            Compute_diff_disp<<<Gridsize,Blocksize>>>(unewx_begin_r, unewx_end_r, unewy_begin_r, 
                                                     unewz_begin_r, ux_begin_r, uy_begin_r, uz_begin_r, 
                                                     dummy, dummy2, dummy3, norm_calc);

            //CUDA_CHECK(cudaDeviceSynchronize());
            if (norm_calc == 0)
            {
                blas_stat = cublasDasum(blas_handle, num_items, dummy, 1, &disperror);
                if (blas_stat != CUBLAS_STATUS_SUCCESS)
                {
                    printf("Rank %d: cublas call failed !!! \n", rank);
                }
                // Sum over all ranks and distribute
                MPI_Allreduce(MPI_IN_PLACE, &disperror, 1, MPI_DOUBLE, MPI_SUM, comm);
                
                disperror = sqrt(disperror);
            }
            if (norm_calc == 1)
            {
                cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy,  &disperr[0], num_items);
                cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy2, &disperr[1], num_items);
                cub::DeviceReduce::Max(t_storage, t_storage_bytes, dummy3, &disperr[2], num_items);
                //CUDA_CHECK(cudaDeviceSynchronize());

                ncclAllReduce(disperr, disperr, 3, ncclDouble, ncclMax, nccl_comm, 0);
        
                CUDA_CHECK(cudaMemcpy(disperr_h, disperr, 3*sizeof(double), cudaMemcpyDeviceToHost));
                 
                //MPI_Allreduce(MPI_IN_PLACE, disperr, 1, MPI_DOUBLE, MPI_MAX, comm);
                //MPI_Allreduce(MPI_IN_PLACE, disperr2, 1, MPI_DOUBLE, MPI_MAX, comm);
                //MPI_Allreduce(MPI_IN_PLACE, disperr3, 1, MPI_DOUBLE, MPI_MAX, comm);

                //CUDA_CHECK(cudaDeviceSynchronize());
                
                if (disperr_h[0] < disperr_h[1] && disperr_h[0] < disperr_h[2])
                    disperror = disperr_h[0];
                
                else if (disperr_h[1] < disperr_h[0] && disperr_h[1] < disperr_h[2])
                    disperror = disperr_h[1];
                
                else
                    disperror = disperr_h[2];
            }
            if (print_elas_vectors == 1)
            {
                if (rank == 0) 
                    printf("disperror:%le\n",disperror);
            }

            if (disperror < Tol)
                converge = 0;

            iter = iter + 1;

            Copy_new_sol<<< Gridsize, Blocksize>>> (unewx_begin_r, unewx_end_r, unewy_begin_r,
                                                    unewz_begin_r, ux_begin_r, uy_begin_r, uz_begin_r);
            //CUDA_CHECK(cudaDeviceSynchronize());
            if ((print_elas_vectors == 1 || print_elas_vectors == 2) && OUTPUT == 1)
            { 
                Print_elas_MA2(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, 
                              (char*)"ux", (char*)"uy", (char*)"uz");
            }
            
            if (elast_eqm == 0 && iter > nelast)
            {
                converge = 0;
                if(rank == 0 && print_elas_vectors == 1 && OUTPUT == 1)
                    printf("Solved for nelast steps:%d\n", nelast);
            }
            
            if (elast_eqm == 1)
            {
                if (iter > nelast) 
                {
                    if (rank == 0)
                        printf("====> $$ Unable to converge till nelast steps and exiting $$ <====\n");
                    MPI_Abort(comm, 1);
                }
            }

        }
    if ((print_conv_iter == 1) && (rank == 0))
        printf("Converged at iteration no. = %d \n",iter);

    if ((print_conv_iter == 2) && (rank == 0) && (OUTPUT == 1))
        printf("Converged at iteration no. = %d \n",iter);
            
    if(print_elas_vectors == 2 && OUTPUT == 1)
    {
            
        memset(eigsts_h, 0.0, 3*sizeof(double));  
        memset(persts_h, 0.0, 6*sizeof(double));  
         
        Print_elas_MA2(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, (char*)"ux", (char*)"uy", (char*)"uz");
        
        CUDA_CHECK(cudaMemcpy(eigsts_h, avgeigsts, 3*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(hom_strain_h, hom_strain_v, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
         
        if (rank == 0)
        {
            printf("Avgeigsts0 value: %le\n", eigsts_h[0]);
            printf("Avgeigsts1 value: %le\n", eigsts_h[1]);
            printf("Avgeigsts2 value: %le\n", eigsts_h[2]);
            
            printf("Avgpersts0 value: %le\n", persts_h[0]);
            printf("Avgpersts1 value: %le\n", persts_h[1]);
            printf("Avgpersts2 value: %le\n", persts_h[2]);
            printf("Avgpersts3 value: %le\n", persts_h[3]);
            printf("Avgpersts4 value: %le\n", persts_h[4]);
            printf("Avgpersts5 value: %le\n", persts_h[5]);

            printf("Homstrain0 value: %le\n", hom_strain_h[0]);
            printf("Homstrain1 value: %le\n", hom_strain_h[1]);
            printf("Homstrain2 value: %le\n", hom_strain_h[2]);
            printf("Homstrain3 value: %le\n", hom_strain_h[3]);
            printf("Homstrain4 value: %le\n", hom_strain_h[4]);
            printf("Homstrain5 value: %le\n", hom_strain_h[5]);
        }
    }
    
    if (TRACK_OBS == 1 || (engs_out != 0 && OUTPUT == 1))
        CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
    
    ////NOTE:dummy2 is reused for felas out.
    if (nof_variants == 1)
    {
        Compute_dfeldphi_inhomsv<<< Gridsize, Blocksize >>>(dfdphi0_begin_r, dfdphi0_end_r,
                                                            str_v0_begin_r, str_v1_begin_r, 
                                                            str_v2_begin_r, str_v3_begin_r, 
                                                            str_v4_begin_r, str_v5_begin_r, 
                                                            dummy2, hphisum, dhdphi0, hom_strain_v,
                                                            Chom11, Chom12, Chom44,
                                                            Chet11, Chet12, Chet44,
                                                            epszero, misfit_aniso, engs_out, OUTPUT, 
                                                            TRACK_OBS, nx_local, ny, nz);
    }
    
    if (nof_variants == 4)
    { 
        Compute_dfeldphi_inhom<<< Gridsize, Blocksize >>>(dfdphi0_begin_r, dfdphi0_end_r,
                                                            dfdphi1_begin_r, dfdphi2_begin_r,
                                                            dfdphi3_begin_r,
                                                            str_v0_begin_r, str_v1_begin_r, 
                                                            str_v2_begin_r, str_v3_begin_r, 
                                                            str_v4_begin_r, str_v5_begin_r, 
                                                            dummy2, hphisum, dhdphi0, dhdphi1, dhdphi2,
                                                            dhdphi3, hom_strain_v,
                                                            Chom11, Chom12, Chom44,
                                                            Chet11, Chet12, Chet44,
                                                            epszero, misfit_aniso,engs_out, OUTPUT, TRACK_OBS, nx_local, ny, nz);
    }
    
    if (engs_out == 1 && OUTPUT == 1)
        CUDA_CHECK(cudaMemcpy(felas_h, dummy, double_size, cudaMemcpyDeviceToHost)); 
    
    if ( TRACK_OBS == 1 || (stress_strain_out != 0 && OUTPUT ==1))
    {
        //Compute_str_sts<<< Gridsize, Blocksize >>>(e11, e22, e33, s11, s22, s33,
        //                                       str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
        //                                        hphisum, Chom, Chet, hom_strain_v, epszero, misfit_aniso, ny,nz); 
        //
        //Compute_str_sts2<<< Gridsize, Blocksize >>>(e23, e13, e12, s23, s13, s12,
        //                                       str_v3_begin_r, str_v4_begin_r, str_v5_begin_r, str_v5_end_r,
        //                                        hphisum, Chom, Chet, hom_strain_v, ny,nz); 
        
        //Compute_str<<< Gridsize, Blocksize >>>(e11, e22, e33, e23, e13, e12,e_eq,
        //                                       str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
        //                                       str_v3_begin_r, str_v4_begin_r, str_v5_begin_r, hphisum, hom_strain_v,
        //                                       epszero, misfit_aniso, ny,nz); 
        
        ////NOTE:Reusing the pointers here.
        Compute_str<<< Gridsize, Blocksize >>>(dummy3, dummy4, dummy5, dhdphi0, dhdphi1, dhdphi2, dhdphi3,
                                               str_v0_begin_r, str_v0_end_r, str_v1_begin_r, str_v2_begin_r, 
                                               str_v3_begin_r, str_v4_begin_r, str_v5_begin_r, hphisum, hom_strain_v,
                                               epszero, misfit_aniso, ny,nz);
        
        if (stress_strain_out == 1 && OUTPUT == 1)
        {
            CUDA_CHECK(cudaMemcpy(e11_h, dummy3, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e22_h, dummy4, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e33_h, dummy5, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e23_h, dhdphi0, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e13_h, dhdphi1, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e12_h, dhdphi2, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(e_eq_h,dhdphi3, double_size, cudaMemcpyDeviceToHost));

        }
        /*
        if (print_elas_vectors == 3 && OUTPUT == 1)
        {    
            Print_elas_MA(str_v3_begin_r, str_v3_end_r, str_v4_begin_r, str_v5_begin_r, (char*)"perstr3", (char*)"perstr4", 
                            (char*)"perstr5");
            
            CUDA_CHECK(cudaMemset(avgpersts, 0.0, 6*sizeof(*Vf)));
            memset(persts_h, 0.0, 6*sizeof(double));  
            
            Print_MAD(t_storage_bytes, t_storage, e23, Vf, num_items, sizescale, (char*)"e23");  
            Print_MAD(t_storage_bytes, t_storage, e13, Vf, num_items, sizescale, (char*)"e13");  
            Print_MAD(t_storage_bytes, t_storage, e12, Vf, num_items, sizescale, (char*)"e12");  
            
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e11, &avgpersts[0], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e22, &avgpersts[1], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e33, &avgpersts[2], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e23, &avgpersts[3], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e13, &avgpersts[4], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, e12, &avgpersts[5], num_items);
            
            ncclAllReduce(avgpersts, avgpersts, 6, ncclDouble, ncclSum, nccl_comm, 0);
        
            CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
            //CUDA_CHECK(cudaDeviceSynchronize()); 
            
            if (rank == 0)
            {
                persts_h[0] *= sizescale;
                persts_h[1] *= sizescale;
                persts_h[2] *= sizescale;
                persts_h[3] *= sizescale;
                persts_h[4] *= sizescale;
                persts_h[5] *= sizescale;
                
                printf("E11 avg value is:%le\n", persts_h[0]);
                printf("E22 avg value is:%le\n", persts_h[1]);
                printf("E33 avg value is:%le\n", persts_h[2]);
                printf("E23 avg value is:%le\n", persts_h[3]);
                printf("E13 avg value is:%le\n", persts_h[4]);
                printf("E12 avg value is:%le\n", persts_h[5]);
            }
            MPI_Barrier(comm);
        }*/
        
        //Compute_sts<<< Gridsize, Blocksize >>>(s11, s22, s33, s23, s13, s12, s_eq, e11, e22, e33, e23, e13, e12,
        //                                       hphisum, Chom, Chet, nx_local,ny,nz);
        
        ////NOTE:Reusing the pointers here.
        Compute_sts2<<< Gridsize, Blocksize >>>(dummy3, dummy4, dummy5, dhdphi0, dhdphi1, dhdphi2, dhdphi3, 
                                               hphisum, Chom, Chet, nx_local,ny,nz);
        
        if (stress_strain_out == 1 && OUTPUT == 1)
        {
            CUDA_CHECK(cudaMemcpy(s11_h, dummy3, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s22_h, dummy4, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s33_h, dummy5, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s23_h, dhdphi0, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s13_h, dhdphi1, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s12_h, dhdphi2, double_size, cudaMemcpyDeviceToHost));
            CUDA_CHECK(cudaMemcpy(s_eq_h,dhdphi3, double_size, cudaMemcpyDeviceToHost));
        }
        
        
        //Compute_sts_N<<< Gridsize, Blocksize >>>(s11, s22, s33, e11, e22, e33, hphisum, Chom, Chet, nx_local,ny,nz);
        //
        //Compute_sts_S<<< Gridsize, Blocksize >>>(s23, s13, s12, e23, e13, e12, hphisum, Chom, Chet, nx_local,ny,nz);

        //Compute_EQ_terms<<<Gridsize, Blocksize>>>(s_eq, e_eq, s11,s22,s33,s23,s13,s12, e11,e22,e33,e23,e13,e12, nx_local,ny,nz);
              
        if (TRACK_OBS == 1) 
        {
            //Print_MAD(t_storage_bytes, t_storage, s23, Vf, num_items, sizescale, (char*)"s23");  
            //Print_MAD(t_storage_bytes, t_storage, s13, Vf, num_items, sizescale, (char*)"s13");  
            //Print_MAD(t_storage_bytes, t_storage, s12, Vf, num_items, sizescale, (char*)"s12");  
            
            memset(persts_h, 0.0, 6*sizeof(double));  
            CUDA_CHECK(cudaMemset(avgpersts, 0.0, 6*sizeof(*Vf)));
            
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy3, &avgpersts[0], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy4, &avgpersts[1], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy5, &avgpersts[2], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dhdphi0, &avgpersts[3], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dhdphi1, &avgpersts[4], num_items);
            cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dhdphi2, &avgpersts[5], num_items);
            //CUDA_CHECK(cudaDeviceSynchronize()); 
            
            ncclAllReduce(avgpersts, avgpersts, 6, ncclDouble, ncclSum, nccl_comm, 0);
        
            CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
            //CUDA_CHECK(cudaDeviceSynchronize()); 
            
            if (rank == 0)
            {
                persts_h[0] *= sizescale;
                persts_h[1] *= sizescale;
                persts_h[2] *= sizescale;
                persts_h[3] *= sizescale;
                persts_h[4] *= sizescale;
                persts_h[5] *= sizescale;
                if (print_elas_vectors == 3)
                { 
                    printf("S11 avg value is:%le\n", persts_h[0]);
                    printf("S22 avg value is:%le\n", persts_h[1]);
                    printf("S33 avg value is:%le\n", persts_h[2]);
                    printf("S23 avg value is:%le\n", persts_h[3]);
                    printf("S13 avg value is:%le\n", persts_h[4]);
                    printf("S12 avg value is:%le\n", persts_h[5]);
                }
            }
            MPI_Barrier(comm);
        } 
    }

    if (norm_calc == 0)
        cublasDestroy(blas_handle);
}
