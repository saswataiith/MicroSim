//#include "binary.h"
//#include "calc_uzero.cu"

__global__ void Move_perstr(double* __restrict__ perstr11, double* __restrict__ perstr22,
                            double* __restrict__ perstr33,
                              BoxIterator<cufftDoubleComplex> ux_begin,
                              BoxIterator<cufftDoubleComplex> ux_end,
                              BoxIterator<cufftDoubleComplex> uy_begin,
                              BoxIterator<cufftDoubleComplex> uz_begin, int ny, int nz)
{
    int i = threadIdx.x + blockDim.x*blockIdx.x;
    int j = threadIdx.y + blockDim.y*blockIdx.y;
    int k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    ux_begin += idx; uy_begin += idx, uz_begin += idx;
    
    if (ux_begin < ux_end)
    {
        perstr11[idx] = ux_begin->x;
        perstr22[idx] = uy_begin->x;
        perstr33[idx] = uz_begin->x;
    }

}

__global__ void Compute_uzero4(BoxIterator<cufftDoubleComplex> ux_begin,
                              BoxIterator<cufftDoubleComplex> ux_end,
                              BoxIterator<cufftDoubleComplex> uy_begin,
                              BoxIterator<cufftDoubleComplex> uz_begin,
                              BoxIterator<cufftDoubleComplex> str0_begin,
                              BoxIterator<cufftDoubleComplex> str1_begin,
                              BoxIterator<cufftDoubleComplex> str2_begin,
                              const double* __restrict__ Chom, int ny, int nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockIdx.z*blockDim.z;

    long idx = k + (nz*(j + i*ny));

    ux_begin += idx; uy_begin += idx, uz_begin += idx;
    str0_begin += idx; str1_begin += idx, str2_begin += idx;
    double n[3] = {0.0}; 
    double omega[6] = {0.0};

    if (ux_begin < ux_end)
    {
        get_kx_ky_kz(&n[0], &n[1], &n[2], ux_begin);
        get_omega(omega, n, Chom);
      
        const cufftDoubleComplex fk11 = {(ux_begin->x * n[0]), (ux_begin->y * n[0])};
        const cufftDoubleComplex fk22 = {(uy_begin->x * n[1]), (uy_begin->y * n[1])};
        const cufftDoubleComplex fk33 = {(uz_begin->x * n[2]), (uz_begin->y * n[2])};

        *str0_begin = { (omega[0]*fk11.y + omega[5]*fk22.y + omega[4]*fk33.y), 
                      -1.0*(omega[0]*fk11.x + omega[5]*fk22.x + omega[4]*fk33.x) };
        
        *str1_begin = { (omega[5]*fk11.y + omega[1]*fk22.y + omega[3]*fk33.y), 
                      -1.0*(omega[5]*fk11.x + omega[1]*fk22.x + omega[3]*fk33.x) };

        *str2_begin = { (omega[4]*fk11.y + omega[3]*fk22.y + omega[2]*fk33.y), 
                      -1.0*(omega[4]*fk11.x + omega[3]*fk22.x + omega[2]*fk33.x) };

        
    }
    //__syncthreads();

}
__global__ void Compute_eigsts_1hom(double* __restrict__ eigsts, const double* hphisum, 
                                    const double* __restrict__ Chom,
                                    const double epszero_d, int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    if (idx >= nx_local*ny*nz)
        return;
    
    const double eig11 = epszero_d * hphisum[idx];
    
    eigsts[idx] = (eig11*(Chom[0] + 2.0 * Chom[1]));
}

__global__ void Compute_eigsts_2hom(double* __restrict__ eigsts11, double* __restrict__ eigsts22,
                                    const double* __restrict__ hphisum, 
                                    const double* __restrict__ Chom, const double epszero_d,
                                    const double misfit_aniso,int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);
    if (idx >= nx_local*ny*nz)
        return;
     
    const double eig11 = epszero_d * hphisum[idx];
     
    //If misit_aniso is diff in Y,Z we have to take another misfit_aniso.
    const double Chom11 = Chom[0];
    const double Chom12 = Chom[1];
    const double mfit_aniso = misfit_aniso;

    eigsts11[idx] = (eig11*(Chom11 + 2.0 * Chom12*mfit_aniso)); 
    eigsts22[idx] = (eig11*(Chom12 + mfit_aniso*(Chom11 + Chom12)));

}

__global__ void Compute_persts_hom(double* __restrict__ persts11, double* __restrict__ persts22, 
                                   double* __restrict__ persts33,
                                   BoxIterator<cufftDoubleComplex> str_v0_begin,
                                   BoxIterator<cufftDoubleComplex> str_v0_end,
                                   BoxIterator<cufftDoubleComplex> str_v1_begin,
                                   BoxIterator<cufftDoubleComplex> str_v2_begin,
                                   const double* __restrict__ Chom, int ny, int nz)


{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    
    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        
        const double Ct11 = Chom[0];
        const double Ct12 = Chom[1]; 

        persts11[idx] = (fma(Ct11, (str_v0_begin->x), Ct12*((str_v1_begin->x)+(str_v2_begin->x))));
        persts22[idx] = (fma(Ct11, (str_v1_begin->x), Ct12*((str_v0_begin->x)+(str_v2_begin->x))));
        persts33[idx] = (fma(Ct11, (str_v2_begin->x), Ct12*((str_v0_begin->x)+(str_v1_begin->x))));

    }
    //__syncthreads();
}

/*
__global__ void Compute_persts0_hom(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double Chom11,
                                double Chom12, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        
        //persts[idx] = (Ct11*(str_v0_begin->x) + Ct12*(str_v1_begin->x) + Ct12*(str_v2_begin->x));
        persts[idx] = fma(Chom11, (str_v0_begin->x), Chom12*((str_v1_begin->x)+(str_v2_begin->x)));

    }
    __syncthreads();
}

__global__ void Compute_persts1_hom(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double Chom11, double Chom12, 
                                long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {

        persts[idx] = fma(Chom11, (str_v1_begin->x), Chom12*((str_v0_begin->x)+(str_v2_begin->x)));

    }
    __syncthreads();
}

__global__ void Compute_persts2_hom(double *persts,
                                BoxIterator<cufftDoubleComplex> str_v0_begin,
                                BoxIterator<cufftDoubleComplex> str_v0_end,
                                BoxIterator<cufftDoubleComplex> str_v1_begin,
                                BoxIterator<cufftDoubleComplex> str_v1_end,
                                BoxIterator<cufftDoubleComplex> str_v2_begin,
                                BoxIterator<cufftDoubleComplex> str_v2_end,
                                double Chom11, double Chom12, 
                                long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + nz*(j + i*ny);

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {

        persts[idx] = fma(Chom11, (str_v2_begin->x), Chom12*((str_v0_begin->x)+(str_v1_begin->x)));

    }
    __syncthreads();
}

*/

__global__ void Compute_homstr_hom(double* __restrict__ hom_strain_v, const double S11, const double S12,
                                   const double* __restrict__ sigappl, double* __restrict__ avgeigsts,
                                   double* __restrict__ avgpersts, int misfit_aniso, int nx, int ny, int nz)
{
    double sizescale = 1.0/((double)(nx*ny*nz));

    if (misfit_aniso == 1)
    {
        avgeigsts[0] *= sizescale;
        avgeigsts[1] = avgeigsts[0];
        avgeigsts[2] = avgeigsts[0];
    }
    else
    {
        avgeigsts[0] *= sizescale;
        avgeigsts[1] *= sizescale;
        avgeigsts[2] = avgeigsts[1];
    }

    avgpersts[0] *= sizescale;
    avgpersts[1] *= sizescale;
    avgpersts[2] *= sizescale;
    
    const double ts0 = sigappl[0] + avgeigsts[0] - avgpersts[0];
    const double ts1 = sigappl[1] + avgeigsts[1] - avgpersts[1];
    const double ts2 = sigappl[2] + avgeigsts[2] - avgpersts[2];
    
    hom_strain_v[0] = (S11 * ts0) + (S12 * ts1) + (S12 * ts2);
    hom_strain_v[1] = (S12 * ts0) + (S11 * ts1) + (S12 * ts2);
    hom_strain_v[2] = (S12 * ts0) + (S12 * ts1) + (S11 * ts2);
}

__global__ void Compute_homstr_hom2(double* __restrict__ hom_strain_v, 
                                    const double S11_d, const double S12_d,
                                    const double* __restrict__ avgeigsts0,
                                    const double* __restrict__ avgeigsts1,
                                    const double* __restrict__ avgeigsts2)
{ 
    const double S11  = S11_d;
    //const double S12  = S12_d;
    
    hom_strain_v[0] = S11*(*avgeigsts0);
    hom_strain_v[1] = S11*(*avgeigsts1);
    hom_strain_v[2] = S11*(*avgeigsts2);
}

////Peridoic strains are stored in ux pointers and they already have disp values and spo reused. 
__global__ void Compute_perstr_hom(BoxIterator<cufftDoubleComplex> ux_begin,
                                   BoxIterator<cufftDoubleComplex> ux_end,
                                   BoxIterator<cufftDoubleComplex> uy_begin,
                                   BoxIterator<cufftDoubleComplex> uz_begin)
{


    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    double  nk[3];
    const int nz = nz_d;
    const int ny = ny_d;
    long idx = k + nz*(j + i*ny);

    ux_begin += idx; uy_begin += idx; uz_begin += idx;
    if (ux_begin < ux_end)
    {
        get_kx_ky_kz(&nk[0], &nk[1], &nk[2], ux_begin);

        cufftDoubleComplex xdisp = *ux_begin; 
        cufftDoubleComplex ydisp = *uy_begin; 
        cufftDoubleComplex zdisp = *uz_begin; 

        *ux_begin = {(-1.0*xdisp.y * nk[0]), (xdisp.x * nk[0])};
        *uy_begin = {(-1.0*ydisp.y * nk[1]), (ydisp.x * nk[1])};
        *uz_begin = {(-1.0*zdisp.y * nk[2]), (zdisp.x * nk[2])};

    }
    //__syncthreads();

}
/*
__global__ void Compute_eigstr1(double *eigstr11,double epszero, double *hphisum,
                                   long nx, long ny, long nz)

{
    int i = threadIdx.x + blockDim.x*blockIdx.x;
    int j = threadIdx.y + blockDim.y*blockIdx.y;
    int k = threadIdx.z + blockDim.z*blockIdx.z;
    int idx = k + nz*(j + i*ny);
    if (idx <nx*ny*nz)
    {
        eigstr11[idx] = epszero*hphisum[idx];
    }
   // __syncthreads();
}

__global__ void Compute_eigstr2(double *eigstr11,double epszero, double *hphisum,
                                double misfit_aniso, long nx, long ny, long nz)

{
    int i = threadIdx.x + blockDim.x*blockIdx.x;
    int j = threadIdx.y + blockDim.y*blockIdx.y;
    int k = threadIdx.z + blockDim.z*blockIdx.z;
    int idx = k + nz*(j + i*ny);
    if (idx <nx*ny*nz)
    {
        eigstr11[idx] = epszero*misfit_aniso*hphisum[idx];
    }
   // __syncthreads();
}
*/
__global__ void Compute_dfeldphi_sv(BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                                 BoxIterator<cufftDoubleComplex> dfdphi0_end,
                                 BoxIterator<cufftDoubleComplex> str_v0_begin,
                                 BoxIterator<cufftDoubleComplex> str_v1_begin,
                                 BoxIterator<cufftDoubleComplex> str_v2_begin,
                                 double* __restrict__ felas,
                                 const double* __restrict__ hphisum, const double* __restrict__ dhdphi, 
                                 const double* __restrict__ hom_strain,
                                 const double* __restrict__ Chom, double epszero_d, double misfit_aniso, int engs_out, 
                                 int output, int TRACK_OBS, int ny, int nz)
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));
    
    dfdphi0_begin += idx;
    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (dfdphi0_begin >= dfdphi0_end)
        return;
    
    const double tmp = dfdphi0_begin->x;
    const double hphi = hphisum[idx];
    const double eig11 = epszero_d;
    const double eig22 = eig11 * misfit_aniso;

    const double e11 = hom_strain[0] + str_v0_begin->x - eig11*hphi;
    const double e22 = hom_strain[1] + str_v1_begin->x - eig22*hphi;
    const double e33 = hom_strain[2] + str_v2_begin->x - eig22*hphi; 
    ////eig33 since misfit_aniso is same so using eig22.

    const double Chom11_d = Chom[0];
    const double Chom12_d = Chom[1];
     
    *dfdphi0_begin = {(tmp + (-1.0*dhdphi[idx]*(Chom11_d*(e11*eig11 + e22*eig22 + e33*eig22) +
                                             Chom12_d*(e11*eig22 + e22*eig11 + e11*eig22 +
                                                       e33*eig11 + e22*eig22 + e33*eig22)))), 0.0};

    if(TRACK_OBS == 1 || (engs_out == 1 && output == 1))
    {
        felas[idx] = 0.5*(Chom11_d*(e11*e11 + e22*e22 + e33*e33) +
                          2.0*Chom12_d*(e11*e22 + e22*e33 + e33*e11));
    }

}

__global__ void Compute_dfeldphi_hom(BoxIterator<cufftDoubleComplex> dfdphi0_begin,
                                     BoxIterator<cufftDoubleComplex> dfdphi0_end,
                                     BoxIterator<cufftDoubleComplex> dfdphi1_begin,
                                     BoxIterator<cufftDoubleComplex> dfdphi2_begin,
                                     BoxIterator<cufftDoubleComplex> dfdphi3_begin,
                                     BoxIterator<cufftDoubleComplex> str_v0_begin,
                                     BoxIterator<cufftDoubleComplex> str_v1_begin,
                                     BoxIterator<cufftDoubleComplex> str_v2_begin,
                                     double* __restrict__ felas, 
                                     const double* __restrict__ hphisum, 
                                     const double* __restrict__ dhdphi0, 
                                     const double* __restrict__ dhdphi1, 
                                     const double* __restrict__ dhdphi2, 
                                     const double* __restrict__ dhdphi3, 
                                     const double* __restrict__ hom_strain, 
                                     const double* __restrict__ Chom, double epszero_d, double misfit_aniso,
                                     int engs_out, int output, int TRACK_OBS, int ny, int nz) 
{

    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));
    
    dfdphi0_begin += idx; dfdphi1_begin += idx;
    dfdphi2_begin += idx; dfdphi3_begin += idx;
    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (dfdphi0_begin < dfdphi0_end)
    { 
        const double Chom11_d = Chom[0];
        const double Chom12_d = Chom[1];
        const double tmp0 = dfdphi0_begin->x;
        const double tmp1 = dfdphi1_begin->x;
        const double tmp2 = dfdphi2_begin->x;
        const double tmp3 = dfdphi3_begin->x;

        const double hsum = hphisum[idx];
        const double eig11 = epszero_d;
        const double eig22 = eig11 * misfit_aniso;

        const double e11 = hom_strain[0] + str_v0_begin->x - eig11*hsum;
        const double e22 = hom_strain[1] + str_v1_begin->x - eig22*hsum;
        const double e33 = hom_strain[2] + str_v2_begin->x - eig22*hsum; 
        ////eig33 since misfit_aniso is same so using eig22.
        const double dfel = (Chom11_d*(e11*eig11 + e22*eig22 + e33*eig22) +
                             Chom12_d*(e11*eig22 + e22*eig11 + e11*eig22 +
                                       e33*eig11 + e22*eig22 + e33*eig22));
         
        *dfdphi0_begin = {(tmp0 + (-1.0*dhdphi0[idx]*dfel)), 0.0};
        *dfdphi1_begin = {(tmp1 + (-1.0*dhdphi1[idx]*dfel)), 0.0};
        *dfdphi2_begin = {(tmp2 + (-1.0*dhdphi2[idx]*dfel)), 0.0};
        *dfdphi3_begin = {(tmp3 + (-1.0*dhdphi3[idx]*dfel)), 0.0};
    
        if(TRACK_OBS == 1 || (engs_out == 1 && output == 1))
        {
            felas[idx] = 0.5*(Chom11_d*(e11*e11 + e22*e22 + e33*e33) +
                              2.0*Chom12_d*(e11*e22 + e22*e33 + e33*e11));
        }
    }
   // __syncthreads();
}
__global__ void Compute_str_sts_hom(double* __restrict__ dummy1, double* __restrict__ dummy2, double* __restrict__ dummy3, 
                                double* __restrict__ s11, double* __restrict__ s22, double* __restrict__ s33, 
                                const double* __restrict__ hphisum, const double* __restrict__ Chom,
                                double *hom_strain_v, double epszero_d, double misfit_aniso, 
                                int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));


    if (idx < nx_local*ny*nz)
    {
        const double Ct11 = Chom[0];
        const double Ct12 = Chom[1];
 
        const double eig11 = epszero_d*hphisum[idx];
        const double eig22 = eig11*misfit_aniso;
        
        const double homstrain0 = hom_strain_v[0];
        const double homstrain1 = hom_strain_v[1];
        const double homstrain2 = hom_strain_v[2];

        const double E11 = homstrain0 + dummy1[idx] - eig11;
        const double E22 = homstrain1 + dummy2[idx] - eig22;
        const double E33 = homstrain2 + dummy3[idx] - eig22; ////eig33 since misfit_aniso is same so using eig22.
        
        const double S11 = Ct11*E11 + Ct12*E22 + Ct12*E33;
        const double S22 = Ct12*E11 + Ct11*E22 + Ct12*E33;
        const double S33 = Ct12*E11 + Ct12*E22 + Ct11*E33;
     
        dummy1[idx] = E11;
        dummy2[idx] = E22;
        dummy3[idx] = E33;
        
        s11[idx] = S11;
        s22[idx] = S22;
        s33[idx] = S33;
    }
}


__global__ void Compute_sts_hom(double* __restrict__ dummy1, double* __restrict__ dummy2, double* __restrict__ dummy3, 
                                const double* __restrict__ hphisum, 
                                const double* __restrict__ Chom, double *hom_strain_v, 
                                double epszero_d, double misfit_aniso, int nx_local, int ny, int nz) 
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;
    long idx = k + (nz*(j + i*ny));

    if (idx < nx_local*ny*nz)
    { 
        const double Ct11 = Chom[0];
        const double Ct12 = Chom[1]; 
        
        const double eig11 = epszero_d*hphisum[idx];
        const double eig22 = eig11*misfit_aniso;
        
        const double homstrain0 = hom_strain_v[0];
        const double homstrain1 = hom_strain_v[1];
        const double homstrain2 = hom_strain_v[2];
        
        const double E11 = homstrain0 + dummy1[idx] - eig11;
        const double E22 = homstrain1 + dummy2[idx] - eig22;
        const double E33 = homstrain2 + dummy3[idx] - eig22; ////eig33 since misfit_aniso is same so using eig22.

        dummy1[idx] = Ct11*E11 + Ct12*E22 + Ct12*E33;   ////S11
        dummy2[idx] = Ct12*E11 + Ct11*E22 + Ct12*E33;   ////S22
        dummy3[idx] = Ct12*E11 + Ct12*E22 + Ct11*E33;   ////S33
         
    }
}

__global__ void Compute_str(double *e11, double *e22, double *e33, 
                            BoxIterator<cufftDoubleComplex> str_v0_begin,
                            BoxIterator<cufftDoubleComplex> str_v0_end,
                            BoxIterator<cufftDoubleComplex> str_v1_begin,
                            BoxIterator<cufftDoubleComplex> str_v1_end,
                            BoxIterator<cufftDoubleComplex> str_v2_begin,
                            BoxIterator<cufftDoubleComplex> str_v2_end,
                            double *hphisum, double *hom_strain,
                            double epszero_d,
                            double misfit_aniso, long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));

    str_v0_begin += idx; str_v1_begin += idx; str_v2_begin += idx;

    if (str_v0_begin < str_v0_end)
    {
        double eig11 = epszero_d*hphisum[idx];
        double eig22 = eig11*misfit_aniso;

        e11[idx] = hom_strain[0] + str_v0_begin->x - eig11;
        e22[idx] = hom_strain[1] + str_v1_begin->x - eig22;
        e33[idx] = hom_strain[2] + str_v2_begin->x - eig22; ////eig33 since misfit_aniso is same so using eig22.
       
    }
    //__syncthreads();
}

__global__ void Compute_sts(double *s11, double *s22, double *s33, 
                            double *e11, double *e22, double *e33, 
                            double Chom11_d, double Chom12_d,
                            long nx, long ny, long nz)
{
    long i = threadIdx.x + blockDim.x*blockIdx.x;
    long j = threadIdx.y + blockDim.y*blockIdx.y;
    long k = threadIdx.z + blockDim.z*blockIdx.z;

    long idx = k + (nz*(j + i*ny));
    if (idx < nx*ny*nz)
    {
        double Ct11 = Chom11_d; 
        double Ct12 = Chom12_d;
        
        s11[idx] = Ct11*e11[idx] + Ct12*e22[idx] + Ct12*e33[idx];
        s22[idx] = Ct12*e11[idx] + Ct11*e22[idx] + Ct12*e33[idx];
        s33[idx] = Ct12*e11[idx] + Ct12*e22[idx] + Ct11*e33[idx];
    }
    
    //__syncthreads();
}


void HomElast(cudaLibXtDesc *ux, cudaLibXtDesc *uy, cudaLibXtDesc *uz,
              cudaLibXtDesc *dfdphi0, cudaLibXtDesc *dfdphi1,
              cudaLibXtDesc *dfdphi2, cudaLibXtDesc *dfdphi3)
{
    
    auto [ux_begin_r, ux_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);

    auto [ux_begin_f, ux_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)ux->descriptor->data[0]);
    
    auto [uy_begin_r, uy_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);

    auto [uy_begin_f, uy_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uy->descriptor->data[0]);
    
    auto [uz_begin_r, uz_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);

    auto [uz_begin_f, uz_end_f] = BoxIterators(CUFFT_XT_FORMAT_INPLACE_SHUFFLED, CUFFT_Z2Z,
                                        rank, size, nx, ny, nz, 
                                        (cufftDoubleComplex*)uz->descriptor->data[0]);
    
    auto [dfdphi0_begin_r, dfdphi0_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi0->descriptor->data[0]);

    auto [dfdphi1_begin_r, dfdphi1_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi1->descriptor->data[0]);

    auto [dfdphi2_begin_r, dfdphi2_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, 
                                            CUFFT_Z2Z, rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi2->descriptor->data[0]);

    auto [dfdphi3_begin_r, dfdphi3_end_r] = BoxIterators(CUFFT_XT_FORMAT_INPLACE, CUFFT_Z2Z,
                                            rank, size, nx, ny, nz, 
                                            (cufftDoubleComplex*)dfdphi3->descriptor->data[0]);

    double S11, S12;
    
    S11 = ((Chom11)+(Chom12))/((Chom11)*(Chom11) + (Chom11)*(Chom12) - 2.0*(Chom12)*(Chom12));
    S12 = (-1.0*(Chom12))/((Chom11)*(Chom11) + (Chom11)*(Chom12) - 2.0*(Chom12)*(Chom12));
    //S44 = 1.0/(Chom44);
    
    if(misfit_aniso == 1.0)
    {
        Compute_eigsts_1hom<<<Gridsize,Blocksize>>>(dummy, hphisum, Chom, epszero, nx_local,ny,nz); 
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgeigsts[0], num_items);
        if (nccl_int == 0)
        {
            CUDA_CHECK(cudaStreamSynchronize(0));
            MPI_Allreduce(MPI_IN_PLACE, avgeigsts, 1, MPI_DOUBLE, MPI_SUM, comm);
        }
        else
            ncclAllReduce(avgeigsts, avgeigsts, 1, ncclDouble, ncclSum, nccl_comm, 0);
    }
    else
    {
        Compute_eigsts_2hom<<<Gridsize,Blocksize>>>(dummy, dummy2, hphisum, Chom, epszero, misfit_aniso, nx_local,ny,nz);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgeigsts[0], num_items);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy2, &avgeigsts[1], num_items);
        if (nccl_int == 0)
        {
            CUDA_CHECK(cudaStreamSynchronize(0));
            MPI_Allreduce(MPI_IN_PLACE, avgeigsts, 2, MPI_DOUBLE, MPI_SUM, comm); 
        }
        else
        {
            ncclAllReduce(avgeigsts, avgeigsts, 2, ncclDouble, ncclSum, nccl_comm, 0);
        }
    }
     
    Compute_eigsts_hom<<<Gridsize,Blocksize>>>(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, 
                                               hphisum, Chom, epszero,misfit_aniso); 
    
    if(print_elas_vectors == 3 && OUTPUT == 1)
        Print_elas_MA(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,(char*)"eigsts11", (char*)"eigsts22", 
                        (char*)"eigsts33");
     
    CUFFT_CHECK(cufftXtExecDescriptor(plan, ux,ux, CUFFT_FORWARD));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uy,uy, CUFFT_FORWARD));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uz,uz, CUFFT_FORWARD));
    
    Compute_uzero3<<<Gridsize,Blocksize>>>(ux_begin_f, ux_end_f, uy_begin_f, 
                                           uz_begin_f, Chom); 

    if(print_elas_vectors == 3 && OUTPUT == 1)
    {
        CUFFT_CHECK(cufftXtExecDescriptor(plan, ux,ux, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uy,uy, CUFFT_INVERSE));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uz,uz, CUFFT_INVERSE));
        
        Normalize_3d<<< Gridsize, Blocksize >>>(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, nx,ny,nz);
        
        Print_elas_MA(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,(char*)"ux", (char*)"uy", (char*)"uz");
        
        CUFFT_CHECK(cufftXtExecDescriptor(plan, ux,ux, CUFFT_FORWARD));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uy,uy, CUFFT_FORWARD));
        CUFFT_CHECK(cufftXtExecDescriptor(plan, uz,uz, CUFFT_FORWARD));
    }
     
    Compute_perstr_hom<<< Gridsize, Blocksize >>>(ux_begin_f, ux_end_f, uy_begin_f, uz_begin_f); 
    
    CUFFT_CHECK(cufftXtExecDescriptor(plan, ux,ux, CUFFT_INVERSE));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uy,uy, CUFFT_INVERSE));
    CUFFT_CHECK(cufftXtExecDescriptor(plan, uz,uz, CUFFT_INVERSE));
    
    Normalize_3d<<< Gridsize, Blocksize >>>(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, nx,ny,nz);
    
    Compute_persts_hom<<<Gridsize,Blocksize>>>(dummy, dummy2, dummy3, ux_begin_r, ux_end_r,
                                                uy_begin_r, uz_begin_r, Chom, ny, nz);
    
    cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy, &avgpersts[0], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy2, &avgpersts[1], num_items);
    cub::DeviceReduce::Sum(t_storage,t_storage_bytes, dummy3, &avgpersts[2], num_items);
    
    if (nccl_int == 0)
    {
        CUDA_CHECK(cudaStreamSynchronize(0));
        MPI_Allreduce(MPI_IN_PLACE, avgpersts, 3, MPI_DOUBLE, MPI_SUM, comm); 
    }
    else
    {
        ncclAllReduce(avgpersts, avgpersts, 3, ncclDouble, ncclSum, nccl_comm, 0);
    }
    
    if (TRACK_OBS == 1)
        ////NOTE:COPYING perstr to double for finding strains and stresses
        Move_perstr<<<Gridsize,Blocksize>>>(dummy3, dummy4, dummy5, ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r, ny,nz);

    ////Note:Scaling of avg value is done here.
    Compute_homstr_hom<<<1,1>>>(hom_strain_v, S11, S12, sigappl_v,
                                avgeigsts, avgpersts, misfit_aniso, nx,ny,nz);

    if(print_elas_vectors == 3 && OUTPUT == 1)
    {
            
        CUDA_CHECK(cudaMemcpy(eigsts_h, avgeigsts, 3*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(hom_strain_h, hom_strain_v, 6*sizeof(double), cudaMemcpyDeviceToHost));
        
        Print_elas_MA(ux_begin_r, ux_end_r, uy_begin_r, uz_begin_r,(char*)"perstr0", (char*)"perstr1", 
                        (char*)"perstr2");
         
        if (rank == 0)
        {
            printf("Avgeigsts0 value: %le\n", eigsts_h[0]);
            printf("Avgeigsts1 value: %le\n", eigsts_h[1]);
            printf("Avgeigsts2 value: %le\n", eigsts_h[2]);
            
            printf("Avgpersts0 value: %le\n", persts_h[0]);
            printf("Avgpersts1 value: %le\n", persts_h[1]);
            printf("Avgpersts2 value: %le\n", persts_h[2]);

            printf("Homstrain0 value: %le\n", hom_strain_h[0]);
            printf("Homstrain1 value: %le\n", hom_strain_h[1]);
            printf("Homstrain2 value: %le\n", hom_strain_h[2]);
        }
    }

    if (TRACK_OBS == 1 || (engs_out != 0 && OUTPUT == 1))
        CUDA_CHECK(cudaMemset(dummy2, 0.0, double_size));
    
    if (nof_variants == 1)
        Compute_dfeldphi_sv<<<Gridsize, Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r,
                                                     ux_begin_r, uy_begin_r, uz_begin_r,
                                                     dummy2, hphisum, dhdphi0, hom_strain_v,
                                                     Chom, epszero, misfit_aniso, engs_out, OUTPUT, TRACK_OBS, ny,nz);
    if (nof_variants == 4)
        Compute_dfeldphi_hom<<<Gridsize, Blocksize>>>(dfdphi0_begin_r, dfdphi0_end_r,
                                                      dfdphi1_begin_r, dfdphi2_begin_r, dfdphi3_begin_r, 
                                                      ux_begin_r, uy_begin_r, uz_begin_r,
                                                      dummy2, hphisum, dhdphi0, dhdphi1, dhdphi2, dhdphi3, hom_strain_v,
                                                      Chom, epszero, misfit_aniso, engs_out, OUTPUT, TRACK_OBS, ny,nz);
    if (engs_out == 1 && OUTPUT == 1)
        CUDA_CHECK(cudaMemcpy(felas_h, dummy, double_size, cudaMemcpyDeviceToHost)); 
 
    if (stress_strain_out == 1 && OUTPUT == 1)
    {
        Compute_str_sts_hom<<< Gridsize, Blocksize >>>(dummy3, dummy4, dummy5, dhdphi0, dhdphi1, dhdphi2, 
                                                       hphisum, Chom,  hom_strain_v, epszero, misfit_aniso, nx_local, ny,nz); 
        
        CUDA_CHECK(cudaMemcpy(s11_h, dhdphi0, double_size, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(s22_h, dhdphi1, double_size, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(s33_h, dhdphi2, double_size, cudaMemcpyDeviceToHost));
        
        CUDA_CHECK(cudaMemcpy(e11_h, dummy3, double_size, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(e22_h, dummy4, double_size, cudaMemcpyDeviceToHost));
        CUDA_CHECK(cudaMemcpy(e33_h, dummy5, double_size, cudaMemcpyDeviceToHost));
    }
    
    if (TRACK_OBS == 1)
    {
        Compute_sts_hom<<< Gridsize, Blocksize >>>(dummy3, dummy4, dummy5, 
                                                hphisum, Chom, hom_strain_v, epszero, misfit_aniso, nx_local, ny,nz);
            
        memset(persts_h, 0.0, 6*sizeof(double));  
        CUDA_CHECK(cudaMemset(avgpersts, 0.0, 6*sizeof(*avgpersts)));
        
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy3, &avgpersts[0], num_items);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy4, &avgpersts[1], num_items);
        cub::DeviceReduce::Sum(t_storage, t_storage_bytes, dummy5, &avgpersts[2], num_items);
        //CUDA_CHECK(cudaDeviceSynchronize()); 
        
        ncclAllReduce(avgpersts, avgpersts, 6, ncclDouble, ncclSum, nccl_comm, 0);
    
        CUDA_CHECK(cudaMemcpy(persts_h, avgpersts, 6*sizeof(double), cudaMemcpyDeviceToHost));
        //CUDA_CHECK(cudaDeviceSynchronize()); 
        
        if (rank == 0)
        {
            persts_h[0] *= sizescale;
            persts_h[1] *= sizescale;
            persts_h[2] *= sizescale;
            if (print_elas_vectors == 3)
            { 
                printf("S11 avg value is:%le\n", persts_h[0]);
                printf("S22 avg value is:%le\n", persts_h[1]);
                printf("S33 avg value is:%le\n", persts_h[2]);
            }
        }
        MPI_Barrier(comm);
    }
}
