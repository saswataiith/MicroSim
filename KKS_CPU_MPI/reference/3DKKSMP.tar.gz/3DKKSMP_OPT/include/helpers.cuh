#include <iostream>
#include <fstream>
#include <cstdint>
#include <string>
#include <vector>
#include <cuda_runtime.h>
#include<cublas_v2.h>

#ifndef HELPERS_CUH
#define HELPERS_CUH
/*
__device__ void get_kx_ky_kz(double *kx, double *ky, double *kz, 
                             BoxIterator<cufftDoubleComplex> it) 

{
    long x = (long)it.x();
    long y = (long)it.y();
    long z = (long)it.z();

    int nx = nx_d;
    int ny = ny_d;
    int nz = nz_d;

    double dx = dx_d;
    double dy = dy_d;
    double dz = dz_d;

    if (x <= nx / 2)
        *kx = (double)x * (double) (2.0 * M_PI /(dx * (double)nx));
    else
        *kx = (double)(x-nx) * (double) (2.0 * M_PI /(dx * (double)nx));
    
    if (y<= ny / 2)
        *ky = (double)y * (double) (2.0 * M_PI /(dy * (double)ny));
    else
        *ky = (double)(y-ny) * (double) (2.0 * M_PI /(dy * (double)ny));
    
    if (z<= nz / 2)
        *kz = (double)z * (double) (2.0 * M_PI /(dz * (double)nz));
    else
        *kz = (double)(z-nz) * (double) (2.0 * M_PI /(dz * (double)nz));

    return;
}*/

__global__ void printKernel(double *arr, int idx, int rank) {
    printf("Rank %d: hphisum[%d] = %f\n", rank, idx, arr[idx]);
}

__global__ void printIter(BoxIterator<cufftDoubleComplex> iter_begin, int idx, long rank) {
    iter_begin += idx;
    printf("Rank %ld: ux[%d] = %f + %f i\n", rank, idx, iter_begin->x, iter_begin->y);
}

#endif // HELPERS_CUH
