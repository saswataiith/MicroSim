#include<stdio.h>
#include<stddef.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#include<fenv.h>
#include<cuda.h>
#include <stdint.h>
#include <mpi.h>
#include<cufftMp.h>
#include<cufft.h>
#include<cuComplex.h>
#include<cublas_v2.h>
#include<cuda_runtime.h>
#include<math_constants.h>
#include "helper_cuda.h"
#include <cub/cub.cuh>
#include <time.h>
#include <unistd.h>
#include "cuda_runtime_api.h"
#include "box_iterator.hpp"
#include "error_checks.hpp"
#include "helpers.cuh"
#include <sys/stat.h>
#include <errno.h>
#include "hdf5.h"
#include "hdf5_hl.h"
#include <nccl.h>
#include <curand_kernel.h>

#define PI acos(-1.0)
#define COMPERR 1.0e-8
#define kB 1.38e-23
#define Complex(x,y) make_cufftDoubleComplex(x,y)
#define Re(z) cuCreal(z)
#define Im(z) cuCimag(z)

#define H2D CUFFT_COPY_HOST_TO_DEVICE
#define D2H CUFFT_COPY_DEVICE_TO_HOST
#define D2D CUFFT_COPY_DEVICE_TO_DEVICE
__constant__ int nx_d;
__constant__ int ny_d;
__constant__ int nz_d;
__constant__ int nx_local_d;
__constant__ int nx_start_d;
__constant__ double dx_d;
__constant__ double dy_d;
__constant__ double dz_d;

//using namespace cub;
cudaDeviceProp GPUprops;
cudaError_t Err;
// CUB Vars.
void *t_storage = NULL;
size_t t_storage_bytes = 0;
size_t complex_size, double_size;
long i, j, k, l;

//Energy calc vars.
double *fchem, *fgrad, *felas,*felas2, *ftotal;
double *fchem_avg, *fgrad_avg, *felas_avg, *ftotal_avg, *Vf;

cudaLibXtDesc *mu, *dfdc, *dfdcx, *dfdcy, *dfdcz, *gradmux, *gradmuy, *gradmuz;
cudaLibXtDesc *M, *gradMx, *gradMy, *gradMz, *gradsq_mu;
double *f0, *c_eq, *kappa;
cudaLibXtDesc *comp, *phi0, *phi1, *phi2, *phi3;
double *hphi0, *hphi1, *hphi2, *hphi3, *hphisum;
double *dhdphi0, *dhdphi1, *dhdphi2, *dhdphi3, *phisum;

// Driv forces.
double *dgdphi0, *dgdphi1, *dgdphi2, *dgdphi3;
double *dfchdphi0, *dfchdphi1, *dfchdphi2, *dfchdphi3;
cudaLibXtDesc *dfdphi0, *dfdphi1, *dfdphi2, *dfdphi3;

//Elastic driving force
double *dfeldphi0, *dfeldphi1, *dfeldphi2, *dfeldphi3;

//Occupancy matrix
int *occupancy_h, count;

//FFT Handle
cufftHandle  plan = 0;
cufftHandle  dummy_plan = 0;
// Diff Input params deciding vars.
int kappa_omega_calc = 0, elast_consts = 0, elast_eqm = 0, print_conv_iter = 0;
int FE_form = 0, Non_dim_calc = 0, Method=0, Ln_dx =0, felas2_out = 0, newdfel = 0;
//total number of simulation steps
int num_steps = 0, savet = 0, nelast = 0, time_sa = 0, appl_stress = 0, seed = 0, VTK_out = 0;
int norm_calc = 0, EC_calc = 0; 

// Conversion paramters.
double Lconv=0.0, Econv=0.0, Tconv=0.0;

//Configuration to be initialized or to be read
int        initcount = 0, initflag = 0, iteration = 0, interpolation = 0, calc_uzero = 0,
           restart = 0, OUTPUT = 0, print_elas_vectors = 0;

// Output writing vars.
int conf_out = 0, stress_strain_out = 0, print_engs = 0, count_engs = 0, engs_out = 0,
    drivforces_out = 0, nof_variants = 0;

// Alloy composition, amplitude of white noise to be added to the system
double     alloycomp = 0.0, noise_level = 0.0, spacing=0.0;

//Grid size along x, timestep
double     dx = 0.0, dy = 0.0, dz = 0.0, dt = 0.0, delta = 0.0;
int        elast_int = 0, t_prof1 = 0, t_prof2 = 0, t_prof3 = 0,
           numsteps_prof1 = 0, numsteps_prof2 = 0, time_elast = 0, comp_evolution = 0;

//Total simulation time (nondimensional)
double     sim_time = 0.0, total_time = 0.0;

//System dimensions along x and y
long        nx = 0, ny = 0, nz = 0,  np = 0;

// Phase-specific parameters.
double kpa = 0.0, omega = 0.0;

//Bulk free energy coefficients
double     f0A = 0.0, f0B = 0.0, Vm = 0.0, sigma = 0.0, width = 0.0, alpha = 0.0;
double     Am = 0.0, Ap = 0.0, theta = 0.0, vf = 0.0, Na=0.0, Nv=0.0, theta2 = 0.0;
double     f0_alpha = 0.0, f0_beta = 0.0;
double     diffusivity = 0.0, relax_coeff = 0.0, gamma_intf = 0.0, gamma_apb = 0.0 ;
double     Mobility = 0.0, Vol_frac = 0.0;
double     interface_energy = 0.0, interface_width = 0.0;
//Excess solute concentration in matrix phase
double     c0 = 0.0, c0p = 0, alloy_comp = 0.0; 
double     ppt_size_h = 0.0, *ppt_size;
double     c_alpha_eq = 0.0,  c_beta_eq = 0.0, Supersaturation=0.0;
double     wn = 0.0, T = 0.0, Ln = 0.0, En = 0.0, Tn = 0.0;

FILE       *fpout;
double     epszero = 0.0, misfit_aniso = 0.0;
double     sizescale = 0.0;
double     sigappl_v_h[6] = {0.0}, *sigappl_v;
double     disperror = 0.0, Tol = 0.0;
double     mu_m = 0.0, nu_m = 0.0, Az_m = 0.0;
double     mu_p = 0.0, nu_p = 0.0, Az_p = 0.0;
double     Cp[6][6] = {0.0}, Cm[6][6] = {0.0};
double     Chom11 = 0.0, Chom12 = 0.0, Chom44 = 0.0;
double     *Chom11_d, *Chom12_d, *Chom44_d;
double     Chet11 = 0.0, Chet12 = 0.0, Chet44 = 0.0;
double     *Chet11_d, *Chet12_d, *Chet44_d;
double     *S11_d, *S12_d, *S44_d;
double     S11 = 0.0, S12 = 0.0, S44 = 0.0;
double     c11m = 0.0, c12m = 0.0, c44m = 0.0, inhom = 0.0; 
double     c11p = 0.0, c12p = 0.0, c44p = 0.0;

cudaLibXtDesc *ux,*uy, *uz;
cudaLibXtDesc *unewx,*unewy, *unewz;
cudaLibXtDesc *str_v0_d, *str_v1_d, *str_v2_d, *str_v3_d, *str_v4_d, *str_v5_d;
cudaLibXtDesc *eigsts11, *eigsts22, *eigsts33;
cudaLibXtDesc *ts0_d, *ts1_d, *ts2_d,*ts3_d, *ts4_d, *ts5_d;

double *vol_frac; double vf_h = 0.0;
double *ux_avg, *uy_avg, *uz_avg;
double *ux_avg2, *uy_avg2, *uz_avg2;
double *ux_real,*uy_real, *uz_real;
double *s11, *s22, *s33, *s23, *s13, *s12, *s_eq;
double *s11_h, *s22_h, *s33_h, *s23_h, *s13_h, *s12_h, *s_eq_h;
double *e11, *e22, *e33, *e23, *e13, *e12, *e_eq;
double *e11_h, *e22_h, *e33_h, *e23_h, *e13_h, *e12_h, *e_eq_h;

int calc_interface_energy = 0, create_nuclei = 0;

int Num_of_blocks = 0;

dim3 Gridsize, Blocksize;
//dim3 Gridsize2, Blocksize2;

MPI_Comm comm = MPI_COMM_WORLD;
int rank,size;
long nx_local, nx_start, nx_end;

cufftDoubleComplex *comp_h2, *phi0_h2; 
cufftDoubleComplex *comp_h, *phi0_h, *phi1_h, *phi2_h, *phi3_h;

cufftDoubleComplex *glob_comp = NULL;
cufftDoubleComplex *glob_phi0 = NULL;
cufftDoubleComplex *glob_phi1 = NULL;
cufftDoubleComplex *glob_phi2 = NULL;
cufftDoubleComplex *glob_phi3 = NULL;

size_t free_gpumem, total_gpumem;
//size_t workspace;
long num_items = 0;

double *comp_out_h, *phi0_out_h, *phi1_out_h, *phi2_out_h, *phi3_out_h;
double *dummy, *dummy2, *dummy3, *dummy4, *dummy5;
double *Cavg, *S_d;
int NUM_THREADS_X, NUM_THREADS_Y, NUM_THREADS_Z;
int MPI_out = 0;

double dkx, dky, dkz;
double *kx, *ky, *kz, *glob_kx;
int Imag = 0;

cufftDoubleComplex *test1, *test2, *test3;
double *calpha, *cbeta, *falpha, *fbeta;
int testing = 0, nccl_int = 0;
int equal_nofps = 0, proceed = 0;
long Blocks_X, Blocks_Y, Blocks_Z;
long Thread_X, Thread_Y, Thread_Z;

double *hom_strain;
double *Chom, *Chet;
double  *min_comp, *max_comp;
double  min_comp_h=0.0, max_comp_h=0.0;
int Smoothening = 0;
int Smoothening_steps = 0;
int temp1 = 0, temp2 = 0;

int converge=1,iter=1, FALSE = 0;
double *avgeigsts0, *avgeigsts1, *avgeigsts2;
double *avgeigsts, *avgpersts;
double *avgpersts0, *avgpersts1, *avgpersts2;
double *avgpersts3, *avgpersts4, *avgpersts5;
double *eigsts_h, *persts_h;
double eigsts0, eigsts1, eigsts2;
double  persts0, persts1, persts2;
double persts3, persts4, persts5;
double *hom_strain_h;
double *hom_strain_v;
double *disperr, *disperr_h; 
cublasHandle_t blas_handle;
cublasStatus_t blas_stat;
ncclComm_t nccl_comm;
char path[100];
char param[100];
int NFP=0;
double CURV = 0.0, F = 0.0, phi_a = 0.0, phi_b = 0.0, Lambda = 0.0, delta_C = 0.0, a2 = 0.0;
double CALPHA_chk = 0.0, CBETA_chk = 0.0; double* abort_flag;
int noise_int=0; int noise_steps=0; double noise_per=0.0;
curandStatePhilox4_32_10_t *d_states; double* noise_array; double* noise_mean;

////Eng calc vars.
cudaLibXtDesc *gradphi0x, *gradphi0y, *gradphi0z;
cudaLibXtDesc *gradphi1x, *gradphi1y, *gradphi1z;
cudaLibXtDesc *gradphi2x, *gradphi2y, *gradphi2z;
cudaLibXtDesc *gradphi3x, *gradphi3y, *gradphi3z;
double *ftotal_out, *felas_out;
double *Comp1D; double *Phi01D;
int16_t *dummy_int, *dummy_int2, *dummy_int3, *dummy_int4, *dummy_int5;
int16_t *comp_int_h, *phi0_int_h, *phi1_int_h, *phi2_int_h, *phi3_int_h;
float *dummy_float, *dummy_float2, *dummy_float3, *dummy_float4, *dummy_float5;
float *comp_float_h, *phi0_float_h, *phi1_float_h, *phi2_float_h, *phi3_float_h;
int TRACK_TIME=0; int TRACK_OBS=0;
double *Avg_ptr, *Avg_ptr_h; double *ftotal_h, *felas_h;
double *comp_avg, *comp_avg_h; 
